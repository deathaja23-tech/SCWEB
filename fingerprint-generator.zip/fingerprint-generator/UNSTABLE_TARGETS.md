# Unstable / Held Targets

Dokumen ini mencatat **target antibot yang BELUM stabil** — yaitu yang **tidak
didaftarkan** di `Target_Registry` sehingga tidak muncul di `GET /targets` dan
mengembalikan **400** bila diminta via `?target=`.

Alasannya menegakkan **Requirement 8.4** ("jangan pernah pancarkan payload yang
diketahui salah"): sebuah target hanya diregister bila **skema payload + konstanta
kripto stabil** tersedia. Sumber penilaian stabilitas: `anti-bot-crypto-constants.md`
§9 (Stability Assessment) dan `anti-bot-fingerprint-reference.md`.

Status per: 2026-07-14.

## Ringkasan

| Target | Tier | Kode ada? | Diregister? | Penghambat utama |
| ------ | ---- | --------- | ----------- | ---------------- |
| `github` | — | dihapus | ❌ | **Not Applicable** — server-echo token, tak ada payload untuk digenerate (lihat §Not Applicable) |
| `akamai` | — | scaffold | ❌ | **Not Applicable** — server nonce (`bm_sz`) + state akumulatif; butuh browser+challenge hidup (lihat §akamai) |
| `cloudflare` (`jsd`) | — | scaffold | ❌ | **Not Applicable** — `ut` HMAC server-signed + nonce `r` per-request; di-RE 2026-07-14 (lihat §cloudflare/jsd) |
| `cloudflare` (`turnstile`) | — | scaffold | ❌ | **Not Applicable** — VM bytecode per-request + eksekusi interaktif; di-RE 2026-07-14 (lihat §cloudflare/turnstile) |
| `kasada` | — | scaffold | ❌ | **Not Applicable** — server IM token gating `ips.js` + VM per-deploy; di-RE 2026-07-14 (lihat §kasada) |

**Sudah stabil & diregister (referensi):** `generic`, `amazon`, `xiaomi`, `x`,
`microsoft`, `datadome`, `human`.

**Semua target held (Tier C) telah tuntas di-RE (2026-07-14).** Tidak ada lagi
target berstatus "held/rotating menunggu RE" — ketiganya terbukti **Not Applicable**
secara arsitektur, bukan sekadar konstanta berputar (lihat §Not Applicable +
`re-artifacts/RE_EVIDENCE_TIER_C.json`).

---

## Registered (2026-07-14) — `datadome` + `human`

Sebelumnya Tier B (held). **Dinaikkan ke registered** setelah RE penuh + capture
payload nyata dari `tags.js v5.8.0` (leboncoin.fr) dan verifikasi **byte-accurate
round-trip** (golden test di `cryptoutil/datadome_roundtrip_test.go`).

**Root-cause bug yang menahan target ini** (bukan "urutan sinyal rotating"
seperti diduga): xorshift state mixer `c(n)=(n^=n<<13)^n>>17^n<<5` — `>>17` di
JavaScript adalah **arithmetic shift bertanda (int32)**, bukan logical unsigned.
Implementasi lama pakai unsigned `>>`, jadi keystream desync setelah mix pertama.

**Yang dipatok dari capture (semua terverifikasi):**
- **xorshift signed int32** — `cryptoutil.Xorshift32` (fix utama).
- **seed constant `i^t` = `0x7d8479f9`** — cross-session stable (dibuktikan
  recover dari 3 payload di 2 sesi). `mainSeed = 0x7d8479f9 ^ djb2(ddk)`.
- **cid seed** = `1809053797 ^ djb2(cid)`, salt OFF (dibuktikan via cross-payload
  diff test).
- **main salt** ON (`--e`, `e0=u`); **base64 salt** `--h`, `h0=u`; ekstraksi byte
  `>>16,>>8,>>0` (i=0,1,2).
- **urutan + 191 signal** — di-capture via hook `JSON.stringify` in-browser,
  disimpan di `signal_template.go` (regenerate dari `re-artifacts/datadome/`).

**Perilaku builder:** 30 signal identity-coherent di-override dari `BrowserIdentity`
(screen/GPU/UA/tz/plugins), 11 signal session-specific di-randomize per-build
(hash/counter — supaya payload tidak byte-identik = bot tell), 114 detection-flag
tetap default clean-browser, 36 network-timing default. `human` reuse layout ini
dengan HSV interstitial `9E9FC74889F6`.

**Batas jujur:** `u` (salt init) = `f(Date.now())` per-sesi — di generator
stateless dipakai turunan dari clock identity (reproducible per-build). Blok async
7-elemen (`bci/bcl/bct/bdt/nhi/k_lyts/k_lytk`) urutan internalnya bervariasi antar
page-load; server DataDome parse buffer by-key bukan by-posisi, jadi tidak masalah.

---

## Not Applicable — di luar cakupan generator

Target yang **dihapus** karena secara arsitektur tidak ada payload fingerprint
untuk digenerate. Bukan "menunggu RE" — sudah di-RE dan terbukti tidak cocok
dengan model generator stateless.

### `github` (dihapus 2026-07-14)

- **Hasil RE (dari `github.com/login` + `/signup` asli):** GitHub **tidak** memakai
  fingerprintjs/BotD collector yang di-POST. Asumsi lama di `anti-bot-fingerprint-reference.md`
  §9 (`fastBotDetection`/`fsid`/`signals`/`nonce`) **fiktif** — nol kecocokan di
  seluruh aset GitHub (`sessions.js`, `signup.js`, HTML form).
- **Gate sebenarnya = server-echo token:**
  - `timestamp` + `timestamp_secret` — HMAC di-*keyed* dengan Rails `secret_key_base`
    (server-side). **Berubah tiap request** (bukan hash dari `timestamp`). Client
    hanya meng-echo balik, tidak bisa menghitung.
  - `required_field_XXXX` — honeypot bernama **dinamis** per-render (mis. `7579`→`413b`→`ba31`).
    Harus dikosongkan.
  - `authenticity_token` — CSRF Rails standar (echo-only).
  - `visitor-payload`/`visitor-hmac` — Octolytics tracking, **bukan** gate.
  - `navigator.webdriver` — dicek client-side di `signup.js`, bukan payload POST.
- **Bukti tes login POST nyata (bad creds, 4 varian):** form-valid, honeypot-terisi,
  `timestamp_secret`-basi, dan tanpa-timestamp — **semua** dapat perlakuan identik
  (`200 "Incorrect username or password"`) di tahap pre-auth. Gate-nya form-echo,
  bukan fingerprint payload.
- **Kenapa NA:** `timestamp_secret` di-keyed dengan secret yang hanya ada di server
  GitHub — generator stateless tidak bisa & tidak boleh memproduksinya. Cara benar =
  **scrape → echo field → submit** (urusan HTTP client, bukan generator fingerprint).

### `akamai` (di-RE 2026-07-14, bukan lagi "Tier C rotating")

Diagnosis lama ("urutan array 58-elemen rotating") **salah** — persis seperti kasus
datadome. RE penuh membuktikan blocker-nya arsitektural, bukan sekadar konstanta.

- **Capture nyata:** `sensor_data` v3 dari BestBuy (Akamai Bot Manager), format
  `3;0;1;<n>;3555907;<base64hash>;<counters>;<blok terenkripsi delimiter ">`.
  POST `{"sensor_data": "..."}` ke path random same-origin, `text/plain`.
- **Blocker #1 — server-issued nonce.** Header telemetry `e=<hash>~YAAQsXw2F16Zk0Gf...`
  — token `YAAQ...` itu **ditemukan di dalam cookie `bm_sz`** (`in_bmsz: true`) yang
  di-set server pada response awal. Payload valid **wajib menyertakan challenge token
  dari server dulu** → challenge-response, bukan generate-dari-nol.
- **Blocker #2 — internal accumulation state.** Dengan `Date.now`/`performance.now`/
  `Math.random` **di-freeze** dan **tanpa input**, dua panggilan `bmak.get_telemetry()`
  berturut-turut tetap menghasilkan output **berbeda** (6530B vs 2694B). Ada
  counter/state internal yang berubah tiap panggil.
- **Bukti empiris** (bukan asumsi): probe `Date.now`/`perf`/`random` frozen + no-input
  → `identical: false`; substring-match nonce → `in_bmsz: true`.
- **Kenapa beda dari datadome:** datadome seed enkripsinya **konstan** (`0x7d8479f9`,
  cross-session stable) & semua input deterministik dari identity + client-chosen
  session key → byte-accurate offline. akamai seed = **server nonce** + state
  akumulatif → tidak bisa offline.
- **Kenapa NA:** butuh runtime browser hidup + challenge server. Kategori sama dengan
  `turnstile`. Yang *bisa* = extraction-replay stateful (ambil `bm_sz` → jalankan
  `get_telemetry()` di CloakBrowser → replay), tapi itu **solver/client**, bukan
  generator stateless. Scaffold `internal/antibot/akamai/` tetap ada (tidak diregister).
- **Deep-dive struktural (2026-07-14):** field-by-field map `sensor_data` v3 +
  cookie `_abck`/`bm_sz` ada di `re-artifacts/akamai/SENSOR_V3_STRUCTURE.md`.
  Smoking gun terbukti: `sensor_data seg[4]` == `bm_sz[2]` == `3555907` (match
  persis) → payload meng-echo nilai server-issued. SEED (seg[5]) = 32 byte
  (256-bit) session key, bukan konstanta (kontras DataDome `0x7d8479f9`). Enrichment
  di `RE_EVIDENCE.json` → `deep_dive_2026_07_14`. Gap tersisa (jujur, belum di-RE):
  alfabet char-substitution seg[7], algoritma MAC `_abck[6]` (server-side), encoding
  event penuh setelah header.

---

### `cloudflare` — varian `jsd` (di-RE 2026-07-14)

Diagnosis lama ("alfabet LZ + template ~1610 entri rotating per-script") **usang** —
flow JSD sudah berganti. Capture nyata dari `nowsecure.nl` (CF managed/JSD):

- **Flow sekarang = `precursor`, bukan `jsd/oneshot`.** GET
  `cdn-cgi/challenge-platform/scripts/precursor/main.js` lalu POST **plain-JSON
  `precdata`** (telemetri behavioral: `cb/f/k/n/ptr/v` + `_to` timestamp) — bukan
  template fingerprint 1610-entri, bukan LZ-compressed.
- **Blocker #1 — nonce server per-request.** `__CF$cv$params.r` berputar tiap load
  (**bukti:** `a1abda6ebe2ff882` → `a1abda8758e8ce19` di dua fetch beruntun).
- **Blocker #2 — token HMAC server-signed.** `__CF$cv$params.ut` (format
  `<base>-<epoch>-1.2.1.1-<hmac_sig>`) **hanya muncul setelah** browser POST
  `precdata` (respons server), absen dari page-load biasa. HMAC di-keyed dengan
  secret server → client tidak bisa menghitung, hanya echo.
- **Blocker #3 — butuh browser.** `scripts/precursor/main.js` = **0 byte** ke plain
  curl (butuh cf cookie + konteks JS browser). Sukses = cookie `cf_clearance` (IP+UA+TLS-bound).
- **Kenapa NA (beda dari datadome):** datadome seed `0x7d8479f9` konstan &
  client-derivable; gate CF JSD = token HMAC-signed server yang client cuma echo.
  Tidak ada jalur client-computable.

### `cloudflare` — varian `turnstile` (di-RE 2026-07-14)

- **Bukti test-key:** `1x00...AA` (always-pass) balikin placeholder konstan
  `XXXX.DUMMY.TOKEN.XXXX` (len 21) — bypass VM asli, tak berguna untuk sitekey nyata.
  `3x00...FF` (paksa challenge interaktif) → browser headless **tak pernah** hasilkan
  token (butuh eksekusi interaktif/WebGL nyata). Membuktikan token **tak bisa dihitung offline**.
- **VM chunk per-versi:** widget fetch `challenges.cloudflare.com/turnstile/v0/b/<ver>/api.js`.
  Program = float-key XOR + VM bytecode per-request (417–580 instr) + PoW (400–500k SHA-256), semua berputar per-request.
- **Kenapa NA:** token = hasil eksekusi VM bytecode terenkripsi per-request di dalam
  iframe realm CF melawan challenge hidup. Kategori sama akamai/BotGuard — hanya engine
  browser hidup yang bisa produksi token valid.

### `kasada` (di-RE 2026-07-14)

Algoritma XTEA memang stabil (`DELTA 0x9E3779B9`, 32 round), tapi itu bukan
penghambatnya. Capture nyata dari canadagoose.com/hyatt.com/twitch.tv:

- **Blocker #1 — server IM token gating `ips.js`.** URL `ips.js` **membawa query
  param server-issued**: `akm_bmfp_b2=<blob>` **dan** `x-kpsdk-im=<IM token>`.
  Script VM yang di-serve **diparameterisasi challenge server** → client wajib punya
  token server dulu sebelum bisa menjalankan generator. Challenge-response, identik akamai.
- **Header terverifikasi:** `x-kpsdk-ct` (Client Token blob server-bound, 168 char),
  `x-kpsdk-dt`, `x-kpsdk-v: j-1.2.522` (versi per-deploy), `x-kpsdk-im`.
- **Blocker #2 — VM per-deploy.** Path UUID per-deploy
  (`149e9513-.../2d206a39-.../ips.js`, ~477KB) = VM 172-handler + template 428-slot
  di-shuffle per-batch + time-lock ~5 jam. Kunci XTEA + seed phrase + layout
  ter-embed di bytecode terenkripsi, ganti per-deploy.
- **PoW:** SHA-256 chaining, difficulty dari `/mfc`, butuh eksekusi VM.
- **Kenapa NA:** dua blocker independen — (1) IM token server harus ada dulu
  (challenge-response), (2) generatornya VM bytecode terenkripsi per-deploy.
  Generator stateless tidak bisa produksi keduanya.

---

## Catatan

- **Registered (2026-07-14):** `datadome` + `human` — byte-accurate, golden
  round-trip verified (lihat §Registered). Tidak lagi held.
- **Not Applicable (semua di-RE, bukan label):** `github` (server-echo token),
  `akamai` (server nonce `bm_sz` + state akumulatif), `cloudflare/jsd` (token HMAC
  server-signed `ut` + nonce `r` per-request), `cloudflare/turnstile` (VM bytecode
  per-request + eksekusi interaktif), `kasada` (server IM token gating `ips.js` +
  VM per-deploy). **Semuanya model arsitektur (server-issued challenge + eksekusi
  browser hidup), bukan sekadar konstanta rotating.** Bukti empiris di
  `re-artifacts/RE_EVIDENCE_TIER_C.json` + `re-artifacts/{cf-jsd,cf-turnstile,kasada}/`.
- **Tidak ada lagi target held.** Semua yang dulu Tier C ("rotating, menunggu RE")
  sudah tuntas: terbukti NA, bukan menunggu konstanta.
- **Satu-satunya jalur untuk target NA** = extraction-replay stateful (jalankan
  script asli di browser hidup, panen token/cookie, replay) — itu **solver/client**,
  di luar cakupan generator fingerprint stateless.
- **Cara mengaktifkan target baru** (umum, bila suatu saat ada yang stabil):
  lengkapi skema payload + konstanta dari capture nyata → hapus status "held" →
  tambahkan `init()` `antibot.Register(...)` + blank import di `cmd/server/main.go`
  → tambahkan ke enum `target` di `cmd/server/docs.go`.
