#!/usr/bin/env python3
"""Capture Cloudflare Turnstile: solve the widget twice on a real sitekey and
compare tokens. Proves (1) token is per-solve unique (server-challenge-bound),
(2) the challenge chunk (VM bytecode) is fetched per-request, (3) offline
generation is impossible without executing the per-request bytecode.

Uses a self-hosted HTML page with a public Cloudflare demo sitekey.
Standalone CloakBrowser script (native launch_async).
"""
import asyncio
import http.server
import json
import socketserver
import threading
from pathlib import Path

OUT = Path(__file__).parent
OUT.mkdir(parents=True, exist_ok=True)
PORT = 8791
HOST_IP = "192.168.88.241"  # LAN IP reachable from CloakBrowser (Docker or local)

# Public Cloudflare Turnstile TEST sitekeys (docs.cloudflare.com):
#   1x00000000000000000000AA -> always passes (visible)
#   3x00000000000000000000FF -> forces interactive challenge (real VM)
SITEKEY = "1x00000000000000000000AA"

PAGE = f"""<!doctype html><html><head>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
</head><body>
<div id="cf" class="cf-turnstile" data-sitekey="{SITEKEY}"
     data-callback="onOk"></div>
<script>
window.__tok = null;
function onOk(t){{ window.__tok = t; }}
</script></body></html>"""


async def solve_once(ctx, label):
    page = await ctx.new_page()
    chunk_urls = []

    def on_req(r):
        u = r.url
        if "challenges.cloudflare.com" in u and (".js" in u or "/cv/" in u or "/flow/" in u or "pat/" in u):
            chunk_urls.append(u)

    page.on("request", on_req)
    await page.goto(f"http://{HOST_IP}:{PORT}/", wait_until="domcontentloaded", timeout=30000)

    tok = None
    for _ in range(40):  # up to ~40s
        await asyncio.sleep(1)
        try:
            tok = await page.evaluate("window.__tok")
        except Exception:
            tok = None
        if tok:
            break
    print(f"[{label}] token={'<none>' if not tok else tok[:60]+'...'} len={len(tok) if tok else 0}", flush=True)
    await page.close()
    return {"token": tok, "chunk_urls": chunk_urls}


def serve():
    class H(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(PAGE.encode())

        def log_message(self, *a):
            pass

    with socketserver.TCPServer(("0.0.0.0", PORT), H) as httpd:
        httpd.serve_forever()


async def main():
    from cloakbrowser import launch_async

    threading.Thread(target=serve, daemon=True).start()
    await asyncio.sleep(1)

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()

    r1 = await solve_once(ctx, "solve-1")
    r2 = await solve_once(ctx, "solve-2")

    result = {
        "sitekey": SITEKEY,
        "solve1": r1,
        "solve2": r2,
        "tokens_identical": bool(r1["token"] and r1["token"] == r2["token"]),
        "token1_prefix": (r1["token"] or "")[:8],
        "token2_prefix": (r2["token"] or "")[:8],
        "chunk_urls_differ": r1["chunk_urls"] != r2["chunk_urls"],
    }
    (OUT / "capture.json").write_text(json.dumps(result, indent=2))
    print(f"[*] tokens_identical={result['tokens_identical']} "
          f"chunk_urls_differ={result['chunk_urls_differ']}", flush=True)
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
