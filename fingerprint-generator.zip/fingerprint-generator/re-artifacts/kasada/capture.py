#!/usr/bin/env python3
"""Capture Kasada: detect ips.js/p.js, /tl POST, and x-kpsdk-* headers on a
KPSDK-gated target. Proves the token requires executing per-deploy VM bytecode
(ips.js) + PoW, and that x-kpsdk-ct is server-challenge-bound (per-deploy).

Standalone CloakBrowser script (native launch_async).
"""
import asyncio
import json
import os
from pathlib import Path

OUT = Path(__file__).parent
OUT.mkdir(parents=True, exist_ok=True)

# Known Kasada (KPSDK) deployments to probe.
TARGETS = [
    "https://www.canadagoose.com/",
    "https://www.hyatt.com/",
    "https://www.twitch.tv/",
    "https://www.homedepot.com/",
]


async def main():
    from cloakbrowser import launch_async

    cap = {"target": None, "kpsdk_reqs": [], "ips_js": [], "p_js": [], "tl_posts": [],
           "kpsdk_headers": [], "window_kpsdk": None}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    def on_req(r):
        u, h = r.url, r.headers
        kp = {k: v for k, v in h.items() if k.lower().startswith("x-kpsdk")}
        if kp:
            cap["kpsdk_headers"].append({"url": u[:100], "kpsdk": kp})
        if "ips.js" in u:
            cap["ips_js"].append(u)
        if u.rstrip("/").endswith("/p.js") or "/p.js?" in u:
            cap["p_js"].append(u)
        if u.endswith("/tl") or "/tl?" in u:
            entry = {"url": u, "method": r.method}
            try:
                entry["post_len"] = len(r.post_data or "")
            except Exception:
                pass
            cap["tl_posts"].append(entry)

    page.on("request", on_req)

    target = TARGETS[int(os.environ.get("TARGET_IDX", "0"))]
    cap["target"] = target
    print(f"[*] navigating {target}", flush=True)
    try:
        await page.goto(target, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)
    await asyncio.sleep(8)

    try:
        cap["window_kpsdk"] = await page.evaluate(
            "typeof window.KPSDK !== 'undefined' ? Object.keys(window.KPSDK) : null")
    except Exception as e:
        cap["window_kpsdk_err"] = str(e)

    (OUT / "capture.json").write_text(json.dumps(cap, indent=2))
    print(f"[+] ips.js={len(cap['ips_js'])} p.js={len(cap['p_js'])} "
          f"/tl={len(cap['tl_posts'])} kpsdk_hdrs={len(cap['kpsdk_headers'])} "
          f"window.KPSDK={cap['window_kpsdk']}", flush=True)
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
