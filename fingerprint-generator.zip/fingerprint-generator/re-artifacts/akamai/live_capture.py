"""
Akamai Bot Manager — live sensor capture via CloakBrowser.

Loads an Akamai-fronted origin in a real browser engine (the sensor bmak script
is injected at RUNTIME, so static curl never sees it), then:
  1. captures the injected sensor script body (deobfuscation target),
  2. intercepts the sensor_data POST (real payload, not a header sample),
  3. dumps two back-to-back bmak.get_telemetry() calls to prove/measure the
     accumulation-state delta,
  4. reads the _abck / bm_sz cookies before & after the POST.

Authorized RE / instrumentation of a live session — no forging, no bypass.
"""
import asyncio, json, sys, time
from pathlib import Path
from cloakbrowser import launch_async

TARGET = sys.argv[1] if len(sys.argv) > 1 else "https://www.nike.com/"
OUT = Path(__file__).parent / "live_capture_out"
OUT.mkdir(exist_ok=True)

async def main():
    result = {"target": TARGET, "captured_at": time.time()}
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    scripts, posts = [], []

    async def on_response(resp):
        url = resp.url
        try:
            ct = resp.headers.get("content-type", "")
            if "javascript" in ct and resp.request.method == "GET":
                body = await resp.text()
                # Akamai sensor tells: bmak object, get_telemetry, sensor_data
                if any(t in body for t in ("bmak", "get_telemetry", "sensor_data", "abck")):
                    scripts.append({"url": url, "len": len(body)})
                    fn = OUT / ("sensor_%d.js" % len(scripts))
                    fn.write_text(body)
        except Exception:
            pass

    def on_request(req):
        # sensor_data POST: text/plain body with {"sensor_data":...}
        if req.method == "POST":
            try:
                pd = req.post_data or ""
                if "sensor_data" in pd:
                    posts.append({"url": req.url, "body_len": len(pd), "head": pd[:400]})
            except Exception:
                pass

    page.on("response", lambda r: asyncio.create_task(on_response(r)))
    page.on("request", on_request)

    all_js = []
    async def on_any_js(resp):
        try:
            if "javascript" in resp.headers.get("content-type","") and resp.request.method=="GET":
                all_js.append({"url": resp.url, "len": int(resp.headers.get("content-length") or 0)})
        except Exception:
            pass
    page.on("response", lambda r: asyncio.create_task(on_any_js(r)))

    await page.goto(TARGET, wait_until="domcontentloaded", timeout=60000)
    # let the sensor boot + fire its first telemetry POST (needs a beat)
    await page.wait_for_timeout(6000)
    # nudge some input so the sensor has behavioral data to encode
    try:
        await page.mouse.move(120, 140)
        await page.mouse.move(300, 380)
        await page.mouse.wheel(0, 500)
    except Exception:
        pass
    await page.wait_for_timeout(4000)

    # cookies
    cookies = {c["name"]: c["value"] for c in await ctx.cookies()}
    result["cookies_present"] = {k: (k in cookies) for k in ("_abck", "bm_sz", "ak_bmsc")}
    result["abck_head"] = cookies.get("_abck", "")[:120]
    result["bm_sz_head"] = cookies.get("bm_sz", "")[:120]

    # probe bmak in-page: two get_telemetry() calls to measure accumulation delta
    probe = await page.evaluate("""() => {
        const out = {bmak_present: typeof bmak !== 'undefined'};
        try {
            if (typeof bmak !== 'undefined' && typeof bmak.get_telemetry === 'function') {
                const a = bmak.get_telemetry();
                const b = bmak.get_telemetry();
                out.t1_len = a.length; out.t2_len = b.length;
                out.identical = (a === b);
                out.t1_head = a.slice(0, 200);
                out.ver = a.split(';')[0];
                // list bmak's own enumerable keys (API surface, not values)
                out.bmak_keys = Object.keys(bmak).slice(0, 60);
            }
        } catch(e) { out.err = String(e); }
        return out;
    }""")
    # hunt for the sensor global under any name (bmak is common but not universal)
    hunt = await page.evaluate("""() => {
        const hits = [];
        for (const k of Object.getOwnPropertyNames(window)) {
            try {
                const v = window[k];
                if (v && typeof v === 'object' && typeof v.get_telemetry === 'function') {
                    hits.push({name: k, keys: Object.keys(v).slice(0,40)});
                }
            } catch(e){}
        }
        return hits;
    }""")
    result["sensor_global_hunt"] = hunt
    result["bmak_probe"] = probe
    result["sensor_scripts"] = scripts
    result["sensor_posts"] = posts
    result["all_js_count"] = len(all_js)
    result["all_js"] = all_js[:40]

    (OUT / "capture.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    await browser.close()

asyncio.run(main())
