# Akamai Bot Manager — LIVE reverse-engineering (CloakBrowser instrumentation)

**Method:** loaded Akamai-fronted origins in CloakBrowser (real engine — the sensor
`bmak` script is injected at RUNTIME, so static curl never sees it), captured the
sensor script body, the real `sensor_data` POST, two back-to-back
`bmak.get_telemetry()` calls, and the `_abck`/`bm_sz` cookies. Script:
`live_capture.py`. Raw output: `live_capture_out/`.

**Targets that actually booted the full sensor:** `att.com`, `ups.com`
(both set `_abck` + `bm_sz`, `window.bmak` present). `nike.com` only set
`ak_bmsc` (edge present, Bot Manager sensor not armed on the marketing page).

---

## 1. `bmak` object — real API surface (live)

`window.bmak` keys captured live:
```
firstLoad, form_submit, get_telemetry, listFunctions, applyFunc, startTs
```
`get_telemetry()` is the single entry that serializes the whole sensor into the
telemetry string. Confirmed callable from the page context.

## 2. Accumulation state — PROVEN live (the #2 blocker, now measured twice)

Two back-to-back `get_telemetry()` calls, same page, same instant:

| target | call 1 | call 2 | identical? |
|--------|-------:|-------:|:----------:|
| att.com | 6808 B | 2940 B | **false** |
| ups.com | 6864 B | 2916 B | **false** |

The first call flushes a full buffer; the second returns only the delta. An internal
ring buffer / counter mutates per call. **A "replay the same inputs offline" strategy
drifts by construction** — this is no longer an inference, it's measured on two
independent live sites.

## 3. Telemetry envelope — CORRECTED from live data

The old bestbuy artifact showed a *plaintext* `sensor_data` head. The **real POST
body** is a 4-section envelope joined by `&&&`, and `sensor_data` is **base64**:

```
a=<32hex client id>
&&&e=<32hex>~YAAQ...~<int>~<int>     <- server challenge (YAAQ) echoed back
&&&sensor_data=<BASE64>              <- the actual sensor blob
&&&j=AAQAAAAG...                     <- server-MAC-ish trailer (base64)
```

## 4. `sensor_data` (base64) decoded — v3 layout CONFIRMED live (UPS)

`base64 → ;`-delimited. Live UPS decode (corrects the seg[1..3] order from the
static bestbuy guess):

```
3;1;2;0;3420737;wToDY7O53na1dFTzfCmegiU0cs9kx/zndKO3jz+uAT0=;31,124,0,0,15,337;"!x&:>8*wD`yFy"b"x3)...
```

| seg | live value | meaning | status |
|----|-----------|---------|--------|
| 0 | `3` | sensor version | confirmed |
| 1 | `1` | const | confirmed value |
| 2 | `2` | const | confirmed value (was mis-ordered as `1` in static guess) |
| 3 | `0` | const | confirmed value |
| 4 | `3420737` | **server nonce** (from `bm_sz`) | confirmed — cookie `bm_sz` present same session |
| 5 | `wToDY7O5...AT0=` | **256-bit SEED** (b64→32 B: `c13a0363b3b9de76...`) | confirmed (decodes to 32 bytes) |
| 6 | `31,124,0,0,15,337` | bootstrap counters (step,kbd,ptr,…) | confirmed values |
| 7+ | `"!x&:>8*wD..."` | env/UA probes, `"`-delimited, per-session char-substituted | confirmed shape |

Cross-check: the static bestbuy sample had seg[4]=`3555907` == `bm_sz[2]`=`3555907`
(exact). Live UPS shows the same invariant (sensor carries a nonce + `bm_sz` present).
→ **challenge-response confirmed on both a static sample and a live session.**

## 5. Sensor script obfuscation — characterized (543 KB, single line)

Not obfuscator.io (`_0x` array absent). It is a **custom Akamai obfuscator**:

| signature | count | technique |
|-----------|------:|-----------|
| `push`/`shift` | 478 | string-array rotation |
| `try{`/`catch(` | 224 | control-flow flattening (proxy try/catch) |
| `switch(` | 39 | dispatcher blocks |
| bitwise `^ >>> <<` | 218 | ARX-style mixing in the encode step |
| `charCodeAt` / `fromCharCode` | 8 / 2 | char transform |
| `\xNN` escapes | 1120 | string hiding |

Bootstrap head is an `Array.prototype.entries` polyfill IIFE, then the flattened
sensor body. Properties are set via bracket notation (`bmak[...]`), so a static
`bmak.x =` grep returns nothing — has to be traced through the dispatcher.

## 6. Verdict — UNCHANGED, now backed by LIVE evidence

**NOT APPLICABLE as a stateless generator.** Two blockers, both now proven on live
traffic (not just a static sample):

1. **Server-issued nonce** — `sensor_data` seg[4] must equal the `bm_sz` the server
   sets first (challenge-response). No `bm_sz` → no valid first payload.
2. **Accumulating internal state** — measured: call1 ≫ call2 on two independent
   sites. Offline replay drifts.

**Only viable path = extraction-replay solver:** fetch `bm_sz` → run
`bmak.get_telemetry()` in a live CloakBrowser → POST it → harvest the refreshed
`_abck` → replay `_abck` over HTTP bound to same IP + UA + TLS within TTL. That is a
`captcha-solver` concern (same shape as `cloudflare`/`awswaf`), **not** this stateless
generator. Harvest-only; no site hardcoded.

## 7. seg[7] transform — RESOLVED via dynamic alignment (not a static alphabet)

The remaining "deobfuscate the char-substitution alphabet" gap is now **closed with
a definitive negative result** — there is no static alphabet to recover. Method:
`dynamic_align.py` loaded att.com in two independent sessions and compared the
env-probe block seg[7] while holding the navigator identical.

| variable | session 1 | session 2 | equal? |
|----------|-----------|-----------|:------:|
| navigator (UA/platform/lang/HW/…) | Chrome 146 Win32 … | *same* | **yes** |
| SEED (seg[5]) | `NLtji/JrqYl+…PAlk=` | `NLtji/JrqYl+…PAlk=` | **yes** |
| server nonce (seg[4]) | `3228723` | `4405304` | **no** |
| **seg[7] env block** | `n,g!J{"w-g9"B"3g.*…` | `j^iJ2x"v9Wt".…` | **NO** |

**Conclusion:** navigator identical + SEED identical, yet seg[7] **still differs**.
Therefore seg[7] is NOT a static substitution alphabet keyed by SEED — the encode
folds in the **server nonce** (which is server-issued and changes every session:
3228723 → 4405304) plus per-call accumulation state. There is literally no fixed
alphabet to extract; the "alphabet" is a per-session function of a value the server
hands out. This is the same reason the whole target is NOT APPLICABLE, now proven
at the field level for seg[7] specifically rather than assumed.

## 8. Dispatcher / obfuscation internals (static confirmation)

Walked the 543 KB script far enough to confirm the machine, not to fully unroll it
(unrolling is verdict-irrelevant given §7):

- `JQ(a,b){return a.charCodeAt(b);}` — char access primitive.
- `SJ(){var xM=['R3','hD','WW','DM','dJ','fJ'];…}` — rotated string-array pool
  (elements drawn from a tiny alphabet `R F K Q 3 X r d V W Y`, a custom base-N).
- `zD(fv,l8){…switch(fv){case sM:…case MX:…}}` — **control-flow-flattened
  dispatcher**: 39 `switch` blocks + 224 try/catch proxies + 478 push/shift array
  rotations. State constants (`sM,kQ,wj,…`) resolve at runtime, so static grep for
  `bmak.x =` finds nothing (props set via bracket notation through the dispatcher).
- One `case OM` branch builds a value with `padStart` + `parseInt(…,radix)` +
  `Math.pow` — the numeric obfuscation of a probe result, consistent with the ARX
  mixing (218 bitwise ops) feeding the per-session encode.

## 9. Truly unknowable-from-client (hard stop, not a gap)

- `_abck[6]` and envelope `j=` are **server MACs** (secret key lives on Akamai's
  edge) — identical situation to GitHub's `secret_key_base`. Cannot be reversed from
  any amount of client-side analysis, by construction.
- seg[4] server nonce ORIGIN is server-side — the client only echoes it.

## 10. Final status — Akamai is FULLY characterized

Everything reversible from the client has been reversed and, crucially, the two
items that looked like "remaining gaps" are now positively classified:

- seg[7] alphabet → **proven non-static** (dynamic alignment), not a gap, a negative
  result. Nothing to extract.
- `_abck[6]`/`j=` MAC → **provably server-side**, unknowable by construction (not a
  gap in effort, a mathematical wall).

Verdict stands and is now airtight: **NOT APPLICABLE as a stateless generator**;
the only sound path is the extraction-replay solver (harvest `_abck` from a live
`get_telemetry()` session, replay same IP+UA+TLS within TTL). Artifacts:
`dynamic_align.py` + `dynamic_align_out/align.json`.
