"""
Akamai sensor_data seg[7] — dynamic transform characterization.

Instead of statically unpacking the 543KB control-flow-flattened dispatcher, we
use the LIVE browser (SEED is known = seg[5]) to answer the decisive question:
is the seg[7] env-probe encoding a STATIC alphabet, or a per-session SEED-keyed
transform?

Method:
  1. load an armed Akamai origin, grab telemetry T1 (has SEED_1, seg7_1).
  2. read the REAL navigator/env values in-page (ground truth).
  3. reload -> new session -> telemetry T2 (SEED_2, seg7_2) with the SAME
     navigator values.
  4. compare: if seg7 differs across sessions despite identical navigator ->
     transform is SEED-keyed (static alphabet recovery is meaningless).
"""
import asyncio, json, base64, sys
from pathlib import Path
from cloakbrowser import launch_async

TARGET = sys.argv[1] if len(sys.argv) > 1 else "https://www.att.com/"
OUT = Path(__file__).parent / "dynamic_align_out"
OUT.mkdir(exist_ok=True)

async def grab(ctx):
    page = await ctx.new_page()
    await page.goto(TARGET, wait_until="domcontentloaded", timeout=60000)
    await page.wait_for_timeout(5000)
    try:
        await page.mouse.move(100, 120); await page.mouse.move(280, 340)
        await page.mouse.wheel(0, 400)
    except Exception: pass
    await page.wait_for_timeout(3000)
    data = await page.evaluate("""() => {
        const out = {};
        try {
            out.tel = (typeof bmak!=='undefined' && bmak.get_telemetry) ? bmak.get_telemetry() : null;
        } catch(e){ out.tel_err = String(e); }
        // ground-truth env the sensor probes
        out.nav = {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            languages: (navigator.languages||[]).join(','),
            hardwareConcurrency: navigator.hardwareConcurrency,
            deviceMemory: navigator.deviceMemory,
            maxTouchPoints: navigator.maxTouchPoints,
            vendor: navigator.vendor,
            productSub: navigator.productSub,
            appVersion: navigator.appVersion,
            webdriver: navigator.webdriver,
        };
        out.scr = {w: screen.width, h: screen.height, cd: screen.colorDepth, dpr: devicePixelRatio};
        return out;
    }""")
    await page.close()
    return data

def parse_seg(tel):
    """extract sensor_data (b64) -> ;-split segments"""
    if not tel: return None
    # tel is the &&&-joined envelope; sensor_data is the 3rd section
    for part in tel.split("&&&"):
        if part.startswith("sensor_data="):
            b64 = part[len("sensor_data="):]
            raw = base64.b64decode(b64 + "="*(-len(b64)%4)).decode("latin-1")
            return raw.split(";")
    # or tel itself may already be the sensor string (version at head)
    if tel[:2] == "3;":
        return tel.split(";")
    return None

async def main():
    browser = await launch_async(headless=True)
    # two independent sessions
    c1 = await browser.new_context(); d1 = await grab(c1)
    c2 = await browser.new_context(); d2 = await grab(c2)

    s1 = parse_seg(d1.get("tel"))
    s2 = parse_seg(d2.get("tel"))
    res = {
        "target": TARGET,
        "nav_identical_across_sessions": d1.get("nav") == d2.get("nav"),
        "nav": d1.get("nav"),
        "seed_1": s1[5] if s1 and len(s1)>5 else None,
        "seed_2": s2[5] if s2 and len(s2)>5 else None,
        "seed_differs": (s1[5] != s2[5]) if (s1 and s2 and len(s1)>5 and len(s2)>5) else None,
        "seg7_1": s1[7][:200] if s1 and len(s1)>7 else None,
        "seg7_2": s2[7][:200] if s2 and len(s2)>7 else None,
        "seg7_differs": (s1[7] != s2[7]) if (s1 and s2 and len(s1)>7 and len(s2)>7) else None,
        "nonce_1": s1[4] if s1 and len(s1)>4 else None,
        "nonce_2": s2[4] if s2 and len(s2)>4 else None,
    }
    (OUT/"align.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    await browser.close()

asyncio.run(main())
