# Akamai Bot Manager — `sensor_data` v3 structure (deep-dive)

**Source:** live BestBuy capture (2026-07-14), cross-checked against the `_abck` /
`bm_sz` cookies in `RE_EVIDENCE.json`. Every "confirmed" row below was derived
from the actual captured bytes, not from documentation. Rows marked "inferred"
are structural guesses that still need a second capture / instrumented run to
prove.

## 1. Cookie: `_abck` (server verdict — split on `~`)

| idx | field | example | confirmed? |
|----|-------|---------|-----------|
| 0 | 32-hex session hash | `FC951C06...F33B` | confirmed (shape) |
| 1 | flag | `-1` | confirmed |
| 2 | **server challenge token** | `YAAQsXw2F5ZP...` | confirmed — same `YAAQ...` family appears in `bm_sz[1]` |
| 3 | flag | `-1` | confirmed |
| 4 | flag | `-1` | confirmed |
| 5 | epoch (sec) | `1783977952` → 2026-07-13 21:25:52 UTC | confirmed (decodes to capture time) |
| 6 | verify blob (base64) | `AAQAAAAG...` | confirmed (shape) — server MAC over the session |

`_abck` is **issued by the server** and updated after each accepted sensor POST.
The client never mints it; it only proves it earlier by POSTing a valid sensor.

## 2. Cookie: `bm_sz` (server nonce — split on `~`)

| idx | field | example | note |
|----|-------|---------|------|
| 0 | 32-hex id | `17DC8423...2C8F` | session id |
| 1 | **`YAAQ...` challenge** | `YAAQsXw2FzBP...` | server nonce the sensor must echo |
| 2 | int | `3555907` | **echoed verbatim into sensor_data seg[4]** |
| 3 | int | `4471089` | budget / expiry counter |

## 3. `sensor_data` v3 payload (split on `;`)

Header of a real POST body (`{"sensor_data":"..."}`, `text/plain`, to
`/<rand>/<rand>/rjw/<rand>/<rand>/<rand>`):

```
3;0;1;2048;3555907;RqWgxD1vFWNwVaegkdmhM2MkYqrsEq0ezKdrpBjq3IE=;158,0,0,2,4,0;"@9"4"z4R"mgF%...
```

| seg | value | meaning | confirmed? |
|----|-------|---------|-----------|
| 0 | `3` | sensor version | confirmed |
| 1 | `0` | const | confirmed (value) / inferred (meaning) |
| 2 | `1` | const | confirmed / inferred |
| 3 | `2048` | const (buffer size?) | confirmed / inferred |
| 4 | `3555907` | **server nonce echo — identical to `bm_sz[2]`** | **confirmed (cross-ref match)** |
| 5 | `RqWgxD1v...q3IE=` | **256-bit SEED** (b64 → 32 bytes) | confirmed (decodes to 32 bytes) |
| 6 | `158,0,0,2,4,0` | bootstrap counters (step, kbd, ptr, …) | confirmed (values) / inferred (labels) |
| 7 | `"@9"4"z4R"...` | env/UA probes, `"`-delimited, per-session char-substituted | confirmed (shape) |

### SEED (seg[5])
`base64 → 32 bytes = 46a5a0c43d6f1563 7055a7a091d9a133 632462aaec12ad1e cca76ba418eadc81`
A 256-bit client-chosen session key. It keys the char-substitution transform in
seg[7]+, so the **same navigator/UA yields different tokens per session**. This is
the structural opposite of DataDome (fixed constant seed `0x7d8479f9`), and is why
DataDome is byte-accurate offline while Akamai is not.

## 4. The two hard blockers (both empirically shown)

1. **Server-issued nonce (challenge-response).** seg[4] must equal `bm_sz[2]`, and
   the `YAAQ...` token in `bm_sz[1]` gates acceptance. You cannot build a valid
   first payload without first fetching `bm_sz` from the server. → offline
   generation impossible by construction.
2. **Accumulating internal state.** With `Date.now` / `performance.now` /
   `Math.random` frozen and zero user input, two back-to-back `bmak.get_telemetry()`
   calls still differ in size (6530 B vs 2694 B). An internal counter/ring buffer
   mutates per call, so even a "replay the same inputs" strategy drifts.

## 5. Verdict (unchanged, now with structural proof)

**NOT APPLICABLE as a stateless generator.** The only sound approach is stateful
**extraction-replay**: fetch `bm_sz` → run `bmak.get_telemetry()` inside a live
browser engine (CloakBrowser) → POST it → harvest the refreshed `_abck` → replay
`_abck` over HTTP bound to the **same IP + UA + TLS**, within TTL. That is a
solver/client concern (same shape as the `cloudflare` / `awswaf` harvesters), NOT
this stateless fingerprint generator. Harvest-only; no site is hardcoded.

## 6. What is still NOT reverse-engineered (honest gaps)

- The exact char-substitution alphabet in seg[7]+ (needs the deobfuscated
  `bmak` sensor source of a specific script version).
- The MAC algorithm behind `_abck[6]` (server-side; unknowable from client).
- Field-by-field map of the full body past the header (mouse/keyboard event
  encoding) — needs an instrumented `get_telemetry()` dump, not a single capture.
