#!/usr/bin/env python3
"""Deep-dive WHAT triggers Microsoft's 'Account creation has been blocked — unusual
activity'. The press-hold PoW is solved (_px3 rotates) but MSA's server-side risk
engine still blocks. This probes the risk signals:

  (1) risk/initialize + risk/verify RESPONSE bodies (the actual score/decision).
  (2) headless/automation leaks the DFP (fpt.live.com) + sensor VM can read:
      navigator.webdriver, plugins, languages, hardwareConcurrency, deviceMemory,
      WebGL vendor/renderer (SwiftShader = headless tell), permissions, chrome obj,
      CDP artifacts (window.cdc_, $cdc_), notification permission mismatch.
  (3) the CreateAccount RESPONSE body (the block reason/code).

Drives to the gate, captures all of the above. Standalone CloakBrowser headless.
"""
import asyncio
import json
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def pick(p, trig, idx):
    for _ in range(3):
        try:
            await p.click(trig, timeout=3000)
        except Exception:
            await asyncio.sleep(0.5); continue
        o = p.locator('[role="option"]')
        try:
            await o.first.wait_for(state="visible", timeout=3000)
        except Exception:
            await asyncio.sleep(0.5); continue
        try:
            await o.nth(min(idx, await o.count() - 1)).click(timeout=2500)
            return True
        except Exception:
            await asyncio.sleep(0.5); continue
    return False


async def main():
    from cloakbrowser import launch_async
    cap = {"risk": [], "create": [], "leaks": {}}

    b = await launch_async(headless=True)
    ctx = await b.new_context()
    p = await ctx.new_page()

    async def on_resp(resp):
        u = resp.url
        if "/risk/initialize" in u or "/risk/verify" in u:
            try:
                cap["risk"].append({"url": u.split("?")[0][-60:], "status": resp.status,
                                    "body": (await resp.text())[:500]})
            except Exception:
                pass
        elif "CreateAccount" in u:
            try:
                cap["create"].append({"status": resp.status, "body": (await resp.text())[:600]})
            except Exception:
                pass

    p.on("response", lambda r: asyncio.create_task(on_resp(r)))

    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    # signup.live.com does an OAuth redirect right after load — wait for it to settle
    await asyncio.sleep(6)
    try:
        await p.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass

    # capture automation/headless leaks (after redirect settles)
    async def grab_leaks():
        return await p.evaluate(r"""() => {
      const gl = (() => { try {
        const c = document.createElement('canvas').getContext('webgl');
        const dbg = c.getExtension('WEBGL_debug_renderer_info');
        return {vendor: c.getParameter(dbg.UNMASKED_VENDOR_WEBGL),
                renderer: c.getParameter(dbg.UNMASKED_RENDERER_WEBGL)};
      } catch(e) { return {err: String(e)}; }})();
      return {
        webdriver: navigator.webdriver,
        plugins: navigator.plugins.length,
        languages: navigator.languages,
        hardwareConcurrency: navigator.hardwareConcurrency,
        deviceMemory: navigator.deviceMemory,
        platform: navigator.platform,
        userAgent: navigator.userAgent,
        webgl_vendor: gl.vendor, webgl_renderer: gl.renderer,
        hasChrome: !!window.chrome,
        cdc: Object.keys(window).filter(k => /cdc_|\$cdc/.test(k)),
        permissions_notif: (typeof Notification !== 'undefined') ? Notification.permission : 'n/a',
        maxTouchPoints: navigator.maxTouchPoints,
        connection: navigator.connection ? navigator.connection.effectiveType : null,
        outerDims: [window.outerWidth, window.outerHeight],
        innerDims: [window.innerWidth, window.innerHeight],
      };
    }""")

    for _ in range(3):
        try:
            cap["leaks"] = await grab_leaks(); break
        except Exception as e:
            cap["leaks"] = {"eval_error": str(e)[:80]}
            await asyncio.sleep(2)

    await fill(p, ['input[type="email"]'], tag); await nxt(p); await asyncio.sleep(3)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await fill(p, ['input[type="password"]'], pw); await nxt(p); await asyncio.sleep(4)
    await pick(p, '#BirthMonthDropdown', 5); await pick(p, '#BirthDayDropdown', 10)
    await fill(p, ['input[name="BirthYear"]', '[aria-label="Birth year"]'], "1995")
    await nxt(p); await asyncio.sleep(3)
    await fill(p, ['#firstNameInput'], "Nathan"); await fill(p, ['#lastNameInput'], "Kusumo")
    await nxt(p); await asyncio.sleep(7)

    # press-hold if present
    box = await p.evaluate(r"""() => {
      const f=[...document.querySelectorAll('iframe')].find(f=>/hsprotect/i.test(f.src||'')&&f.getBoundingClientRect().width>50);
      if(!f) return null; const r=f.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2};}""")
    if box:
        await p.mouse.move(box["x"], box["y"]); await p.mouse.down()
        for _ in range(16):
            await p.mouse.move(box["x"] + random.uniform(-1, 1), box["y"] + random.uniform(-1, 1))
            await asyncio.sleep(0.5)
        await p.mouse.up(); await asyncio.sleep(5)
    cap["challenge_shown"] = bool(box)

    cap["final"] = await p.evaluate(r"""() => ({
      heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
      body:(document.body.innerText||'').slice(0,200)})""")

    (OUT / "risk_probe.json").write_text(json.dumps(cap, indent=2))
    print("=== HEADLESS / AUTOMATION LEAKS ===")
    for k, v in cap["leaks"].items():
        print(f"  {k}: {v}")
    print("\n=== risk/initialize + risk/verify responses ===")
    for r in cap["risk"]:
        print(f"  {r['status']} {r['url']}")
        print(f"    {r['body'][:200]}")
    print("\n=== CreateAccount responses ===")
    for r in cap["create"]:
        print(f"  {r['status']}: {r['body'][:300]}")
    print("\n=== final state ===")
    print(" ", cap["final"]["heading"][:50], "|", cap["final"]["body"][:100].replace(chr(10), " "))
    await b.close()


if __name__ == "__main__":
    asyncio.run(main())
