#!/usr/bin/env python3
"""Capture the Outlook (signup.live.com) registration network flow to confirm the
anti-bot layer order + payloads that static ServerData analysis revealed:

  - Arkose FunCaptcha (iframe.arkoselabs.com/B7D8911C-...)
  - HUMAN Security (hsprotect.net, appId PXzC5j78di)
  - MSA Risk API (/api/v1.0/risk/initialize + /risk/verify)
  - DFP device fingerprint (fpt.live.com)
  - HIP visual fallback (client.prod.repmap.microsoft.com/GetHIP)
  - /API/CheckAvailableSigninNames + /API/CreateAccount (apiCanary-gated)

Drives the signup form (email + password + name + DOB) to trigger the captcha
layer, recording every request to the anti-bot hosts + their payload shapes.
Standalone CloakBrowser script.
"""
import asyncio
import json
import random
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = "https://signup.live.com/signup"

_HOSTS = ("arkoselabs.com", "hsprotect.net", "fpt.live.com", "repmap.microsoft.com",
          "/risk/initialize", "/risk/verify", "CheckAvailableSigninNames",
          "CreateAccount", "GetCredentialType", "funcaptcha")


async def main():
    from cloakbrowser import launch_async

    cap = {"target": SIGNUP, "antibot_reqs": [], "arkose": {}, "order": []}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    def hit(u):
        return next((h for h in _HOSTS if h in u), None)

    def on_req(r):
        u = r.url
        h = hit(u)
        if h:
            e = {"host": h, "url": u[:150], "method": r.method, "rtype": r.resource_type}
            if r.method == "POST":
                try:
                    pd = r.post_data or ""
                    e["post_len"] = len(pd)
                    e["post_head"] = pd[:160]
                except Exception:
                    pass
            cap["antibot_reqs"].append(e)
            cap["order"].append(h)

    page.on("request", on_req)

    print(f"[*] navigating {SIGNUP}", flush=True)
    try:
        await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)
    await asyncio.sleep(4)

    tag = random.randint(100000, 999999)
    # EASI flow: uses your own email (any address) — try filling the email field.
    async def fill(sels, val):
        for s in sels:
            try:
                await page.fill(s, val, timeout=3000)
                return True
            except Exception:
                continue
        return False

    filled = await fill(
        ['input[name="MemberName"]', '#MemberName', 'input[type="email"]',
         'input[name="Email"]', '#liveEmail'],
        f"waguri.re{tag}@example.com")
    print(f"[*] email filled: {filled}", flush=True)

    # Click Next to advance to password / captcha.
    for _ in range(2):
        for s in ['#iSignupAction', 'button[type=submit]', 'input[type=submit]',
                  '#nextButton', 'button:has-text("Next")']:
            try:
                await page.click(s, timeout=2500)
                break
            except Exception:
                continue
        await asyncio.sleep(3)

    await asyncio.sleep(6)  # let arkose/human/risk fire

    # Grab any Arkose iframe public key / config present in the DOM.
    try:
        cap["arkose"] = await page.evaluate(r"""() => {
          const out = {};
          const ifr = document.querySelector('iframe[src*="arkoselabs"]');
          if (ifr) out.arkose_iframe = ifr.src;
          const h = document.querySelector('iframe[src*="hsprotect"]');
          if (h) out.human_iframe = h.src;
          if (window.fpConfig) out.hasFpConfig = true;
          return out;
        }""")
    except Exception as e:
        cap["arkose_err"] = str(e)

    (OUT / "network.json").write_text(json.dumps(cap, indent=2))
    print(f"[+] antibot_reqs={len(cap['antibot_reqs'])} order={cap['order']}", flush=True)
    print(f"[+] arkose/human: {json.dumps(cap['arkose'])[:200]}", flush=True)
    for r in cap["antibot_reqs"][:25]:
        print(f"    {r['method']} [{r['host']}] {r['url'][:95]}", flush=True)

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
