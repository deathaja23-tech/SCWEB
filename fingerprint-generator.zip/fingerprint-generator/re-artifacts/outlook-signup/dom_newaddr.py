#!/usr/bin/env python3
"""Inspect the signup.live.com DOM for the 'Get a new email address' flow so the
solver targets the right selectors (username field, @outlook.com/@hotmail.com
domain dropdown, the toggle link) instead of guessing. Standalone CloakBrowser.
"""
import asyncio
import json
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = "https://signup.live.com/signup"


async def main():
    from cloakbrowser import launch_async
    dump = {"toggle": None, "username_field": None, "domain_options": [],
            "before": {}, "after": {}}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()
    try:
        await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print("goto:", e)
    await asyncio.sleep(3)

    # snapshot initial inputs/links
    dump["before"] = await page.evaluate(r"""() => ({
      inputs: [...document.querySelectorAll('input')].map(i => ({name:i.name,id:i.id,type:i.type,ph:i.placeholder})),
      links: [...document.querySelectorAll('a,button,span[role=button],div[role=button]')]
               .map(a => (a.textContent||'').trim()).filter(t => /new email|outlook|hotmail|get a new/i.test(t)),
    })""")

    # click "Get a new email address"
    clicked = False
    for sel in ['text=Get a new email address', 'a:has-text("new email")',
                '#liveSwitch', '[data-bind*="switchToLive"]',
                'text=Get a new email']:
        try:
            await page.click(sel, timeout=3000)
            clicked = True
            dump["toggle"] = sel
            break
        except Exception:
            continue
    await asyncio.sleep(2)

    # snapshot after toggle: username field + domain dropdown
    dump["after"] = await page.evaluate(r"""() => ({
      inputs: [...document.querySelectorAll('input')].map(i => ({name:i.name,id:i.id,type:i.type,ph:i.placeholder})),
      selects: [...document.querySelectorAll('select')].map(s => ({name:s.name,id:s.id,
                 options:[...s.options].map(o=>o.value+'='+o.textContent)})),
    })""")
    dump["clicked"] = clicked

    (OUT / "dom_newaddr.json").write_text(json.dumps(dump, indent=2))
    print("clicked toggle:", clicked, "via", dump["toggle"])
    print("before links:", dump["before"].get("links"))
    print("after inputs:", json.dumps(dump["after"].get("inputs"))[:400])
    print("after selects:", json.dumps(dump["after"].get("selects"))[:400])
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
