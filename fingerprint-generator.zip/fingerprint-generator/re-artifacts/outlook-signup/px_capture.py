#!/usr/bin/env python3
"""Deep-dive the PerimeterX/HUMAN 'Press & Hold' gate at Outlook signup: capture the
FULL network cycle around the challenge to learn (a) how it's solved and (b) whether
the resulting token is replayable.

Drives to the press-hold gate, then records every hsprotect.net request+RESPONSE
(collector /api/v2/msft, the challenge init, the token/cookie emitted), plus what
gets attached to the CreateAccount POST. Also dumps the _px* cookies before/after.

Standalone CloakBrowser headless.
"""
import asyncio
import json
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def pick(p, trig, idx):
    try:
        await p.click(trig, timeout=3000)
    except Exception:
        return
    o = p.locator('[role="option"]')
    try:
        await o.first.wait_for(state="visible", timeout=3000)
    except Exception:
        return
    n = await o.count()
    await o.nth(min(idx, n - 1)).click(timeout=2500)
    await asyncio.sleep(0.3)


async def main():
    from cloakbrowser import launch_async
    cap = {"px_responses": [], "create_reqs": [], "px_cookies_pre": [],
           "px_cookies_post": [], "challenge_urls": []}

    b = await launch_async(headless=True)
    ctx = await b.new_context()
    p = await ctx.new_page()

    async def on_resp(resp):
        u = resp.url
        if "hsprotect.net" in u or "perimeterx" in u or "px-cdn" in u:
            e = {"url": u[:140], "status": resp.status, "method": resp.request.method}
            try:
                ct = resp.headers.get("content-type", "")
                if "json" in ct or resp.request.method == "POST":
                    body = await resp.text()
                    e["body_head"] = body[:400]
                    e["body_len"] = len(body)
                sc = resp.headers.get("set-cookie", "")
                if sc:
                    e["set_cookie"] = sc[:200]
            except Exception:
                pass
            cap["px_responses"].append(e)
            if "captcha" in u.lower() or "challenge" in u.lower():
                cap["challenge_urls"].append(u[:140])

    def on_req(r):
        if "CreateAccount" in r.url:
            try:
                pd = r.post_data or ""
            except Exception:
                pd = ""
            cap["create_reqs"].append({"url": r.url[:120], "len": len(pd),
                                       "head": pd[:400]})

    p.on("response", lambda r: asyncio.create_task(on_resp(r)))
    p.on("request", on_req)

    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000); await asyncio.sleep(3)
    await fill(p, ['input[type="email"]'], tag); await nxt(p); await asyncio.sleep(3)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await fill(p, ['input[type="password"]'], pw); await nxt(p); await asyncio.sleep(4)
    await pick(p, '#BirthMonthDropdown', 5); await pick(p, '#BirthDayDropdown', 10)
    await fill(p, ['#BirthYear', 'input[name="BirthYear"]'], "1995"); await nxt(p); await asyncio.sleep(3)
    await fill(p, ['#firstNameInput'], "Nathan"); await fill(p, ['#lastNameInput'], "Kusumo")

    # snapshot _px cookies before the challenge
    cap["px_cookies_pre"] = [c["name"] for c in await ctx.cookies() if "px" in c["name"].lower() or c["name"].startswith("_px")]
    await nxt(p); await asyncio.sleep(8)  # challenge should render now

    # what challenge is present? dump the press-hold element + iframe
    cap["challenge_dom"] = await p.evaluate(r"""() => {
      const out = {};
      const ph = [...document.querySelectorAll('*')].find(e => /press *(&|and) *hold/i.test(e.textContent||'') && (e.textContent||'').length<80);
      out.press_hold_text = ph ? (ph.textContent||'').trim().slice(0,60) : null;
      const ifr = [...document.querySelectorAll('iframe')].map(f=>({src:(f.src||'').slice(0,90),
        w:f.getBoundingClientRect().width, h:f.getBoundingClientRect().height}));
      out.iframes = ifr;
      // the press-hold button is often a div/button inside the hsprotect iframe or a #px-captcha
      out.px_captcha = !!document.querySelector('#px-captcha, [id*="px-captcha"], [class*="px-captcha"]');
      return out;
    }""")

    cap["px_cookies_post"] = [{"name": c["name"], "len": len(c.get("value", "")),
                               "domain": c.get("domain")}
                              for c in await ctx.cookies()
                              if "px" in c["name"].lower() or c["name"].startswith("_px")]

    await p.screenshot(path=str(OUT / "px_gate.png"))
    (OUT / "px_capture.json").write_text(json.dumps(cap, indent=2))

    print("=== PerimeterX responses ===")
    for r in cap["px_responses"][-12:]:
        sc = " +setcookie" if "set_cookie" in r else ""
        print(f"  {r['status']} {r['method']} {r['url'][:80]}{sc}")
    print("=== challenge DOM ===")
    print("  " + json.dumps(cap["challenge_dom"])[:400])
    print("=== _px cookies pre:", cap["px_cookies_pre"])
    print("=== _px cookies post:", [c["name"] for c in cap["px_cookies_post"]])
    print("=== CreateAccount reqs:", len(cap["create_reqs"]))
    await b.close()


if __name__ == "__main__":
    asyncio.run(main())
