#!/usr/bin/env python3
"""Find the REAL new-@outlook.com-mailbox entry: start from outlook.com's 'Create
free account' CTA (not signup.live.com/signup which is EASI-only now). Follow it and
report where the MemberName field + @outlook.com/@hotmail.com domain dropdown lives.
Standalone CloakBrowser.
"""
import asyncio
import json
from pathlib import Path

OUT = Path(__file__).parent
ENTRIES = [
    "https://outlook.com/",
    "https://www.microsoft.com/en-us/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook",
]


async def scan(page):
    return await page.evaluate(r"""() => ({
      inputs:[...document.querySelectorAll('input')].map(i=>({name:i.name,id:i.id,type:i.type,ph:i.placeholder})),
      selects:[...document.querySelectorAll('select')].map(s=>({name:s.name,id:s.id,
        opts:[...s.options].map(o=>o.textContent).slice(0,8)})),
      final:location.href, title:document.title,
    })""")


async def main():
    from cloakbrowser import launch_async
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    out = []
    for entry in ENTRIES:
        page = await ctx.new_page()
        try:
            await page.goto(entry, wait_until="domcontentloaded", timeout=40000)
        except Exception as e:
            out.append({"entry": entry, "error": str(e)[:80]}); await page.close(); continue
        await asyncio.sleep(3)
        # click a "Create free account" / "Create account" CTA
        clicked = None
        for sel in ['text=Create free account', 'a:has-text("Create free account")',
                    'text=Create account', 'a:has-text("Sign up for free")',
                    'text=Sign up for free']:
            try:
                await page.click(sel, timeout=3000); clicked = sel; break
            except Exception:
                continue
        await asyncio.sleep(4)
        d = await scan(page)
        d.update({"entry": entry, "clicked_cta": clicked})
        # if a MemberName + domain select now exists, this is the new-mailbox flow
        d["is_new_mailbox_flow"] = any(
            (i.get("name") == "MemberName") for i in d["inputs"]) or bool(d["selects"])
        out.append(d)
        print(f"entry={entry[:40]} clicked={clicked} final={d['final'][:55]}")
        print(f"  inputs={json.dumps(d['inputs'])[:250]}")
        print(f"  selects={json.dumps(d['selects'])[:200]}")
        print(f"  NEW_MAILBOX_FLOW={d['is_new_mailbox_flow']}")
        await page.close()
    (OUT / "dom_probe5.json").write_text(json.dumps(out, indent=2))
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
