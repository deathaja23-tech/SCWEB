#!/usr/bin/env python3
"""The new-outlook-mailbox flow is likely triggered by TYPING a bare username (no
@domain) into the email field — Microsoft then reveals a domain dropdown / 'use
@outlook.com' hint. Type a bare handle, then re-scan for a domain select + hint.
Standalone CloakBrowser.
"""
import asyncio
import json
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = "https://signup.live.com/signup?lic=1"


async def main():
    from cloakbrowser import launch_async
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()
    try:
        await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print("goto:", e)
    await asyncio.sleep(3)

    handle = "wg" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
    dump = {"handle": handle, "stages": {}}

    # locate email field
    sel = None
    for s in ['input[name="MemberName"]', '#MemberName', 'input[type="email"]',
              'input[name="Email"]', '#floatingLabelInput4', 'input[type="text"]']:
        if await page.query_selector(s):
            sel = s
            break
    dump["email_selector"] = sel
    if not sel:
        print("no email field"); await browser.close(); return

    # type a BARE username (no @)
    await page.fill(sel, handle)
    await asyncio.sleep(2)
    dump["stages"]["after_type_bare"] = await page.evaluate(r"""() => ({
      selects:[...document.querySelectorAll('select')].map(s=>({name:s.name,id:s.id,
        opts:[...s.options].map(o=>o.textContent)})),
      hints:[...document.querySelectorAll('*')].map(e=>(e.textContent||'').trim())
        .filter(t=>/outlook\.com|hotmail\.com|use .*instead|new email/i.test(t)&&t.length<60).slice(0,5),
      buttons:[...document.querySelectorAll('a,button,[role=button]')].map(b=>(b.textContent||'').trim())
        .filter(t=>/outlook|hotmail|new email|get a new/i.test(t)&&t.length<50),
    })""")

    # click Next to see if a domain choice appears on the next screen
    for s in ['#iSignupAction', 'button[type=submit]', '#nextButton',
              'button:has-text("Next")']:
        try:
            await page.click(s, timeout=2500); break
        except Exception:
            continue
    await asyncio.sleep(3)
    dump["stages"]["after_next"] = await page.evaluate(r"""() => ({
      selects:[...document.querySelectorAll('select')].map(s=>({name:s.name,id:s.id,
        opts:[...s.options].map(o=>o.textContent)})),
      inputs:[...document.querySelectorAll('input')].map(i=>({name:i.name,id:i.id,type:i.type})),
      bodytext:document.body.innerText.slice(0,300),
      final:location.href,
    })""")

    (OUT / "dom_probe4.json").write_text(json.dumps(dump, indent=2))
    print("email selector:", sel, "| handle:", handle)
    print("--- after typing bare username ---")
    print(json.dumps(dump["stages"]["after_type_bare"], indent=1)[:500])
    print("--- after Next ---")
    print("selects:", json.dumps(dump["stages"]["after_next"]["selects"])[:300])
    print("bodytext:", dump["stages"]["after_next"]["bodytext"][:200])
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
