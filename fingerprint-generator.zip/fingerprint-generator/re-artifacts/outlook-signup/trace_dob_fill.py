#!/usr/bin/env python3
"""Replicate the solver's DOB step EXACTLY and screenshot after each pick to see
whether the Fluent dropdown selection actually lands. Prints the combobox текст
after selecting. Standalone CloakBrowser headless.
"""
import asyncio
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def pick(p, trigger, idx):
    try:
        await p.click(trigger, timeout=3000)
    except Exception as e:
        print(f"  click {trigger} FAIL: {str(e)[:50]}"); return
    opts = p.locator('[role="option"]')
    try:
        await opts.first.wait_for(state="visible", timeout=3000)
    except Exception:
        print(f"  {trigger}: options never visible"); return
    n = await opts.count()
    print(f"  {trigger}: {n} options")
    await opts.nth(min(idx, n - 1)).click(timeout=2500)
    await asyncio.sleep(0.4)


async def main():
    from cloakbrowser import launch_async
    b = await launch_async(headless=True); ctx = await b.new_context(); p = await ctx.new_page()
    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000); await asyncio.sleep(3)
    await fill(p, ['input[type="email"]'], tag); await nxt(p); await asyncio.sleep(3)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await fill(p, ['input[type="password"]'], pw); await nxt(p); await asyncio.sleep(4)

    print("heading:", (await p.evaluate("()=>(document.querySelector('h1,[role=heading]')||{}).textContent||''"))[:40])
    print("=== picking month ===")
    await pick(p, '#BirthMonthDropdown', 5)
    print("=== picking day ===")
    await pick(p, '#BirthDayDropdown', 10)
    print("=== filling year ===")
    await fill(p, ['#BirthYear', 'input[name="BirthYear"]'], "1995")

    # read back the combobox display text to confirm selection stuck
    state = await p.evaluate(r"""() => ({
      month:(document.querySelector('#BirthMonthDropdown')||{}).textContent||'',
      day:(document.querySelector('#BirthDayDropdown')||{}).textContent||'',
      year:(document.querySelector('#BirthYear')||{}).value||'',
    })""")
    print("SELECTED ->", state)
    await p.screenshot(path=str(OUT / "dob_filled.png"))

    await nxt(p); await asyncio.sleep(4)
    after = await p.evaluate(r"""() => ({
      heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
      inputs:[...document.querySelectorAll('input')].map(i=>i.name||i.id),
      body:(document.body.innerText||'').slice(0,150)
    })""")
    print("=== after Next ===")
    print("  heading:", after["heading"][:40])
    print("  inputs:", after["inputs"])
    print("  body:", after["body"][:120].replace("\n", " | "))
    await p.screenshot(path=str(OUT / "after_dob_next.png"))
    await b.close()


if __name__ == "__main__":
    asyncio.run(main())
