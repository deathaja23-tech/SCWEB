#!/usr/bin/env python3
"""Diagnose WHY the press-hold gesture actuates but CreateAccount never fires. Two
hypotheses: (A) the mouse events don't route INTO the cross-origin hsprotect OOPIF
(so PerimeterX never sees the hold), or (B) the hold is too short for the PoW Worker.

Drive to the gate, snapshot _px3 before, do a LONG hold (12s) with CDP-level mouse,
then check: did _px3 change? did the button show a success/progress state? did the
form advance? Standalone CloakBrowser headless.
"""
import asyncio
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def pick(p, trig, idx):
    for attempt in range(3):
        try:
            await p.click(trig, timeout=3000)
        except Exception:
            await asyncio.sleep(0.5); continue
        o = p.locator('[role="option"]')
        try:
            await o.first.wait_for(state="visible", timeout=3000)
        except Exception:
            await asyncio.sleep(0.5); continue
        try:
            await o.nth(min(idx, await o.count() - 1)).click(timeout=2500)
            await asyncio.sleep(0.4)
            return True
        except Exception:
            await asyncio.sleep(0.5); continue
    return False


async def px3(ctx):
    for c in await ctx.cookies():
        if c["name"] == "_px3":
            return c["value"][:24]
    return None


async def main():
    from cloakbrowser import launch_async
    b = await launch_async(headless=True); ctx = await b.new_context(); p = await ctx.new_page()
    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000); await asyncio.sleep(3)
    await fill(p, ['input[type="email"]'], tag); await nxt(p); await asyncio.sleep(3)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await fill(p, ['input[type="password"]'], pw); await nxt(p); await asyncio.sleep(4)
    m_ok = await pick(p, '#BirthMonthDropdown', 5)
    d_ok = await pick(p, '#BirthDayDropdown', 10)
    y_ok = await fill(p, ['input[name="BirthYear"]', '[aria-label="Birth year"]', '#BirthYear'], "1995")
    print("year fill ok:", y_ok)
    dob = await p.evaluate(r"""() => ({
      m:(document.querySelector('#BirthMonthDropdown')||{}).textContent||'',
      d:(document.querySelector('#BirthDayDropdown')||{}).textContent||'',
      y:(document.querySelector('#BirthYear')||{}).value||''})""")
    print(f"DOB set: month_ok={m_ok} day_ok={d_ok} -> {dob}")
    await nxt(p); await asyncio.sleep(3)
    await fill(p, ['#firstNameInput'], "Nathan"); await fill(p, ['#lastNameInput'], "Kusumo")
    await nxt(p); await asyncio.sleep(7)

    # Find the hsprotect iframe + its frame handle (to check button INSIDE it)
    box = await p.evaluate(r"""() => {
      const f = [...document.querySelectorAll('iframe')].find(f =>
        /hsprotect/i.test(f.src||'') && f.getBoundingClientRect().width > 50);
      if (!f) return null;
      const r = f.getBoundingClientRect();
      return {x:r.x+r.width/2, y:r.y+r.height/2, w:r.width, h:r.height, src:f.src};
    }""")
    print("iframe box:", box)
    if not box:
        where = await p.evaluate(r"""() => ({
          heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
          inputs:[...document.querySelectorAll('input')].map(i=>i.name||i.id),
          body:(document.body.innerText||'').slice(0,150),
          allIframes:[...document.querySelectorAll('iframe')].map(f=>({src:(f.src||'').slice(0,60),w:f.getBoundingClientRect().width}))
        })""")
        print("NO press-hold iframe. WHERE:", where["heading"][:40])
        print("  inputs:", where["inputs"])
        print("  body:", where["body"][:120].replace(chr(10), " | "))
        print("  iframes:", where["allIframes"])
        await p.screenshot(path=str(OUT / "px_noiframe.png"))
        await b.close(); return

    px3_before = await px3(ctx)
    print("_px3 before:", px3_before)

    # try to read the button text INSIDE the cross-origin frame via frame handle
    ph_frame = None
    for fr in p.frames:
        if "hsprotect" in (fr.url or ""):
            ph_frame = fr; break
    if ph_frame:
        try:
            inner = await ph_frame.evaluate(r"""() => {
              const b = document.querySelector('[id*="px-captcha"],button,[role=button],div');
              return {text:(document.body.innerText||'').slice(0,60),
                      hasButton: !!document.querySelector('[id*="px"],button,[role=button]')};
            }""")
            print("INSIDE frame:", inner)
        except Exception as e:
            print("frame eval (cross-origin OOPIF, expected):", str(e)[:60])

    # LONG press-hold (12s) at the iframe center via top-level mouse (CDP input)
    x, y = box["x"], box["y"]
    print(f"pressing at ({x:.0f},{y:.0f}), holding 12s...")
    await p.mouse.move(x, y); await asyncio.sleep(0.2)
    await p.mouse.down()
    for i in range(24):
        await p.mouse.move(x + random.uniform(-1, 1), y + random.uniform(-1, 1))
        await asyncio.sleep(0.5)
    await p.mouse.up()
    print("released after 12s")
    await asyncio.sleep(4)

    px3_after = await px3(ctx)
    print("_px3 after: ", px3_after)
    print("_px3 CHANGED:", px3_before != px3_after)

    state = await p.evaluate(r"""() => {
      const f = [...document.querySelectorAll('iframe')].find(f=>/hsprotect/i.test(f.src||'') && f.getBoundingClientRect().width>50);
      return {still_challenge: !!f,
              heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
              body:(document.body.innerText||'').slice(0,120)};
    }""")
    print("after-hold state:", state)
    await p.screenshot(path=str(OUT / "px_after_hold.png"))
    await b.close()


if __name__ == "__main__":
    asyncio.run(main())
