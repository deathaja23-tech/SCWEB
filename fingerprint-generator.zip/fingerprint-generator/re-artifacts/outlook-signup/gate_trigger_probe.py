#!/usr/bin/env python3
"""Can the PerimeterX press-hold gate be triggered MORE DIRECTLY than the full
4-step Outlook form journey? Goal: find the cleanest way for a solver to reach a
harvestable gate, so the solver stays generic (ideally just goto(url) or a minimal
trigger) instead of hardcoding Outlook signup form-filling.

Tests three hypotheses:
  H1) Load iframe.hsprotect.net/index.html?app_id=PXzC5j78di DIRECTLY (standalone).
      -> if it renders a press-hold + mints _px3, solver never touches the form.
  H2) Minimal form depth: at which step does the gate first appear? (username only?
      password? DOB? name?) -> tells us the true minimum navigation.
  H3) Is there a standalone PerimeterX captcha page (captcha.hsprotect.net) that
      renders the challenge without MSA's form at all?

Standalone CloakBrowser headless. Read-only probes, no account creation.
"""
import asyncio
import json
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
APP_ID = "PXzC5j78di"
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def gate_state(page):
    for _ in range(3):
        try:
            return await _gate_eval(page)
        except Exception:
            await asyncio.sleep(2)
    return {"gate": False, "iframe_w": 0, "iframe_src": None, "heading": ""}


async def _gate_eval(page):
    return await page.evaluate(r"""() => {
      const f = [...document.querySelectorAll('iframe')].find(f =>
        /hsprotect|perimeterx|px-captcha/i.test(f.src||'') &&
        f.getBoundingClientRect().width > 50);
      const t = (document.body.innerText||'').toLowerCase();
      return {
        gate: !!f && /press *(&|and) *hold|prove you're human/.test(t),
        iframe_w: f ? f.getBoundingClientRect().width : 0,
        iframe_src: f ? (f.src||'').slice(0,80) : null,
        heading: (document.querySelector('h1,[role=heading]')||{}).textContent||'',
      };
    }""")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def pick(p, trig, idx):
    for _ in range(2):
        try:
            await p.click(trig, timeout=3000)
        except Exception:
            await asyncio.sleep(0.4); continue
        o = p.locator('[role="option"]')
        try:
            await o.first.wait_for(state="visible", timeout=2500)
            await o.nth(min(idx, await o.count() - 1)).click(timeout=2500)
            return True
        except Exception:
            await asyncio.sleep(0.4)
    return False


async def main():
    from cloakbrowser import launch_async
    results = {}
    browser = await launch_async(headless=True)

    # ── H1: direct hsprotect iframe URL ──
    ctx1 = await browser.new_context(); p1 = await ctx1.new_page()
    for url in [f"https://iframe.hsprotect.net/index.html?app_id={APP_ID}",
                f"https://captcha.hsprotect.net/{APP_ID}/captcha.html",
                f"https://captcha.hsprotect.net/{APP_ID}/"]:
        try:
            r = await p1.goto(url, wait_until="domcontentloaded", timeout=20000)
            await asyncio.sleep(3)
            body = (await p1.evaluate("() => (document.body.innerText||'').slice(0,80)"))
            has_hold = "hold" in body.lower() or "human" in body.lower()
            results.setdefault("H1_direct_iframe", []).append(
                {"url": url, "status": r.status if r else None,
                 "press_hold_text": has_hold, "body": body.replace("\n", " ")[:70]})
        except Exception as e:
            results.setdefault("H1_direct_iframe", []).append({"url": url, "error": str(e)[:60]})
    await ctx1.close()

    # ── H2: minimal form depth — check gate after each step ──
    ctx2 = await browser.new_context(); p2 = await ctx2.new_page()
    depth = {}
    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await p2.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    await asyncio.sleep(6)  # signup.live.com OAuth redirect settles
    try:
        await p2.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    depth["0_landing"] = (await gate_state(p2))["gate"]
    await fill(p2, ['input[type="email"]'], tag); await nxt(p2); await asyncio.sleep(3)
    depth["1_after_username"] = (await gate_state(p2))["gate"]
    await fill(p2, ['input[type="password"]'], pw); await nxt(p2); await asyncio.sleep(3)
    depth["2_after_password"] = (await gate_state(p2))["gate"]
    await pick(p2, '#BirthMonthDropdown', 5); await pick(p2, '#BirthDayDropdown', 10)
    await fill(p2, ['input[name="BirthYear"]', '[aria-label="Birth year"]'], "1995")
    await nxt(p2); await asyncio.sleep(3)
    depth["3_after_dob"] = (await gate_state(p2))["gate"]
    await fill(p2, ['#firstNameInput'], "Nathan"); await fill(p2, ['#lastNameInput'], "Kusumo")
    await nxt(p2); await asyncio.sleep(6)
    depth["4_after_name"] = (await gate_state(p2))["gate"]
    results["H2_form_depth"] = depth
    results["H2_final_state"] = await gate_state(p2)
    await ctx2.close()

    (OUT / "gate_trigger_probe.json").write_text(json.dumps(results, indent=2))
    print("=== H1: direct hsprotect/captcha iframe URLs ===")
    for r in results.get("H1_direct_iframe", []):
        print(f"  {r}")
    print("\n=== H2: at which form step does the gate first appear? ===")
    for k, v in results["H2_form_depth"].items():
        print(f"  {k}: gate={'YES' if v else 'no'}")
    print("  final:", results["H2_final_state"])
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
