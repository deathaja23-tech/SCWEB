#!/usr/bin/env python3
"""Probe signup.live.com for ALL clickable text + the new-address toggle, since the
default page only shows an email field. Dump every link/button label + any element
mentioning outlook/hotmail/new. Standalone CloakBrowser.
"""
import asyncio
import json
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = "https://signup.live.com/signup"


async def main():
    from cloakbrowser import launch_async
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()
    try:
        await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print("goto:", e)
    await asyncio.sleep(3)

    data = await page.evaluate(r"""() => {
      const clickable = [...document.querySelectorAll('a,button,[role=button],[role=link],span,div')]
        .map(e => ({tag:e.tagName, id:e.id, cls:(e.className||'').toString().slice(0,40),
                    txt:(e.textContent||'').trim().slice(0,50)}))
        .filter(e => e.txt && e.txt.length<50 && /new|outlook|hotmail|instead|create|get a/i.test(e.txt));
      const allLinks = [...document.querySelectorAll('a[href],[role=button]')]
        .map(e => (e.textContent||'').trim()).filter(t=>t&&t.length<60);
      return {clickable, allLinks: [...new Set(allLinks)].slice(0,30),
              title: document.title, url: location.href};
    }""")
    (OUT / "dom_probe2.json").write_text(json.dumps(data, indent=2))
    print("title:", data["title"])
    print("url:", data["url"])
    print("new-address candidates:", json.dumps(data["clickable"], indent=1)[:600])
    print("all links:", data["allLinks"])
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
