#!/usr/bin/env python3
"""Trace the @outlook.com signup step-by-step, screenshotting + dumping the DOM
after EACH click so we see exactly which step the driver stalls on (the last run
ended with fl=dob,flname,wld still pending -> a mid-form field wasn't filled).
Standalone CloakBrowser, headless.
"""
import asyncio
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def snap(page, name):
    try:
        await page.screenshot(path=str(OUT / f"step_{name}.png"))
    except Exception:
        pass
    d = await page.evaluate(r"""() => ({
      inputs:[...document.querySelectorAll('input')].map(i=>({name:i.name,id:i.id,type:i.type,ph:i.placeholder})),
      selects:[...document.querySelectorAll('select')].map(s=>({name:s.name,id:s.id})),
      buttons:[...document.querySelectorAll('button,input[type=submit]')].map(b=>({t:(b.textContent||b.value||'').trim().slice(0,30),id:b.id})),
      heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
      body:(document.body.innerText||'').slice(0,200)
    })""")
    print(f"\n=== [{name}] heading={d['heading'][:40]!r}")
    print(f"  inputs={[(i['name'] or i['id'], i['type']) for i in d['inputs']]}")
    print(f"  selects={[(s['name'] or s['id']) for s in d['selects']]}")
    print(f"  buttons={[b['t'] for b in d['buttons'] if b['t']]}")
    print(f"  body={d['body'][:120].strip()!r}")
    return d


async def click_next(page):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]',
              '#nextButton']:
        try:
            await page.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def main():
    from cloakbrowser import launch_async
    b = await launch_async(headless=True); ctx = await b.new_context(); p = await ctx.new_page()
    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    await asyncio.sleep(3)
    await snap(p, "0_email")

    # username
    for s in ['input[name="MemberName"]', 'input[type="email"]']:
        try: await p.fill(s, tag, timeout=3000); break
        except: continue
    await click_next(p); await asyncio.sleep(3)
    await snap(p, "1_password")

    # password (independent of username)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    for s in ['input[name="Password"]', 'input[type="password"]']:
        try: await p.fill(s, pw, timeout=3000); break
        except: continue
    await click_next(p); await asyncio.sleep(3)
    d2 = await snap(p, "2_afterpw")

    # name step
    await asyncio_fill(p, ['input[name="FirstName"]', '#FirstName'], "Nathan")
    await asyncio_fill(p, ['input[name="LastName"]', '#LastName'], "Kusumo")
    await click_next(p); await asyncio.sleep(3)
    d3 = await snap(p, "3_aftername")

    # DOB step — inspect selects carefully
    print("\n--- attempting DOB fill ---")
    for sel in ['#BirthMonth', 'select[name="BirthMonth"]']:
        try:
            await p.select_option(sel, index=random.randint(1, 12), timeout=3000)
            print("  month set via", sel); break
        except Exception as e:
            print("  month fail", sel, str(e)[:50])
    for sel in ['#BirthDay', 'select[name="BirthDay"]']:
        try:
            await p.select_option(sel, index=random.randint(1, 28), timeout=3000)
            print("  day set via", sel); break
        except Exception as e:
            print("  day fail", sel, str(e)[:50])
    for sel in ['#BirthYear', 'input[name="BirthYear"]']:
        try:
            await p.fill(sel, str(random.randint(1990, 2001)), timeout=3000)
            print("  year set via", sel); break
        except Exception as e:
            print("  year fail", sel, str(e)[:50])
    await click_next(p); await asyncio.sleep(5)
    await snap(p, "4_aftedob")

    await b.close()


async def asyncio_fill(page, sels, val):
    for s in sels:
        try:
            await page.fill(s, val, timeout=3000); return True
        except Exception:
            continue
    return False


if __name__ == "__main__":
    asyncio.run(main())
