#!/usr/bin/env python3
"""Try URL variants that force the 'new outlook.com mailbox' signup flow instead of
EASI (external email). Microsoft toggles the flow via query params. For each variant,
report whether a username field + @outlook.com/@hotmail.com domain dropdown appears.
Standalone CloakBrowser.
"""
import asyncio
import json
from pathlib import Path

OUT = Path(__file__).parent

VARIANTS = [
    "https://signup.live.com/signup?lic=1",
    "https://signup.live.com/signup?wa=wsignin1.0&signup=1",
    "https://outlook.live.com/owa/?nlp=1&signup=1",
    "https://signup.live.com/signup?mkt=en-US&lic=1&uiflavor=web&fl=easi2",
    "https://signup.live.com/?lic=1&uiflavor=web",
    "https://account.microsoft.com/account?signup=1",
]


async def probe(page, url):
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=40000)
    except Exception as e:
        return {"url": url, "error": str(e)[:80]}
    await asyncio.sleep(3)
    d = await page.evaluate(r"""() => {
      const inputs=[...document.querySelectorAll('input')].map(i=>({name:i.name,id:i.id,type:i.type,ph:i.placeholder}));
      const selects=[...document.querySelectorAll('select')].map(s=>({name:s.name,
        opts:[...s.options].map(o=>o.textContent).slice(0,6)}));
      const domainTxt=/outlook\.com|hotmail\.com/.test(document.body.innerText);
      return {inputs, selects, mentions_outlook_domain: domainTxt,
              final: location.href, title: document.title};
    }""")
    d["url"] = url
    return d


async def main():
    from cloakbrowser import launch_async
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    results = []
    for v in VARIANTS:
        page = await ctx.new_page()
        r = await probe(page, v)
        results.append(r)
        has_domain = bool(r.get("selects")) or r.get("mentions_outlook_domain")
        print(f"[{'DOMAIN?' if has_domain else 'easi   '}] {v[:55]:55} -> final={r.get('final','')[:50]}")
        if r.get("selects"):
            print(f"     selects: {json.dumps(r['selects'])[:200]}")
        await page.close()
    (OUT / "dom_probe3.json").write_text(json.dumps(results, indent=2))
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
