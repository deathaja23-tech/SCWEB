#!/usr/bin/env python3
"""Determine WHICH challenge actually renders at the Outlook signup gate:
PerimeterX/HUMAN 'Press & Hold' (hsprotect.net) vs Arkose FunCaptcha visual puzzle.

The earlier solver flagged arkose_required purely from a DOM string-match on
'arkoselabs' — but that string is ALWAYS present (ServerData.urlArkoseEnforcement
is configured on every page) regardless of which challenge actually shows. This
drives the @outlook.com signup to the gate, then inspects what's REALLY visible:
which iframes are attached, their sizes/visibility, and screenshots for proof.
"""
import asyncio
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def main():
    from cloakbrowser import launch_async
    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    frames_seen = []
    page.on("frameattached", lambda fr: frames_seen.append(fr.url))

    tag = "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
    await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    await asyncio.sleep(3)

    async def fill(sels, val):
        for s in sels:
            try:
                await page.fill(s, val, timeout=3000); return True
            except Exception:
                continue
        return False

    async def click(sels):
        for s in sels:
            try:
                await page.click(s, timeout=2500); return True
            except Exception:
                continue
        return False

    await fill(['input[name="MemberName"]', 'input[type="email"]'], "wg" + tag)
    await click(['#iSignupAction', 'button:has-text("Next")'])
    await asyncio.sleep(3)
    await fill(['input[name="Password"]', 'input[type="password"]'],
               "Wg" + tag + "!9")
    await click(['#iSignupAction', 'button:has-text("Next")'])
    await asyncio.sleep(3)
    await fill(['input[name="FirstName"]', '#FirstName'], "Nathan")
    await fill(['input[name="LastName"]', '#LastName'], "Kusumo")
    await click(['#iSignupAction', 'button:has-text("Next")'])
    await asyncio.sleep(3)
    try:
        await page.select_option('#BirthMonth', str(random.randint(1, 12)), timeout=3000)
        await page.select_option('#BirthDay', str(random.randint(1, 28)), timeout=3000)
        await fill(['#BirthYear'], str(random.randint(1990, 2001)))
    except Exception:
        pass
    await click(['#iSignupAction', 'button:has-text("Next")'])
    await asyncio.sleep(6)  # let the challenge render

    # Inspect what actually rendered.
    info = await page.evaluate(r"""() => {
      const vis = el => { if(!el) return false; const r=el.getBoundingClientRect();
        const s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'; };
      const iframes = [...document.querySelectorAll('iframe')].map(f => ({
        src: (f.src||'').slice(0,90),
        w: f.getBoundingClientRect().width, h: f.getBoundingClientRect().height,
        visible: vis(f)}));
      const bodytext = document.body.innerText.slice(0, 400);
      const pressHold = /press *& *hold|press and hold|tap and hold|hold/i.test(bodytext);
      const arkoseVisibleIframe = iframes.find(f => /arkoselabs|funcaptcha/i.test(f.src) && f.visible);
      const pxVisibleIframe = iframes.find(f => /hsprotect|perimeterx|px-captcha/i.test(f.src) && f.visible);
      return {iframes, bodytext, pressHold,
              arkose_iframe_visible: !!arkoseVisibleIframe,
              px_iframe_visible: !!pxVisibleIframe};
    }""")

    shot = str(OUT / "challenge.png")
    try:
        await page.screenshot(path=shot, full_page=False)
    except Exception as e:
        shot = f"(screenshot failed: {e})"

    print("=== VISIBLE IFRAMES ===")
    for f in info["iframes"]:
        mark = "VISIBLE" if f["visible"] else "hidden"
        print(f"  [{mark} {int(f['w'])}x{int(f['h'])}] {f['src']}")
    print("=== body text (challenge prompt) ===")
    print("  " + info["bodytext"][:250].replace("\n", " | "))
    print("=== VERDICT ===")
    print(f"  'press & hold' text present: {info['pressHold']}")
    print(f"  Arkose iframe VISIBLE:  {info['arkose_iframe_visible']}")
    print(f"  PerimeterX iframe VIS:  {info['px_iframe_visible']}")
    print(f"  screenshot: {shot}")
    print("=== frames attached during run ===")
    for u in frames_seen:
        if any(h in u for h in ("arkose", "hsprotect", "funcaptcha", "perimeterx")):
            print("  " + u[:100])

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
