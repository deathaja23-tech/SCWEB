#!/usr/bin/env python3
"""Drive to the 'Add some details' step and dump the EXACT DOM of the month/day
dropdown triggers (tag, id, class, role, aria-label, data-*) so the solver targets
real selectors instead of guessing. Also try clicking Month and dump the listbox
options that appear. Standalone CloakBrowser headless.
"""
import asyncio
import json
import random
import string
from pathlib import Path

OUT = Path(__file__).parent
SIGNUP = ("https://go.microsoft.com/fwlink/p/?linkid=2125440"
          "&clcid=0x409&culture=en-us&country=us")


async def fill(p, sels, v):
    for s in sels:
        try:
            await p.fill(s, v, timeout=3000); return True
        except Exception:
            continue
    return False


async def nxt(p):
    for s in ['#iSignupAction', 'button:has-text("Next")', 'button[type=submit]']:
        try:
            await p.click(s, timeout=2500); return True
        except Exception:
            continue
    return False


async def main():
    from cloakbrowser import launch_async
    b = await launch_async(headless=True); ctx = await b.new_context(); p = await ctx.new_page()
    tag = "".join(random.choices(string.ascii_lowercase, k=6)) + str(random.randint(100, 999))
    await p.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000); await asyncio.sleep(3)
    await fill(p, ['input[type="email"]', 'input[name="MemberName"]'], tag); await nxt(p); await asyncio.sleep(3)
    pw = "Zx" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!7"
    await fill(p, ['input[type="password"]'], pw); await nxt(p); await asyncio.sleep(4)

    # We should now be on "Add some details". Dump every button/combobox + labels.
    dump = await p.evaluate(r"""() => {
      const desc = el => ({tag:el.tagName, id:el.id, cls:(el.className||'').toString().slice(0,60),
        role:el.getAttribute('role'), aria:el.getAttribute('aria-label'),
        name:el.getAttribute('name'), txt:(el.textContent||'').trim().slice(0,25),
        ph:el.getAttribute('placeholder')});
      const cands = [...document.querySelectorAll('button,[role=combobox],[role=listbox],select,input,div[tabindex]')]
        .map(desc).filter(d => /month|day|year|birth/i.test(JSON.stringify(d)) ||
                               d.role==='combobox' || d.tag==='SELECT');
      return {heading:(document.querySelector('h1,[role=heading]')||{}).textContent||'',
              candidates: cands};
    }""")
    print("heading:", dump["heading"][:40])
    print("=== month/day/year candidates ===")
    for c in dump["candidates"]:
        print("  " + json.dumps(c))

    # Try clicking the first combobox-ish month control and see the listbox
    print("\n=== trying to open Month dropdown ===")
    opened = False
    for sel in ['[aria-label*="Month" i]', 'button:has-text("Month")', '[role=combobox]',
                'div:has-text("Month")[tabindex]']:
        try:
            await p.click(sel, timeout=2500)
            await asyncio.sleep(0.8)
            opts = await p.evaluate(r"""() => [...document.querySelectorAll('[role=option],li[role=option],[role=listbox] *')]
              .map(o=>(o.textContent||'').trim()).filter(Boolean).slice(0,15)""")
            if opts:
                print(f"  opened via {sel!r} -> options: {opts[:6]}")
                opened = True; break
            else:
                print(f"  clicked {sel!r} but no options appeared")
        except Exception as e:
            print(f"  {sel!r} fail: {str(e)[:50]}")
    (OUT / "inspect_dob.json").write_text(json.dumps(dump, indent=2))
    await p.screenshot(path=str(OUT / "dob_step.png"))
    await b.close()


if __name__ == "__main__":
    asyncio.run(main())
