#!/usr/bin/env python3
"""Extract the DataDome client key (ddk) + endpoint that GitHub's octocaptcha
uses, by loading the octocaptcha datadome iframe directly and reading the
DataDome runtime config + intercepting the api-js.datadome.co POST params.

The ddk is the ONE input that differs from the leboncoin capture the solver was
built on; everything else (tags.js v5.8.0, seed 0x7d8479f9, signal template) is
identical. Standalone CloakBrowser script.
"""
import asyncio
import json
from pathlib import Path
from urllib.parse import parse_qs

OUT = Path(__file__).parent
IFRAME = "https://octocaptcha.com/datadome?origin_page=github_signup_redesign"


async def main():
    from cloakbrowser import launch_async

    cap = {"ddk": None, "endpoint": None, "post_params": {}, "dd_config": None,
           "referer_used": None}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    posts = []

    def on_req(r):
        if "api-js.datadome.co" in r.url and r.method == "POST":
            try:
                pd = r.post_data or ""
            except Exception:
                pd = ""
            posts.append({"url": r.url, "body": pd, "headers": dict(r.headers)})

    page.on("request", on_req)

    # octocaptcha frames are normally embedded from github.com; set a matching
    # referer so DataDome serves the same config it would in the real flow.
    await page.set_extra_http_headers({"Referer": "https://github.com/"})
    cap["referer_used"] = "https://github.com/"

    print(f"[*] loading {IFRAME}", flush=True)
    try:
        await page.goto(IFRAME, wait_until="networkidle", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)
    await asyncio.sleep(6)

    # Read DataDome runtime config from the page.
    try:
        cap["dd_config"] = await page.evaluate(r"""() => {
          const out = {};
          try { if (window.DD_RUM) out.DD_RUM = Object.keys(window.DD_RUM); } catch(e){}
          // DataDome stashes options on the captcha init; scan globals + inline scripts.
          for (const k of Object.getOwnPropertyNames(window)) {
            if (/datadome|dd_?/i.test(k)) { try { out[k] = String(window[k]).slice(0,120); } catch(e){} }
          }
          // scrape any ddk-looking hex + endpoint from all script text.
          const txt = [...document.scripts].map(s => s.textContent).join('\n') + document.documentElement.outerHTML;
          const ddk = txt.match(/['"]?(?:ddk|clientKey|key)['"]?\s*[:=]\s*['"]([A-F0-9]{20,})['"]/i);
          if (ddk) out._ddk_scrape = ddk[1];
          const ep = txt.match(/(https:\/\/[a-z0-9.-]*datadome[a-z0-9.-]*\/[a-z\/]*)/i);
          if (ep) out._endpoint = ep[1];
          return out;
        }""")
    except Exception as e:
        cap["dd_config_err"] = str(e)

    # If no POST fired yet, try to trigger the captcha by clicking anything visible.
    if not posts:
        try:
            await page.mouse.click(200, 200)
            await asyncio.sleep(3)
        except Exception:
            pass

    # Parse ddk out of the POST params (DataDome sends ddk in the body/query).
    for p in posts:
        body = p["body"]
        # body is either urlencoded or has jspl=...; check query too.
        for blob in (body, p["url"].split("?", 1)[-1] if "?" in p["url"] else ""):
            try:
                q = parse_qs(blob)
                for key in ("ddk", "cid", "hash", "ddv", "ddvc", "jsver"):
                    if key in q:
                        cap["post_params"][key] = q[key][0][:80]
            except Exception:
                pass
    cap["n_posts"] = len(posts)
    if posts:
        cap["first_post_head"] = posts[0]["body"][:300]
        cap["endpoint"] = posts[0]["url"]

    if cap.get("dd_config", {}).get("_ddk_scrape"):
        cap["ddk"] = cap["dd_config"]["_ddk_scrape"]
    elif cap["post_params"].get("ddk"):
        cap["ddk"] = cap["post_params"]["ddk"]

    (OUT / "ddk.json").write_text(json.dumps(cap, indent=2))
    print(f"[+] ddk={cap['ddk']} endpoint={cap['endpoint']} posts={cap['n_posts']}", flush=True)
    print(f"[+] post_params={cap['post_params']}", flush=True)
    print(f"[+] dd_config_keys={list((cap.get('dd_config') or {}).keys())}", flush=True)

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
