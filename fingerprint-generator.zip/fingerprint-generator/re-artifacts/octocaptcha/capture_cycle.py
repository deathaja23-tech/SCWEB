#!/usr/bin/env python3
"""Capture the FULL octocaptcha DataDome cycle to decide the solver architecture:

  - Is it a SILENT pass (datadome cookie set after POST, no puzzle) → browser-harvest
    solver like cf_clearance, OR does it return an interactive captcha challenge URL
    (geo.captcha-delivery.com) that needs the visual solver?
  - What does api-js.datadome.co/js/ RETURN (cookie / status / redirect)?
  - Where do cid + hash in the POST come from (cookie vs tags.js runtime)?

Standalone CloakBrowser script. Records request+response bodies for the DataDome
endpoints and the final octocaptcha-token / datadome cookie state.
"""
import asyncio
import json
from pathlib import Path
from urllib.parse import parse_qs

OUT = Path(__file__).parent
IFRAME = "https://octocaptcha.com/datadome?origin_page=github_signup_redesign"


async def main():
    from cloakbrowser import launch_async

    cap = {"iframe": IFRAME, "posts": [], "responses": [], "cookies_before": [],
           "cookies_after": [], "octocaptcha_token": None, "captcha_url": None,
           "verdict": None}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    async def on_response(resp):
        u = resp.url
        if "datadome" in u or "captcha-delivery" in u:
            entry = {"url": u[:160], "status": resp.status, "method": resp.request.method}
            try:
                ct = resp.headers.get("content-type", "")
                if resp.request.method == "POST" or "json" in ct or "javascript" in ct:
                    body = await resp.text()
                    entry["body_head"] = body[:400]
                    entry["body_len"] = len(body)
                # DataDome sets its cookie via Set-Cookie OR returns it in JSON.
                sc = resp.headers.get("set-cookie", "")
                if sc:
                    entry["set_cookie_head"] = sc[:120]
            except Exception as e:
                entry["body_err"] = str(e)
            cap["responses"].append(entry)

    def on_request(r):
        u = r.url
        if "api-js.datadome.co" in u and r.method == "POST":
            try:
                pd = r.post_data or ""
            except Exception:
                pd = ""
            params = {}
            try:
                q = parse_qs(pd)
                for k in ("ddk", "cid", "hash", "ddv", "ttst", "ua", "jsData", "jspl"):
                    if k in q:
                        params[k] = q[k][0][:60]
            except Exception:
                pass
            cap["posts"].append({"url": u, "len": len(pd), "params": params,
                                 "head": pd[:120]})

    page.on("response", lambda r: asyncio.create_task(on_response(r)))
    page.on("request", on_request)

    await page.set_extra_http_headers({"Referer": "https://github.com/"})
    print(f"[*] loading {IFRAME}", flush=True)
    try:
        await page.goto(IFRAME, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)

    cap["cookies_before"] = [c["name"] for c in await ctx.cookies()]
    await asyncio.sleep(10)  # let the DataDome cycle complete
    cap["cookies_after"] = [{"name": c["name"], "domain": c.get("domain"),
                             "len": len(c.get("value", ""))} for c in await ctx.cookies()]

    # Is there a datadome cookie now? Is there a captcha-delivery challenge iframe/url?
    dd_cookie = next((c for c in cap["cookies_after"] if c["name"] == "datadome"), None)
    for r in cap["responses"]:
        if "captcha-delivery.com" in r["url"] or "geo.captcha" in r["url"]:
            cap["captcha_url"] = r["url"]
    # Look for an octocaptcha-token / success postMessage in the page.
    try:
        cap["octocaptcha_token"] = await page.evaluate(
            "() => window.__octocaptcha_token || (document.querySelector('[name=octocaptcha-token]')||{}).value || null")
    except Exception:
        pass

    if dd_cookie and not cap["captcha_url"]:
        cap["verdict"] = "SILENT_PASS (datadome cookie set, no interactive puzzle) -> browser-harvest solver"
    elif cap["captcha_url"]:
        cap["verdict"] = "INTERACTIVE_PUZZLE (captcha-delivery challenge) -> needs visual solver"
    else:
        cap["verdict"] = "INCONCLUSIVE (no datadome cookie, no captcha url) -> inspect responses"

    (OUT / "cycle.json").write_text(json.dumps(cap, indent=2))
    print(f"[+] verdict: {cap['verdict']}", flush=True)
    print(f"[+] datadome cookie: {dd_cookie}", flush=True)
    print(f"[+] posts={len(cap['posts'])} responses={len(cap['responses'])}", flush=True)
    for p in cap["posts"]:
        print(f"    POST params={p['params']}", flush=True)
    for r in cap["responses"][:8]:
        print(f"    {r['status']} {r['method']} {r['url'][:90]} sc={('set_cookie_head' in r)}", flush=True)

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
