#!/usr/bin/env python3
"""Capture GitHub's octocaptcha flow end to end.

octocaptcha (octocaptcha.com) is GitHub's captcha broker embedded in /signup via
`js-octocaptcha-parent`. The page markers point at
`octocaptcha.com/datadome?origin_page=github_signup_redesign` — i.e. the provider
behind octocaptcha is now DataDome (not Arkose FunCaptcha as older notes assumed).

This script drives the signup form far enough to trigger the octocaptcha iframe,
then records every network request to octocaptcha.com / datadome / any captcha
host, plus the iframe chain + page markers, to determine the exact provider and
payload shape.

Standalone CloakBrowser script (native launch_async).
"""
import asyncio
import json
import re
from pathlib import Path

OUT = Path(__file__).parent
OUT.mkdir(parents=True, exist_ok=True)

SIGNUP = "https://github.com/signup"

# Hosts of interest for the captcha broker chain.
_INTEREST = ("octocaptcha.com", "datadome", "arkoselabs", "funcaptcha",
             "captcha-delivery", "geo.captcha", "hcaptcha", "recaptcha",
             "challenges.cloudflare")


async def main():
    from cloakbrowser import launch_async

    cap = {
        "target": SIGNUP,
        "captcha_reqs": [],       # requests to captcha hosts
        "iframe_urls": [],        # frame chain
        "page_markers": {},       # data-octocaptcha-* attributes
        "provider_guess": None,
    }

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    def interesting(u: str) -> bool:
        return any(h in u for h in _INTEREST)

    def on_req(r):
        u = r.url
        if interesting(u):
            e = {"url": u[:180], "method": r.method, "rtype": r.resource_type}
            if r.method == "POST":
                try:
                    pd = r.post_data
                    e["post_len"] = len(pd or "")
                    e["post_head"] = (pd or "")[:200]
                except Exception:
                    pass
            cap["captcha_reqs"].append(e)

    def on_frame(fr):
        u = fr.url
        if u and (interesting(u) or "octocaptcha" in u):
            cap["iframe_urls"].append(u[:180])

    page.on("request", on_req)
    page.on("frameattached", lambda fr: on_frame(fr))

    print(f"[*] navigating {SIGNUP}", flush=True)
    try:
        await page.goto(SIGNUP, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)
    await asyncio.sleep(3)

    # Pull the octocaptcha config attributes off the parent element.
    try:
        cap["page_markers"] = await page.evaluate(r"""() => {
          const el = document.querySelector('.js-octocaptcha-parent, [data-octocaptcha-url]');
          const out = {};
          if (el) for (const a of el.attributes)
            if (a.name.startsWith('data-octocaptcha')) out[a.name] = a.value;
          // also grab any octocaptcha iframe src already present
          const ifr = document.querySelector('iframe[src*="octocaptcha"]');
          if (ifr) out['_iframe_src'] = ifr.src;
          return out;
        }""")
    except Exception as e:
        cap["page_markers_err"] = str(e)

    # Try to advance the form so octocaptcha actually renders: fill the 3 fields.
    async def try_fill(sel, val):
        try:
            await page.fill(sel, val, timeout=4000)
            return True
        except Exception:
            return False

    import random
    tag = random.randint(10000, 99999)
    await try_fill('input[autocomplete="email"], #email, input[name="email"]', f"waguri.re{tag}@example.com")
    await try_fill('input[autocomplete="new-password"], #password, input[name="password"]', "Wg9!zXq2mLp4vT")
    await try_fill('#login, input[name="login"], input[autocomplete="username"]', f"wgre{tag}")
    # click Continue buttons to progress the multi-step signup.
    for _ in range(3):
        try:
            btn = await page.query_selector('button[type=submit], .js-continue, button:has-text("Continue")')
            if btn:
                await btn.click(timeout=3000)
        except Exception:
            pass
        await asyncio.sleep(3)

    await asyncio.sleep(4)  # let the captcha iframe chain settle

    # Guess provider from what we captured.
    hosts = " ".join(r["url"] for r in cap["captcha_reqs"]) + " " + " ".join(cap["iframe_urls"])
    if "datadome" in hosts or "captcha-delivery" in hosts:
        cap["provider_guess"] = "datadome"
    elif "arkoselabs" in hosts or "funcaptcha" in hosts:
        cap["provider_guess"] = "arkose"
    elif "hcaptcha" in hosts:
        cap["provider_guess"] = "hcaptcha"
    elif "recaptcha" in hosts:
        cap["provider_guess"] = "recaptcha"

    (OUT / "capture.json").write_text(json.dumps(cap, indent=2))
    print(f"[+] provider_guess={cap['provider_guess']} "
          f"captcha_reqs={len(cap['captcha_reqs'])} iframes={len(cap['iframe_urls'])}", flush=True)
    print(f"[+] markers: {json.dumps(cap['page_markers'])[:300]}", flush=True)
    for r in cap["captcha_reqs"][:20]:
        print(f"    {r['method']} {r['url'][:120]}", flush=True)

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
