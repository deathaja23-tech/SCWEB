#!/usr/bin/env python3
"""Verify the harvest architecture: let tags.js run naturally in the iframe,
intercept the api-js.datadome.co/js/ RESPONSE, parse the datadome cookie out of
its JSON body ({"status":200,"cookie":"datadome=...; Domain=.github.com; ..."}),
and confirm we can extract a replayable datadome cookie value.

This decides: wrapper solver = browser-run tags.js + intercept-response-cookie
(robust, no manual jspl reconstruction). Standalone CloakBrowser script.
"""
import asyncio
import json
import re
from pathlib import Path

OUT = Path(__file__).parent
IFRAME = "https://octocaptcha.com/datadome?origin_page=github_signup_redesign"


async def main():
    from cloakbrowser import launch_async

    result = {"datadome_cookie": None, "domain": None, "status": None,
              "raw_json": None, "harvested": False}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    async def on_response(resp):
        if "api-js.datadome.co/js/" in resp.url and resp.request.method == "POST":
            try:
                body = await resp.text()
                result["raw_json"] = body[:500]
                data = json.loads(body)
                result["status"] = data.get("status")
                ck = data.get("cookie", "")
                m = re.search(r"datadome=([^;]+)", ck)
                if m:
                    result["datadome_cookie"] = m.group(1)
                    dm = re.search(r"Domain=([^;]+)", ck)
                    result["domain"] = dm.group(1) if dm else None
                    result["harvested"] = True
            except Exception as e:
                result["err"] = str(e)

    page.on("response", lambda r: asyncio.create_task(on_response(r)))
    await page.set_extra_http_headers({"Referer": "https://github.com/"})

    print(f"[*] loading {IFRAME}", flush=True)
    try:
        await page.goto(IFRAME, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)
    await asyncio.sleep(10)

    (OUT / "harvest.json").write_text(json.dumps(result, indent=2))
    print(f"[+] harvested={result['harvested']} status={result['status']} "
          f"domain={result['domain']}", flush=True)
    print(f"[+] datadome cookie: {(result['datadome_cookie'] or '')[:60]}...", flush=True)
    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
