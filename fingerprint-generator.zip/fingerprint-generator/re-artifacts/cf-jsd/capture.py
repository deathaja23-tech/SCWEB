#!/usr/bin/env python3
"""Capture Cloudflare JSD challenge: main.js script, __CF$cv$params token,
and the oneshot POST payload. Determines whether the LZ alphabet + template
are stable per-version OR the challenge token is server-issued (challenge-response).

Standalone CloakBrowser script (native launch_async), per project convention.
"""
import asyncio
import json
import os
import re
import sys
from pathlib import Path

OUT = Path(__file__).parent
OUT.mkdir(parents=True, exist_ok=True)

# CF JSD ("I'm Under Attack" / managed) protected targets to try.
TARGETS = [
    "https://www.blockchain.com/",
    "https://nowsecure.nl/",
    "https://www.cointelegraph.com/",
]


async def main():
    from cloakbrowser import launch_async

    captured = {"requests": [], "cf_params": None, "main_js_urls": [], "target": None}

    browser = await launch_async(headless=True)
    ctx = await browser.new_context()
    page = await ctx.new_page()

    async def on_request(req):
        u = req.url
        if "challenge-platform" in u:
            entry = {"url": u, "method": req.method}
            if req.method == "POST":
                try:
                    entry["post_data"] = req.post_data
                except Exception as e:
                    entry["post_data_err"] = str(e)
            entry["headers"] = dict(req.headers)
            captured["requests"].append(entry)
            if "/scripts/jsd/" in u or "/orchestrate/jsd/" in u or u.endswith("main.js"):
                captured["main_js_urls"].append(u)

    page.on("request", lambda r: asyncio.create_task(on_request(r)))

    target = TARGETS[int(os.environ.get("TARGET_IDX", "0"))]
    captured["target"] = target
    print(f"[*] navigating {target}", flush=True)
    try:
        await page.goto(target, wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        print(f"[!] goto: {e}", flush=True)

    # Let the JSD challenge fire.
    await asyncio.sleep(8)

    html = await page.content()
    m = re.search(r"__CF\$cv\$params\s*=\s*\{([^}]*)\}", html)
    if m:
        captured["cf_params"] = m.group(0)
        print(f"[+] found __CF$cv$params: {m.group(0)[:200]}", flush=True)
    else:
        print("[-] no __CF$cv$params in HTML (site may not be JSD-gated)", flush=True)

    # Dump cookies (cf_clearance is the success signal).
    cookies = await ctx.cookies()
    captured["cookies"] = [{"name": c["name"], "value": c["value"][:40] + "..."} for c in cookies]

    (OUT / "capture.json").write_text(json.dumps(captured, indent=2))
    print(f"[*] wrote capture.json ({len(captured['requests'])} challenge reqs)", flush=True)
    for r in captured["requests"]:
        print(f"    {r['method']} {r['url'][:110]}", flush=True)

    await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
