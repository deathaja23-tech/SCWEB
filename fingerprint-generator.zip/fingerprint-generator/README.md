# Fingerprint Generator

Browser fingerprint generation **HTTP API**. Generates realistic browser fingerprints (GPU, screen, WebGL, canvas, math precision, audio, fonts, performance timing) across **desktop & mobile** and **Chrome / Firefox / Safari**, then shapes each identity into a per-antibot **target** payload + encryption envelope.

Written in Go. **Zero external dependencies** (pure stdlib). Full access is via the API — interactive docs at `/docs`.

**Multi-target architecture:** a generic, target-agnostic browser-identity core feeds pluggable per-antibot **targets**. The default target `generic` emits a flat, self-describing identity payload usable anywhere; named targets shape the identity into a specific antibot's schema and envelope. Adding a target requires its reverse-engineered schema + stable crypto constants.

## Architecture

```
fingerprint-generator/
├── cmd/
│   └── server/
│       ├── main.go                # HTTP API server (?target=, default "generic"), /targets, validation
│       ├── main_test.go           # HTTP property + integration tests
│       └── docs.go                # Swagger UI + hand-written OpenAPI spec
├── internal/
│   ├── identity/                  # GENERIC CORE — target-agnostic browser identity
│   │   ├── identity.go            # Chrome version, GPU, WebGL, canvas, math, audio, hardware tiers, GenOptions
│   │   ├── regions.go             # Region_Profile_Table (data-driven, 33 countries / 7 regions)
│   │   ├── mobile.go              # Android/iOS Chrome mobile identities (portrait, DPR 2–4)
│   │   ├── browser.go             # Firefox (Gecko) / Safari (WebKit) identities + platform matrix
│   │   └── cache.go               # Per-proxy identity cache (6h TTL, region hint)
│   └── antibot/
│       ├── target.go              # Target interface + registry (Build(ctx)/Capabilities/IdentityExtras)
│       ├── cryptoutil/            # SHARED pure-stdlib primitives: OrderedMap, XTEA, MurmurHash3,
│       │                          #   EVP_BytesToKey, LZString, DataDome codec
│       ├── behavioral/            # SHARED human-like signal synth (mouse/touch/click/timing)
│       ├── generic/               # DEFAULT target — flat, self-describing, no envelope
│       ├── amazon/                # Amazon TES (metrics-first OrderedMap + XXTEA ECdITeCs:)
│       ├── xiaomi/                # Xiaomi MiMo (RSA-2048 + AES-128-CBC envelope)
│       ├── x/                     # X/Twitter — variants: xpff | txid | arkose
│       ├── microsoft/             # Microsoft/Outlook Arkose BDA (AES-256-CBC / EVP)
│       ├── arkose/                # SHARED Arkose BDA builder (used by microsoft + x/arkose)
│       ├── datadome/ human/ github/       # Tier B — built but NOT registered (see Target Readiness)
│       └── akamai/ cloudflare/ kasada/    # Tier C — scaffold only, NOT registered
├── .fp-token.env                  # Bearer token for remote API access (gitignored — never commit)
├── .gitignore
├── go.mod
└── README.md
```

## Targets & Readiness Tiers

The default is `generic`. A named target is **registered** (advertised in `GET /targets`, usable via `?target=`) only when its reverse-engineered schema **and** stable crypto constants are available — so the system never emits a knowingly-wrong payload.

| Target | Tier | Status | Variants | Envelope |
| ------ | ---- | ------ | -------- | -------- |
| `generic` | A | **registered (default)** | — | none (flat JSON) |
| `amazon` | A | **registered** | — | XXTEA `ECdITeCs:` |
| `xiaomi` | A | **registered** | — | `s=RSA(aesKey)&d=AES-CBC(json)&a=register` |
| `x` | A | **registered** | `xpff`, `txid`, `arkose` | per-variant (AES-GCM / XOR+base64 / Arkose BDA) |
| `microsoft` | A | **registered** | — | Arkose BDA `{ct,iv,s}` |
| `datadome`, `human`, `github` | B | built, **not registered** | — | held until signal order / keys pinned |
| `akamai`, `cloudflare`, `kasada` | C | scaffold, **not registered** | (`cloudflare`: jsd, turnstile) | rotating constants → cannot verify |

Requesting a non-registered target returns **400** with the list of available targets. Tier B/C code exists (builders/scaffolds conforming to the interface) so it can be enabled once constants are pinned; they are held per the "never emit an incorrect payload" rule.

### Adding / enabling an antibot target

1. Create `internal/antibot/<name>/` and implement the `antibot.Target` interface (`internal/antibot/target.go`):
   - `Name() string`
   - `Capabilities() Capabilities` — variants, default variant, `EncryptionApplicable`, and `RequiredInputs` (session inputs that must be supplied and cannot be synthesized).
   - `Build(ctx *BuildContext) (*BuildResult, error)` — shapes `ctx.Identity` (+ `ctx.Variant` + `ctx.SessionInputs`) into `{Raw, Encoded}`. Both raw and enveloped forms are returned so the server honors `encrypt=true|false` without a second call, and envelope keys can be derived from Identity/Session inputs.
   - `IdentityExtras(id) map[string]interface{}` — extra fields for the emitted `identity` JSON (or `nil`).
2. Register via `init()` + a blank import `_ "fingerprint-generator/internal/antibot/<name>"` in `cmd/server/main.go` — **only** once the schema and stable constants are confirmed.
3. Reuse `internal/identity` (never duplicate Chrome/GPU/WebGL/canvas/region generation) and the shared `cryptoutil` / `behavioral` helpers.

## HTTP API Server

Runs as systemd service `fingerprint-server.service` on port `:8800`.
Exposed at `https://fp.example.com` via Cloudflare Tunnel + Caddy.

```bash
# Systemd management
sudo systemctl status fingerprint-server.service
sudo systemctl restart fingerprint-server.service

# Logs
journalctl -u fingerprint-server.service -f
```

### Interactive docs (Swagger)

Open **`https://fp.example.com/docs`** (Swagger UI) — every parameter is documented with a "Try it out" form; the raw spec is at `/openapi.json`. Both are public (no token).

## Endpoints

| Method | Path            | Auth         | Description                              |
| ------ | --------------- | ------------ | ---------------------------------------- |
| GET    | `/health`       | public       | Liveness check                           |
| GET    | `/targets`      | public       | List registered (verified) target names  |
| GET    | `/docs`         | public       | **Swagger UI** — interactive API docs    |
| GET    | `/openapi.json` | public       | OpenAPI 3 spec                           |
| GET    | `/fingerprint`  | Bearer token | Generate fingerprint(s)                  |
| GET    | `/stats`        | Bearer token | Cache statistics                         |

`/health`, `/targets`, and the docs paths are public at the application level (the service enforces no auth on them). On localhost the service enforces no auth at all. Through the public domain, the **Caddy allowlist** decides which paths skip the Bearer check — add `/targets` to that allowlist alongside `/health` and the docs paths to expose it publicly (otherwise Caddy will still require a token for it).

### Remote access (public domain)

```bash
TOKEN=$(cut -d= -f2 .fp-token.env)

# Health / target list — public, no token
curl https://fp.example.com/health
curl https://fp.example.com/targets

# Default generic identity
curl -H "Authorization: Bearer $TOKEN" "https://fp.example.com/fingerprint"

# Named target + options
curl -H "Authorization: Bearer $TOKEN" \
  "https://fp.example.com/fingerprint?target=amazon&count=5&chrome=131"

# Mobile Safari (iOS), region-targeted
curl -H "Authorization: Bearer $TOKEN" \
  "https://fp.example.com/fingerprint?device=mobile&browser=safari&country=jp"

# X XPFF (variant requires a session input)
curl -H "Authorization: Bearer $TOKEN" \
  "https://fp.example.com/fingerprint?target=x&variant=xpff&guest_id=v1%3A1748492985"

# Proxy-bound identity (cached 6h)
curl -H "Authorization: Bearer $TOKEN" \
  "https://fp.example.com/fingerprint?proxy=http://user:pass@host:port"
```

### Local (no token)

```bash
curl "http://127.0.0.1:8800/fingerprint?count=1&pretty=true"
```

## Query Parameters (`GET /fingerprint`)

| Param     | Default   | Description                                                            |
| --------- | --------- | --------------------------------------------------------------------- |
| `count`   | 1         | Number of fingerprints (max 100)                                      |
| `proxy`   |           | Proxy URL to bind identity to (cached 6h; proxy-provider `__cr.XX` hint)  |
| `chrome`  | random    | Pin Chrome major version (120–151)                                    |
| `target`  | `generic` | Antibot target (see `GET /targets`); unknown → 400                    |
| `variant` | default   | Target variant when the target exposes >1 (`x`: xpff/txid/arkose)     |
| `device`  | desktop   | `desktop` \| `mobile` (case-insensitive); invalid → 400               |
| `browser` | chrome    | `chrome` \| `firefox` \| `safari` (case-insensitive); invalid → 400   |
| `country` | random    | ISO 3166-1 alpha-2 region hint (e.g. `jp`); unknown → weighted-random |
| `encrypt` | true      | Set `false` to skip the envelope (no effect for `generic`)            |
| `pretty`  | false     | Pretty-print the JSON response                                        |

**Session inputs** (per-request values from a live session; required by some targets/variants, validated → 400 if missing): `guest_id`, `sitekey`, `method`, `path`, `verification`, `animation_key`, `cid`, `token`, `difficulty`, `prefix`, `ptoken`, `cookies`, `url`, `hash`.
Example — `x` requires: `xpff`→`guest_id`; `txid`→`method,path,verification,animation_key`; `arkose`→`sitekey`.

## Response Format

The default `generic` target returns a flat, self-describing payload with no envelope (`encryptionApplicable: false`):

```jsonc
{
  "identity": {
    "chromeVersion": "131.0.0.0",
    "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ...",
    "secUA": "\"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"131\", ...", // Chromium-only; omitted for Firefox/Safari
    "secChUaPlatform": "Windows",
    "secChUaMobile": "?0",                     // "?1" for mobile Chrome
    "deviceType": "desktop",                   // desktop | mobile
    "browserFamily": "chrome",                 // chrome | firefox | safari
    "gpuVendor": "Google Inc. (NVIDIA)",
    "gpuModel": "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 ...)",
    "webglExtensions": ["ANGLE_instanced_arrays", ...],
    "canvasHash": -1234567890,
    "histogram": [0, 0, 12, 45, ...],          // 256 bins
    "mathTan": "-1.4214488238747245",
    "mathSin": "0.8178819121159085",
    "mathCos": "-0.5753861119575491",
    "audioFingerprint": "124.04347527516074",  // OfflineAudioContext sum, OS-clustered
    "plugins": [{"name": "Chrome PDF Viewer", ...}],
    "screen": {"width": 1920, "height": 1080, "availWidth": 1920, "availHeight": 1040, "colorDepth": 24, "devicePixelRatio": 1},
    "deviceMemory": 8,
    "hardwareConcurrency": 16,
    "platform": "Win32",                       // Win32 | MacIntel | Linux x86_64 | Linux armv8l | iPhone
    "timeZone": -5,                            // UTC offset (region-coherent)
    "languages": ["en-US", "en"],
    "locale": "en-US",
    "fonts": ["Arial", "Calibri", ...]
  },
  "fingerprint": {
    "raw": { /* target payload — for generic: the flat identity object */ },
    "encryptionApplicable": false              // true for enveloped targets
    // "encrypted": "..."                       // present only when encrypt!=false AND the target has an envelope
  }
}
```

Named targets set `encryptionApplicable: true` and (unless `encrypt=false`) an `encrypted` envelope, and may add target-specific fields to `identity` (e.g. Amazon's `webpackHash`, Microsoft's `arkosePublicKey`). Amazon's `raw` is the order-sensitive `metrics`-first payload; its `encrypted` starts with `ECdITeCs:`.

**Batch response** (`count > 1`):

```jsonc
{ "count": 5, "fingerprints": [ /* same shape as single response */ ] }
```

## Fingerprint Components

Each generated identity includes:

- **Chrome version**: Random 120–151 (or pinned), with matching `Sec-CH-UA`.
- **Device & browser**: Desktop or mobile; Chrome, Firefox, or Safari. Non-Chrome identities carry a Gecko/WebKit UA and **omit** the Chromium-only client hints. Platform matrix stays coherent (Safari → macOS/iOS; Firefox → Windows/macOS/Linux/Android).
- **Platform**: Desktop weighted `Win32` (~70%) / `MacIntel` (~20%) / `Linux x86_64` (~10%); mobile `Android` (weighted) / `iOS`. Drives UA, client hints, GPU renderer, fonts, and screen so every OS-dependent signal stays internally consistent.
- **Mobile**: Portrait screen (`height > width`), `devicePixelRatio` 2–4, mobile GPU (Adreno/Mali/PowerVR on Android, Apple GPU on iOS), platform-specific mobile fonts.
- **GPU / hardware correlation**: GPU, RAM, and CPU cores drawn from one coherent tier (low ~30% / mid ~45% / high ~25%) — no impossible combos. Apple Silicon uses fixed unified-memory and Mac core-count sets.
- **WebGL / canvas / math / audio**: core+optional WebGL extensions; deterministic 256-bin canvas histogram + hash; tan/sin/cos precision families; OfflineAudioContext sum clustered by OS audio backend.
- **Region**: Data-driven `Region_Profile_Table` — **33 countries across 7 regions** (North/South America, Europe, Middle East, Africa, Asia, Oceania). Region-coherent `timeZone` + `navigator.languages` + `locale`, from a `country` param, a proxy-provider `__cr.XX` proxy hint, or weighted-random.
- **Fonts / plugins / screen / timing**: platform-specific font subset; Chrome PDF plugins (empty on mobile/non-Chrome); per-platform resolution + DPR; realistic page-load timing.

## Proxy Caching

When a proxy URL is provided, the identity is cached for **6 hours** per proxy (normalized to `host:port`), so the same proxy always gets the same fingerprint within a session — avoiding mismatches that trigger detection.

Cache file: `~/.fingerprint-generator/identities.dat`

## Encryption

Encryption is per-target. The `generic` target has **no envelope** (`encryptionApplicable: false`). Named targets wrap the payload in their own envelope (Amazon: XXTEA `ECdITeCs:`; Xiaomi: RSA-2048 + AES-128-CBC; X/xpff: AES-256-GCM `hex(iv‖ct‖tag)`; Microsoft & X/arkose: AES-256-CBC `{ct,iv,s}`). Pass `encrypt=false` to omit the envelope for enveloped targets. All crypto uses Go stdlib only (XTEA, MurmurHash3, EVP_BytesToKey, LZString implemented on top of stdlib).

## Build

```bash
cd ./
go build -o ~/bin/fingerprint-server ./cmd/server/
```

## Testing

```bash
go test ./...          # unit, integration (httptest), and property-based tests
go vet ./...
```

Property-based tests (Go stdlib `testing/quick`) cover 22 correctness properties — generic round-trip/purity, hardware/platform coherence, mobile & non-Chrome invariants, region coherence, registry/routing, Amazon backward-compat, named-target schema/envelope conformance, envelope key derivation, and behavioral variability. Smoke tests verify zero external deps (no `go.sum`) and the Xiaomi RSA / X XPFF crypto constants.

## Dependencies

None. Pure Go stdlib + internal packages. No `go.sum` file exists.

## Token

Remote API access token is stored in `.fp-token.env` (chmod 600, **gitignored — never commit**):

```
FP_TOKEN=fp-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Caddy enforces Bearer auth on all paths except the public allowlist (`/health` and the docs paths; add `/targets` there to expose it too). The token is static (not rotated); read it from `.fp-token.env` rather than hardcoding it.
