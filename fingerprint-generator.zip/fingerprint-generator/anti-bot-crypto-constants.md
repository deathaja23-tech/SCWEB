# Anti-Bot Cryptographic Constants Reference

All verified cryptographic constants, key material, and encryption parameters for major anti-bot systems.
Extracted from deobfuscated source code and verified reverse-engineering artifacts.

---

## Table of Contents

1. [Xiaomi MiMo Platform](#1-xiaomi-mimo-platform)
2. [X/Twitter XPFF](#2-xtwitter-xpff)
3. [Arkose Labs FunCaptcha](#3-arkose-labs-funcaptcha)
4. [DataDome / HUMAN Security](#4-datadome--human-security)
5. [Akamai Bot Manager](#5-akamai-bot-manager)
6. [Cloudflare JSD Challenge](#6-cloudflare-jsd-challenge)
7. [Cloudflare Turnstile](#7-cloudflare-turnstile)
8. [Kasada](#8-kasada)
9. [Stability Assessment](#9-stability-assessment)

---

## 1. Xiaomi MiMo Platform

**ALL CONSTANTS STABLE** — hardcoded in client JS, not rotated server-side.

### RSA-1024 (EUI Registration Key)

```
Modulus (hex):
98115acaff831a862bf4a542604f26f1e09f4fe5d513fd8d0fbb031b93e80c53e8eb6670625c6bfafe1087d5abc886805c139df917c9c941037751abd974591889db285ee1276addfe7954e9dc5b25ca14702010c5d3dbf8bc3851b7114e4fe47bb87ee1fe6ce6c80dbffa57c8316188adf7d7a6b622cdb57bebe6102a1a2a15

Modulus (decimal):
106785634791429862123152207359433355248351573424467419272852213277153536329527582678677996296351193686777689496100446946890328044606427833871696298400192771823857293684434765082624827848226041232117068669970631777423832620226185899214442403674003372960474945033635168536394545762592701795295996032023170525717

Exponent: 65537 (0x10001)
Key size: 1024-bit (128 bytes)
Algorithm: RSAES-PKCS1-V1_5
```

PEM:
```
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYEVrK/4Mahiv0pUJgTybx4J9P
5dUT/Y0PuwMbk+gMU+jrZnBiXGv6/hCH1avIhoBcE535F8nJQQN3UavZdFkYidso
XuEnat3+eVTp3FslyhRwIBDF09v4vDhRtxFOT+R7uH7h/mzmyA2/+lfIMWGIrffX
prYizbV76+YQKhoqFQIDAQAB
-----END PUBLIC KEY-----
```

### RSA-2048 (Captcha Data Key)

```
Modulus (hex):
af17cd2e4b8043f0581f3933570b6e83ed1a6e661105508449c4b31b12483ac7f157372ea9a28ef3b1f6a36c0171a703ddb44784c8d3921484ab13e343f1445ee27571d6e6af7f9bdc4411eb07ff71870cc76e3af3f43256843b0400cb48f79c421b6018e965902f9c2d837a31ddf85228ba53e5497f4a74abfb1ac544d9be147691af5fa89e3ee82e9c3a084879c8cc61034721a356f9e48aba77c5b17554f907cc0f4ab610cf70a36d1a2e7a2cdb8c83cd18e1f4725ceb17ebdfb8d196fd7f6e81bf10004c1bd1674e6df9c56ad54749f0ddca5817b199835dd089c4bf67012c49de07c9ba00aee3312413ef2b725daf8652db76e937471abd6389b01a9957

Modulus (decimal):
22103440320064851983329520710864278894610040083409403580461062878270338239122968085772892019053378415198176314956589285043878466680772804186511697428486976364999744106785867555481985379192464940370232849872100167381708655075776893543470566736708729592863927237767625625207612316514164850832308697553495617525748400082299378150595396769799724171191121332074772944328385289101610540610672826929049319810031791181361874965942637321498552298328489719754546462653399123941019860407199607435774344000154824159183750555599963663511044794732584439802768362107835882691559272398982415355205737306686561958737673073531981306199

Exponent: 65537 (0x10001)
Key size: 2048-bit (256 bytes)
Algorithm: RSAES-PKCS1-V1_5
```

PEM:
```
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArxfNLkuAQ/BYHzkzVwtu
g+0abmYRBVCEScSzGxJIOsfxVzcuqaKO87H2o2wBcacD3bRHhMjTkhSEqxPjQ/FE
XuJ1cdbmr3+b3EQR6wf/cYcMx2468/QyVoQ7BADLSPecQhtgGOllkC+cLYN6Md34
Uii6U+VJf0p0q/saxUTZvhR2ka9fqJ4+6C6cOghIecjMYQNHIaNW+eSKunfFsXVU
+QfMD0q2EM9wo20aLnos24yDzRjh9HJc6xfr37jRlv1/boG/EABMG9FnTm35xWrV
R0nw3cpYF7GZg13QicS/ZwEsSd4HyboAruMxJBPvK3Jdr4ZS23bpN0cavWOJsBqZ
VwIDAQAB
-----END PUBLIC KEY-----
```

### AES Constants

```
FIXED_IV:              "0102030405060708" (8 bytes UTF-8, used as 16-byte AES IV)
AES_KEY_LENGTH:        16 chars (random per request)
Algorithm:             AES-128-CBC + PKCS7 padding
Key encoding:          UTF-8 string → Buffer → AES key (NOT derived, raw bytes)
```

**EUI AES Charset (70 chars):**
```
ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*
```

**Captcha AES Charset (89 chars):**
```
ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()-=_+~`{}[]|:<>?/.
```

### Captcha Data Endpoint

```
Key:       8027422fb0eb42fbac1b521ec4a7961f
Endpoint:  https://verify.sec.xiaomi.com/captcha/v2/data
Verify:    https://verify.sec.xiaomi.com/captcha/v2/recaptcha/verify
Sitekey:   6LeBM0ocAAAAAEwYcFUjtxpVbs-0rnbSVXBBXmh4
```

---

## 2. X/Twitter XPFF

**ALL CONSTANTS STABLE** — hardcoded in WASM data section.

### AES Base Key

```
0e6be1f1e21ffc33590b888fd4dc81b19713e570e805d4e5df80a493c9571a05
```

64 hex chars = 32 bytes = 256 bits. The ONLY 64-char hex string in the WASM binary.

### Key Derivation

```
derived_key = SHA-256(base_key + guest_id)
```

- `base_key`: static string from above
- `guest_id`: URL-encoded value from Twitter cookies (e.g. `v1%3A174849298500261196`)
- Result: 32-byte digest = AES-256-GCM key directly (no further KDF)

### Encryption Parameters

```
Algorithm:     AES-256-GCM
IV:            12 bytes (96 bits), random via wasi_snapshot_preview1.random_get
Auth tag:      16 bytes (128 bits), appended by GCM
Output:        hex(IV || ciphertext || auth_tag)
Validity:      300,000 ms (5 minutes)
```

### Host Validation

```
Production:  x.com, pro.x.com
Development: localhost.x.com:3443
```

### Transaction ID Constants

```
TIME_EPOCH_OFFSET:    1682924400000 ms (April 2023)
HASH_SALT_LITERAL:    "obfiowerehiring"
TERMINATOR_BYTE:      0x03
XOR_SALT_RANGE:       0-255
VERIFICATION_META:    <meta name="twitter-site-verification">
ONDEMAND_REGEX:       (\(\w{1}\[(\d{1,2})],\s*16))+
```

### Transaction ID Algorithm

```python
# Hash input construction
time_now = floor((timestamp_ms - 1682924400000) / 1000)
hash_input = f"{METHOD}!{PATH}!{time_now}obfiowerehiring{animation_key}"
hash = SHA-256(hash_input)

# Byte assembly
time_bytes = [(time_now >> (i*8)) & 0xFF for i in range(4)]  # 4 bytes LE
random_salt = randint(0, 255)
payload = [*key_bytes, *time_bytes, *hash[:16], 0x03]
output = bytearray([random_salt, *[b ^ random_salt for b in payload]])
result = base64(output).rstrip('=')
```

---

## 3. Arkose Labs FunCaptcha

**ALL CONSTANTS STABLE** — algorithm constants, not session-dependent.

### Encryption

```
Algorithm:     AES-256-CBC, PKCS7 padding
Wire format:   base64({"ct":"...","iv":"...","s":"..."})
```

### Key Derivation (MD5 Chain, 4 Rounds)

```
key_string    = user_agent + str(timestamp_rounded)
timestamp     = int(time.time()) - (int(time.time()) % 21600)
salted_key    = key_string.encode() + bytes.fromhex(salt)

h0            = MD5(salted_key)
h1            = MD5(h0 + salted_key)
h2            = MD5(h1 + salted_key)
h3            = MD5(h2 + salted_key)

AES_KEY       = (h0 + h1 + h2 + h3)[:32]
```

### Constants

```
TIMESTAMP_WINDOW:   21600 seconds (6 hours)
DECRYPTED_FORMAT:   [{"key":"field_name","value":...}, ...] (flat KV array)
IV_REUSE:           Same IV/salt reused on repackage (deterministic encryption)
```

### EVP_BytesToKey (pre-4.x.x BDA)

```
Key derivation: EVP_BytesToKey(key, salt, 32, 16)
                = OpenSSL-compatible MD5-based key derivation
Key input:      user_agent + timeFrameKey
timeFrameKey:   Math.floor((timestamp/1000) - ((timestamp/1000) % 21600))
TIME_CONSTANT:  21600 (6 hours)
```

### Microsoft/Outlook Arkose Public Key

```
B7D8911C-5CC8-A9A3-35B0-554ACEE604DA
```

---

## 4. DataDome / HUMAN Security

**ALL CONSTANTS STABLE** — hardcoded in encryption library.

### PRNG Constants

```
MAIN_PRNG_SEED:         9959949970
HASH_XOR_CAPTCHA:       -1748112727
HASH_XOR_INTERSTITIAL:  -883841716
CID_PRNG_CONSTANT:      1809053797
EMPTY_STRING_FALLBACK:  1789537805
```

### HSV (Hidden State Value)

```
HSV_INTERSTITIAL:  "9E9FC74889F6" (fixed, 12 hex chars)
HSV_CAPTCHA:       dynamic — randHex[0..randIndex] + hash[-4:] + randHex[randIndex..]
                   randIndex: random 0-8
                   randHex: random 8-char hex string
```

### djb2 Hash Function

```
hash = (hash << 5) - hash + charCode | 0
```

### PRNG Xorshift (every 3rd call)

```
value ^= value << 13
value ^= value >> 17
value ^= value << 5
```

### PRNG State Extraction (per call)

```
Round 0: result = state >> 8 & 0xFF
Round 1: result = state >> 0 & 0xFF
Round 2: result = state >> 16 & 0xFF
Then:    result ^= --saltState  (decrementing, masked to 255)
```

### Custom Base64 Character Mapping

```
Index 0  → '-' (45)
Index 1  → '_' (95)
Index 2-11  → '0'-'9' (48-57)
Index 12-37 → 'A'-'Z' (65-90)
Index 38-63 → 'a'-'z' (97-122)
```

Padding: truncated (no `=` chars), length % 4 indicates padding bytes.

### Buffer Construction Markers

```
First entry start:    123 ('{') XOR main_prng
Subsequent start:     44  (',') XOR main_prng
Key-value separator:  58  (':') XOR main_prng
Closing marker:       125 ('}') XOR main_prng XOR cid_prng
```

### Challenge Type Constants

| Constant | CAPTCHA | Interstitial |
|----------|---------|--------------|
| Main PRNG seed | `9959949970` | `9959949970` |
| Hash XOR | `-1748112727` | `-883841716` |
| CID PRNG constant | `1809053797` | `1809053797` |
| HSV | Dynamic | Fixed `"9E9FC74889F6"` |
| Base64 padding | Handled | Skipped |

### WASM Challenge Fields

Fields hashed by `wasm_b()` (varies per daily build):
```
hardwareConcurrency, br_oh, maxTouchPoints, maxTouchPoints
```

---

## 5. Akamai Bot Manager

### SHA-256 Constants (STABLE)

**Initial Hash Values (8 × uint32):**
```
H0 = 1779033703  (0x6a09e667)
H1 = 3144134277  (0xbb67ae85)
H2 = 1013904242  (0x3c6ef372)
H3 = 2773480762  (0xa54ff53a)
H4 = 1359893119  (0x510e527f)
H5 = 2600822924  (0x9b05688c)
H6 = 528734635   (0x1f83d9ab)
H7 = 1541459225  (0x5be0cd19)
```

**Round Constants (first 16 of 64):**
```
1116352408, 1899447441, 3049323471, 3921009573
961987163,  1508970993, 2453635748, 2870763221
3624381080, 310598401,  607225278,  1426881987
1925078388, 2162078206, 2614888103, 3248222580
```

### 58-Element Array (TIDAK STABIL)

- Exact field ordering embedded in obfuscated `akamai2.0.js` (line 4309)
- Canvas fingerprint at position ~21-22 (confirmed from `Kp(AE, [xln, UQ, YCn])` call)
- Delimiter character obfuscated — not extractable without full deobfuscation
- From traffic analysis: delimiter is likely `,` (comma) or `\t` (tab) depending on version

### Motion Trajectory Distance Calculation

```javascript
// From B8n() function at line 5320
sqrt((x0-x1)² + (x2-x3)² + (x4-x5)²)
```

### Cookie Values

```
_abck passed:   ...~-1~0~-1~-1
_abck failed:   ...~-1~-1~-1~-1
```

---

## 6. Cloudflare JSD Challenge

**ALL TIDAK STABIL** — rotate when Cloudflare updates `main.js`.

### Deobfuscation Parameters

```
DEOBFUSCATION_TARGET:   159113 (rotation target)
DEOBFUSCATION_OFFSET:   pattern: x = x - N (per-script, N varies)
LZ_ALPHABET:            64-char unique charset (per-script rotation)
FINGERPRINT_TEMPLATE:   ~1610 entries (per-script snapshot)
```

### Template Placeholders

```
__BASEURI__    → target URL
__ORIGIN__     → origin (scheme + host)
__HOST__       → hostname
__LASTMOD__    → current timestamp "01/02/2006 15:04:05"
```

### Oneshot POST Structure

```
Endpoint: /cdn-cgi/challenge-platform/h/{sitekey}/jsd/oneshot/{path}{r}
Fields:   t (int64), lhr ("about:blank"), api (false), c (false), payload (object)
Encoding: LZ-compressed to base64 using custom 64-char alphabet
Response: cf_clearance cookie
```

---

## 7. Cloudflare Turnstile

**ALL TIDAK STABIL** — rotate per-request.

### VM Constants

```
OPCODES:            28 (ADD, XOR, CALL, BTOA, RESOLVE, BIND_METHOD, JSON_STRINGIFY, ...)
REGISTER_ADDRESSES: Random floating-point values per request
PROGRAM_LENGTH:     417-580 instructions after decryption
ENCRYPTION:         Double-XOR (outer: p token, inner: float key in bytecode)
```

### Proof of Work

```
POW_ITERATIONS:  400,000-500,000 (uniform random)
POW_FIELDS:      25 fingerprint fields
POW_ALGORITHM:   SHA-256 cache
POW_FLAGS:       ai, createPRNG, cache, solana, dump, InstallTrigger, data
```

### Signal Orchestrator

```
INSTRUCTIONS:    271
EVENT_LISTENERS: keydown, pointermove, click, scroll, paste, wheel
PROPERTIES:      36 window.__oai_so_* properties
TOKEN_HEADER:    OpenAI-Sentinel-Turnstile-Token
OUTPUT:          JSON.stringify → XOR encrypt → RESOLVE return to parent frame
```

---

## 8. Kasada

### XTEA Algorithm Constants (STABLE)

```
DELTA:      0x9E3779B9 (2654435769)
ROUNDS:     32
BLOCK_SIZE: 64 bits (two 32-bit words)
```

### XTEA Encrypt (confirmed from deobfuscated ips.js)

```javascript
// 32 rounds:
sum = 0
for (var i = 0; i < 32; i++) {
    v0 = (v0 + (((v1 << 4) ^ (v1 >> 5)) + v1 ^ (sum + key[sum & 3]))) | 0
    sum = (sum + 2654435769) | 0
    v1 = (v1 + (((v0 << 4) ^ (v0 >> 5)) + v0 ^ (sum + key[(sum >> 11) & 3]))) | 0
}
```

### XTEA Key (TIDAK STABIL)

```
Size:      16 bytes (4 × uint32)
Location:  Embedded as integer array in ips.js bytecode
Rotation:  Every few weeks with bytecode rotation
Time-lock: ~5-hour decode window per script version
```

### VM Architecture

```
HANDLERS:       172 opcode handlers (proxy-dispatched)
BYTECODE:       Custom character-mapped scheme, variable-length, dynamic alphabet
PERMUTATION:    Fisher-Yates shuffle with embedded seed → maps raw opcodes to handler indices
SLOT_COUNT:     428 (template array)
PROBE_COUNT:    427 (in 20 batches, shuffled between batches)
```

### Proof of Work

```
ALGORITHM:      SHA256 chaining
SEED_PHRASE:    Per-domain constant (embedded in p.js)
DIFFICULTY:     Retrieved from /mfc endpoint
SUB-CHALLENGES: Multiple, solved sequentially
COST:           ~100ms CPU for real browser
```

### Output Headers

```
x-kpsdk-ct:  Client Token (expensive, ~30min TTL, reusable)
x-kpsdk-cd:  Client Data (cheap, per-request, <5s freshness)
x-kpsdk-h:   HMAC binding CT to CD
x-kpsdk-v:   Version identifier
x-kpsdk-r:   Request ID
```

---

## 9. Stability Assessment

| Provider | Stable Constants | Rotating/Unstable |
|----------|-----------------|-------------------|
| **Xiaomi** | RSA-1024 mod+exp, RSA-2048 mod+exp, AES charset (70/89), FIXED_IV, captcha key, sitekey | — |
| **X/Twitter XPFF** | AES base_key, GCM params (12B IV, 16B tag), epoch offset, hash salt, terminator byte | guest_id (per-session) |
| **Arkose** | MD5 chain algorithm, 21600s window, wire format, EVP_BytesToKey, MS public key | UA+timestamp (per-session) |
| **DataDome** | ALL PRNG seeds, XOR values, djb2, base64 mapping, buffer markers, HSV constants | Signal ordering in buffer |
| **Akamai** | SHA-256 initial values (8×uint32), round constants (64 values), distance formula | 58-element order, delimiter char |
| **CF/JSD** | — | LZ alphabet, template, deobfuscation target/offset (per-script-rotation) |
| **CF/Turnstile** | — | Float key, VM program, field serialization, PoW params (ALL per-request) |
| **Kasada** | XTEA_DELTA (0x9E3779B9), XTEA_ROUNDS (32), handler count (172), slot count (428) | XTEA key, seed phrase, slot layout (ALL per-deployment) |

### Bypass Feasibility by Provider

| Provider | Static Payload Forge | Browser Required | Notes |
|----------|---------------------|-----------------|-------|
| **Xiaomi** | ✅ Possible | No | RSA keys stable, AES deterministic, payload template static |
| **X/Twitter XPFF** | ✅ Possible | No | AES-GCM with static base_key, minimal payload (4 fields) |
| **Arkose** | ⚠️ Partial | Yes for challenges | Encryption stable, but behavioral signals need real interaction |
| **DataDome** | ⚠️ Partial | Yes for WASM | Encryption stable, but WASM challenge + dynamic HSV need browser |
| **Akamai** | ❌ Difficult | Yes | Array order obfuscated, canvas must be real, motion must be realistic |
| **CF/JSD** | ❌ Difficult | Yes | Template rotates, LZ alphabet rotates, no stable constants |
| **CF/Turnstile** | ❌ Impossible | Yes | ALL crypto rotates per-request, VM bytecode encrypted |
| **Kasada** | ❌ Impossible | Yes | XTEA key rotates, VM obfuscates, 428-slot layout not public |

---

*Last updated: 2026-07-11*
