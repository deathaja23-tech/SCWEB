module fingerprint-generator

go 1.21
