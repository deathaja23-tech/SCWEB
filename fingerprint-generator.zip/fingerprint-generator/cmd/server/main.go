package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	"fingerprint-generator/internal/antibot"
	_ "fingerprint-generator/internal/antibot/amazon"    // register the amazon target
	_ "fingerprint-generator/internal/antibot/datadome"  // register the datadome target
	_ "fingerprint-generator/internal/antibot/generic"   // register the generic target (default)
	_ "fingerprint-generator/internal/antibot/human"     // register the human (ex-PerimeterX) target
	_ "fingerprint-generator/internal/antibot/microsoft" // register the microsoft (Arkose) target
	_ "fingerprint-generator/internal/antibot/x"         // register the x (xpff/txid/arkose) target
	_ "fingerprint-generator/internal/antibot/xiaomi"    // register the xiaomi target
	"fingerprint-generator/internal/identity"
)

func main() {
	port := flag.Int("port", 8800, "Listen port")
	host := flag.String("host", "0.0.0.0", "Listen host")
	cacheDir := flag.String("cache-dir", "", "Cache directory (default: ~/.fingerprint-generator/)")
	flag.Parse()

	if *cacheDir != "" {
		identity.SetCacheDir(*cacheDir)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/fingerprint", handleFingerprint)
	mux.HandleFunc("/targets", handleTargets)
	mux.HandleFunc("/health", handleHealth)
	mux.HandleFunc("/stats", handleStats)
	mux.HandleFunc("/openapi.json", handleOpenAPI)
	mux.HandleFunc("/docs", handleDocs)

	addr := fmt.Sprintf("%s:%d", *host, *port)
	log.Printf("listening on %s", addr)
	log.Fatal(http.ListenAndServe(addr, corsLog(mux)))
}

func corsLog(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		w.Header().Set("Access-Control-Allow-Origin", "*")
		rw := &respWriter{ResponseWriter: w, status: 200}
		next.ServeHTTP(rw, r)
		log.Printf("%s %s %d %s", r.Method, r.URL.Path, rw.status, time.Since(start).Round(time.Microsecond))
	})
}

type respWriter struct {
	http.ResponseWriter
	status int
}

func (w *respWriter) WriteHeader(code int) {
	w.status = code
	w.ResponseWriter.WriteHeader(code)
}

func handleHealth(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, 200, map[string]string{"status": "ok"})
}

func handleStats(w http.ResponseWriter, _ *http.Request) {
	// ponytail: expose internal cache count; add when browser exports Stats()
	writeJSON(w, 200, map[string]interface{}{"cachedIdentities": -1, "note": "cache introspection not yet exposed"})
}

// handleTargets lists the registered (verified) target names in ascending order.
// Public metadata (names only), like the docs endpoints.
func handleTargets(w http.ResponseWriter, _ *http.Request) {
	names := antibot.Names()
	writeJSON(w, 200, map[string]interface{}{"targets": names, "count": len(names)})
}

func handleFingerprint(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	proxy := q.Get("proxy")
	chromeStr := q.Get("chrome")
	encryptStr := q.Get("encrypt")
	countStr := q.Get("count")
	country := strings.TrimSpace(q.Get("country"))

	// Validation order (most specific first): device → browser → target →
	// variant → required session inputs. Each failure returns 400 with no
	// fingerprint emitted.
	device, err := normalizeDevice(q.Get("device"))
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": err.Error()})
		return
	}
	browser, err := normalizeBrowser(q.Get("browser"))
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": err.Error()})
		return
	}

	targetName := q.Get("target")
	if targetName == "" {
		targetName = "generic"
	}
	tgt, err := antibot.MustGet(targetName)
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": err.Error()})
		return
	}
	caps := tgt.Capabilities()

	variant, err := resolveVariant(caps, q.Get("variant"))
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": err.Error()})
		return
	}

	sess := collectSessionInputs(q)
	if missing := checkRequiredInputs(caps, variant, sess); len(missing) > 0 {
		writeJSON(w, 400, map[string]string{
			"error": fmt.Sprintf("missing required session input(s) for target %q variant %q: %s",
				targetName, variant, strings.Join(missing, ", ")),
		})
		return
	}

	encrypt := encryptStr != "false" // default true
	pretty := q.Get("pretty") == "true"
	chrome := 0
	if chromeStr != "" {
		if v, err := strconv.Atoi(chromeStr); err == nil {
			chrome = v
		}
	}
	count := 1
	if countStr != "" {
		if v, err := strconv.Atoi(countStr); err == nil && v > 0 {
			if v > 100 {
				v = 100 // cap
			}
			count = v
		}
	}

	type fpResult struct {
		Identity    interface{}    `json:"identity"`
		Fingerprint fingerprintOut `json:"fingerprint"`
	}

	results := make([]fpResult, count)
	for i := 0; i < count; i++ {
		var id *identity.BrowserIdentity
		if proxy != "" {
			id = identity.IdentityForProxy(proxy)
		} else {
			id = identity.RandomIdentityWithOptions(identity.GenOptions{
				ChromeMajor: chrome,
				Country:     country,
				Device:      device,
				Browser:     browser,
			})
		}

		rawRes, err := tgt.Build(&antibot.BuildContext{
			Identity:      id,
			Variant:       variant,
			SessionInputs: sess,
			Encrypt:       encrypt,
			Page: antibot.PageContext{
				LocationURL: "https://example.com", PageType: "default", EventType: "PageLoad",
			},
		})
		if err != nil {
			writeJSON(w, 500, map[string]string{"error": err.Error()})
			return
		}

		extras := tgt.IdentityExtras(id)
		idJSON := buildIdentityMap(id, extras)
		fp := fingerprintOut{Raw: rawRes.Raw, EncryptionApplicable: caps.EncryptionApplicable}
		if encrypt && caps.EncryptionApplicable {
			fp.Encrypted = rawRes.Encoded
		}
		results[i] = fpResult{Identity: idJSON, Fingerprint: fp}
	}

	var payload interface{} = results[0]
	if count != 1 {
		payload = map[string]interface{}{"count": count, "fingerprints": results}
	}
	if pretty {
		writeJSONPretty(w, 200, payload)
	} else {
		writeJSON(w, 200, payload)
	}
}

// sessionInputKeys is the allowlist of per-request Session_Input query params
// collected into antibot.SessionInputs.
var sessionInputKeys = []string{
	"guest_id", "sitekey", "cid", "path", "token", "difficulty", "prefix",
	"method", "verification", "ptoken", "cookies", "url", "hash", "animation_key",
}

func collectSessionInputs(q map[string][]string) antibot.SessionInputs {
	sess := antibot.SessionInputs{}
	for _, k := range sessionInputKeys {
		if vs, ok := q[k]; ok && len(vs) > 0 {
			sess[k] = vs[0]
		}
	}
	return sess
}

// normalizeDevice accepts "desktop"/"mobile" (case-insensitive, trimmed) or
// empty; anything else is a 400 (Requirement 7.4, 7.8).
func normalizeDevice(raw string) (string, error) {
	v := strings.ToLower(strings.TrimSpace(raw))
	switch v {
	case "":
		return "", nil
	case "desktop", "mobile":
		return v, nil
	default:
		return "", fmt.Errorf("unsupported device %q (accepted: desktop, mobile)", raw)
	}
}

// normalizeBrowser accepts "chrome"/"firefox"/"safari" (case-insensitive,
// trimmed) or empty; anything else is a 400 (Requirement 7.5, 7.9).
func normalizeBrowser(raw string) (string, error) {
	v := strings.ToLower(strings.TrimSpace(raw))
	switch v {
	case "":
		return "", nil
	case "chrome", "firefox", "safari":
		return v, nil
	default:
		return "", fmt.Errorf("unsupported browser %q (accepted: chrome, firefox, safari)", raw)
	}
}

// resolveVariant selects/validates the Target_Variant (Requirement 9.5/9.6/9.8/9.9).
func resolveVariant(caps antibot.Capabilities, raw string) (string, error) {
	v := strings.TrimSpace(raw)
	if len(caps.Variants) == 0 {
		if v != "" {
			return "", fmt.Errorf("target exposes no selectable variant")
		}
		return "", nil
	}
	if v == "" {
		return caps.DefaultVariant, nil
	}
	for _, name := range caps.Variants {
		if strings.EqualFold(name, v) {
			return name, nil
		}
	}
	return "", fmt.Errorf("unsupported variant %q (available: %s)", raw, strings.Join(caps.Variants, ", "))
}

// checkRequiredInputs returns the required Session_Input keys missing for the
// selected variant (Requirement 9.3).
func checkRequiredInputs(caps antibot.Capabilities, variant string, sess antibot.SessionInputs) []string {
	var missing []string
	for _, k := range caps.RequiredInputs[variant] {
		if !sess.Has(k) {
			missing = append(missing, k)
		}
	}
	return missing
}

type fingerprintOut struct {
	Raw                  json.RawMessage `json:"raw"`
	Encrypted            string          `json:"encrypted,omitempty"`
	EncryptionApplicable bool            `json:"encryptionApplicable"`
}

// buildIdentityMap emits the Identity_Core fields, then overlays any keys a
// target contributes via IdentityExtras. Targets with no extras (e.g. generic)
// show only core fields; amazon overlays webpackHash. Chromium-only client-hint
// fields are omitted (omitempty) for non-Chrome identities.
func buildIdentityMap(id *identity.BrowserIdentity, extras map[string]interface{}) map[string]interface{} {
	hist := make([]int, 256)
	copy(hist, id.HistogramBase[:])

	m := map[string]interface{}{
		"chromeVersion": id.ChromeVer,
		"userAgent":     id.UA,
		"platform":      id.Platform,
		"gpuVendor":     id.GPUVendor,
		"gpuModel":      id.GPUModel,
		"webglExtensions": id.WebGLExts,
		"canvasHash":      id.CanvasHash,
		"histogram":       hist,
		"mathTan":         id.MathTan,
		"mathSin":         id.MathSin,
		"mathCos":         id.MathCos,
		"audioFingerprint": id.AudioFingerprint,
		"plugins":          id.Plugins,
		"screen": map[string]interface{}{
			"width":            id.Screen.Width,
			"height":           id.Screen.Height,
			"availWidth":       id.Screen.AvailWidth,
			"availHeight":      id.Screen.AvailHeight,
			"colorDepth":       id.Screen.ColorDepth,
			"devicePixelRatio": id.Screen.DevicePixelRatio,
		},
		"deviceMemory":        id.DeviceMemory,
		"hardwareConcurrency": id.HardwareConcurrency,
		"timeZone":            id.TimeZone,
		"languages":           id.Languages,
		"locale":              id.Locale,
		"fonts":               id.Fonts,
	}

	// Chromium-only client hints: include only when present (non-Chrome omits them).
	if id.SecUA != "" {
		m["secUA"] = id.SecUA
	}
	if id.SecCHUAPlatform != "" {
		m["secChUaPlatform"] = id.SecCHUAPlatform
	}
	if id.SecCHUAMobile != "" {
		m["secChUaMobile"] = id.SecCHUAMobile
	}
	// Device/browser coverage fields.
	if id.DeviceType != "" {
		m["deviceType"] = id.DeviceType
	}
	if id.BrowserFamily != "" {
		m["browserFamily"] = id.BrowserFamily
	}
	if id.MobilePlatform != "" {
		m["mobilePlatform"] = id.MobilePlatform
	}

	// Overlay target-specific extras (e.g. amazon webpackHash).
	for k, v := range extras {
		m[k] = v
	}
	return m
}

func writeJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func writeJSONPretty(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	enc.Encode(v)
}

// handleDocs serves Swagger UI (CDN assets) pointed at /openapi.json.
func handleDocs(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write([]byte(swaggerHTML))
}

// handleOpenAPI serves the hand-written OpenAPI 3 spec (kept in sync with handlers;
// zero Go deps by design, so no codegen).
func handleOpenAPI(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(openapiJSON))
}
