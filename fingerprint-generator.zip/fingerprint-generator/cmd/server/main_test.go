package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"reflect"
	"sort"
	"strings"
	"testing"
	"testing/quick"

	"fingerprint-generator/internal/antibot"
)

func getFP(query string) (int, map[string]interface{}) {
	req := httptest.NewRequest(http.MethodGet, "/fingerprint?"+query, nil)
	rr := httptest.NewRecorder()
	handleFingerprint(rr, req)
	var body map[string]interface{}
	_ = json.Unmarshal(rr.Body.Bytes(), &body)
	return rr.Code, body
}

// getFPParams builds a properly URL-encoded query from a param map (safe for
// values containing whitespace or special characters).
func getFPParams(params map[string]string) (int, map[string]interface{}) {
	vals := url.Values{}
	for k, v := range params {
		vals.Set(k, v)
	}
	return getFP(vals.Encode())
}

func getTargets() (int, map[string]interface{}) {
	req := httptest.NewRequest(http.MethodGet, "/targets", nil)
	rr := httptest.NewRecorder()
	handleTargets(rr, req)
	var body map[string]interface{}
	_ = json.Unmarshal(rr.Body.Bytes(), &body)
	return rr.Code, body
}

func fpBlock(body map[string]interface{}) map[string]interface{} {
	fp, _ := body["fingerprint"].(map[string]interface{})
	return fp
}
func idBlock(body map[string]interface{}) map[string]interface{} {
	id, _ := body["identity"].(map[string]interface{})
	return id
}

// Feature: global-fingerprint-optimization, Property 3: Generic applies no encryption envelope — encryptionApplicable is false and the encrypted field is omitted even when encrypt=true.
func TestProperty3_GenericNoEncryption(t *testing.T) {
	for _, q := range []string{"", "encrypt=true", "target=generic&encrypt=true", "device=mobile&encrypt=true"} {
		code, body := getFP(q)
		if code != 200 {
			t.Fatalf("q=%q code=%d", q, code)
		}
		fp := fpBlock(body)
		if fp["encryptionApplicable"] != false {
			t.Fatalf("q=%q encryptionApplicable != false: %v", q, fp["encryptionApplicable"])
		}
		if _, ok := fp["encrypted"]; ok {
			t.Fatalf("q=%q generic must omit encrypted", q)
		}
	}
}

// Feature: global-fingerprint-optimization, Property 4: No-extras identity view purity — a target whose IdentityExtras is nil (generic) yields an identity view with only Identity_Core fields and no extras keys.
func TestProperty4_NoExtrasIdentityPurity(t *testing.T) {
	f := func(d, b, c uint8) bool {
		devices := []string{"", "desktop", "mobile"}
		browsers := []string{"", "chrome", "firefox", "safari"}
		countries := []string{"", "us", "jp"}
		q := "device=" + devices[int(d)%3] + "&browser=" + browsers[int(b)%4] + "&country=" + countries[int(c)%3]
		code, body := getFP(q)
		if code != 200 {
			return false
		}
		id := idBlock(body)
		// No target-specific extras for generic.
		if _, ok := id["webpackHash"]; ok {
			return false
		}
		if _, ok := id["arkosePublicKey"]; ok {
			return false
		}
		return true
	}
	if err := quick.Check(f, &quick.Config{MaxCount: 150}); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 12: Registry listing is sorted and reflects membership — /targets is ascending and equals exactly the registered set.
func TestProperty12_TargetsListingSorted(t *testing.T) {
	code, body := getTargets()
	if code != 200 {
		t.Fatalf("/targets code=%d", code)
	}
	rawList, _ := body["targets"].([]interface{})
	got := make([]string, len(rawList))
	for i, v := range rawList {
		got[i], _ = v.(string)
	}
	if !sort.StringsAreSorted(got) {
		t.Fatalf("/targets not sorted: %v", got)
	}
	want := antibot.Names()
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("/targets %v != registry Names() %v", got, want)
	}
	// Verified set (Tier A + generic). datadome + human are byte-accurate
	// (golden round-trip against tags.js v5.8.0) and now registered.
	expect := []string{"amazon", "datadome", "generic", "human", "microsoft", "x", "xiaomi"}
	if !reflect.DeepEqual(got, expect) {
		t.Fatalf("/targets %v != expected verified set %v", got, expect)
	}
}

// Feature: global-fingerprint-optimization, Property 14: Unknown-target rejection — an unregistered target yields 400 listing registered names and no fingerprint.
func TestProperty14_UnknownTargetRejected(t *testing.T) {
	registered := map[string]bool{}
	for _, n := range antibot.Names() {
		registered[n] = true
	}
	f := func(name string) bool {
		name = strings.TrimSpace(name)
		if name == "" || registered[name] {
			return true // skip valid/empty
		}
		code, body := getFPParams(map[string]string{"target": name})
		if code != 400 {
			return false
		}
		if _, ok := body["fingerprint"]; ok {
			return false
		}
		msg, _ := body["error"].(string)
		return strings.Contains(msg, "amazon") && strings.Contains(msg, "generic")
	}
	if err := quick.Check(f, &quick.Config{MaxCount: 150}); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 15: Device/browser parameter normalization — accepted values in any casing/whitespace are accepted (200).
func TestProperty15_DeviceBrowserNormalization(t *testing.T) {
	deco := func(s string, padL, padR, up bool) string {
		if up {
			s = strings.ToUpper(s)
		}
		if padL {
			s = "  " + s
		}
		if padR {
			s = s + "\t"
		}
		return s
	}
	f := func(dsel, bsel uint8, padL, padR, up bool) bool {
		devices := []string{"desktop", "mobile"}
		browsers := []string{"chrome", "firefox", "safari"}
		code, _ := getFPParams(map[string]string{
			"device":  deco(devices[int(dsel)%2], padL, padR, up),
			"browser": deco(browsers[int(bsel)%3], padR, padL, up),
		})
		return code == 200
	}
	if err := quick.Check(f, &quick.Config{MaxCount: 150}); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 16: Invalid device/browser rejection — non-empty values matching none of the accepted set yield 400 listing accepted values and no fingerprint.
func TestProperty16_InvalidDeviceBrowserRejected(t *testing.T) {
	valid := map[string]bool{"desktop": true, "mobile": true, "chrome": true, "firefox": true, "safari": true}
	f := func(val string) bool {
		v := strings.ToLower(strings.TrimSpace(val))
		if v == "" || valid[v] {
			return true
		}
		// device path
		code, body := getFPParams(map[string]string{"device": val})
		if code != 400 {
			return false
		}
		if _, ok := body["fingerprint"]; ok {
			return false
		}
		msg, _ := body["error"].(string)
		if !strings.Contains(msg, "desktop") || !strings.Contains(msg, "mobile") {
			return false
		}
		// browser path
		code2, body2 := getFPParams(map[string]string{"browser": val})
		if code2 != 400 {
			return false
		}
		msg2, _ := body2["error"].(string)
		return strings.Contains(msg2, "chrome") && strings.Contains(msg2, "firefox") && strings.Contains(msg2, "safari")
	}
	if err := quick.Check(f, &quick.Config{MaxCount: 150}); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 19: Variant selection and validation — valid variant selects, omitted selects default, unsupported yields 400 listing variants; single-output target rejects any non-empty variant.
func TestProperty19_VariantSelectionValidation(t *testing.T) {
	// x is multi-variant; supply required inputs so only variant validation gates.
	base := "target=x&guest_id=v1%3A1&method=POST&path=/i&verification=a2V5&animation_key=k"
	// valid explicit variant
	if code, _ := getFP(base + "&variant=xpff"); code != 200 {
		t.Fatalf("valid variant xpff should be 200, got %d", code)
	}
	// case-insensitive
	if code, _ := getFP(base + "&variant=ARKOSE&sitekey=PK"); code != 200 {
		t.Fatalf("valid variant ARKOSE should be 200, got %d", code)
	}
	// omitted → default (xpff) with guest_id present
	if code, _ := getFP(base); code != 200 {
		t.Fatalf("omitted variant should default to xpff (200), got %d", code)
	}
	// unsupported variant → 400 listing variants
	code, body := getFP(base + "&variant=bogus")
	if code != 400 {
		t.Fatalf("unsupported variant should be 400, got %d", code)
	}
	msg, _ := body["error"].(string)
	if !strings.Contains(msg, "xpff") || !strings.Contains(msg, "txid") || !strings.Contains(msg, "arkose") {
		t.Fatalf("unsupported-variant error should list variants, got %q", msg)
	}
	// single-output target (generic) with non-empty variant → 400
	code2, body2 := getFP("target=generic&variant=whatever")
	if code2 != 400 {
		t.Fatalf("single-output variant should be 400, got %d", code2)
	}
	if _, ok := body2["fingerprint"]; ok {
		t.Fatal("single-output variant 400 must not emit fingerprint")
	}
}

// Feature: global-fingerprint-optimization, Property 20: Missing required session input is rejected — omitting/blanking a required input yields 400 naming it, with no fabricated substitute.
func TestProperty20_MissingRequiredSessionInput(t *testing.T) {
	// x/xpff requires guest_id.
	code, body := getFP("target=x&variant=xpff")
	if code != 400 {
		t.Fatalf("missing guest_id should be 400, got %d", code)
	}
	if _, ok := body["fingerprint"]; ok {
		t.Fatal("missing-input 400 must not emit fingerprint")
	}
	if msg, _ := body["error"].(string); !strings.Contains(msg, "guest_id") {
		t.Fatalf("error must name guest_id, got %q", msg)
	}
	// blank (whitespace) guest_id also rejected (no fabricated substitute).
	if code, _ := getFP("target=x&variant=xpff&guest_id=%20%20"); code != 400 {
		t.Fatalf("whitespace guest_id should be 400, got %d", code)
	}
	// x/txid requires method,path,verification,animation_key — supply only method.
	code2, body2 := getFP("target=x&variant=txid&method=POST")
	if code2 != 400 {
		t.Fatalf("partial txid inputs should be 400, got %d", code2)
	}
	if msg, _ := body2["error"].(string); !strings.Contains(msg, "path") {
		t.Fatalf("error must name a missing input (path), got %q", msg)
	}
}

// ---- Integration / smoke (Task 22) ----

func TestIntegration_TargetsEndpoint(t *testing.T) {
	code, body := getTargets()
	if code != 200 {
		t.Fatalf("/targets code=%d", code)
	}
	if _, ok := body["targets"]; !ok {
		t.Fatal("/targets missing 'targets'")
	}
}

func TestIntegration_AmazonEnvelopeAndEncryptFalse(t *testing.T) {
	// encrypt default → ECdITeCs envelope present.
	code, body := getFP("target=amazon")
	if code != 200 {
		t.Fatalf("amazon code=%d", code)
	}
	fp := fpBlock(body)
	if fp["encryptionApplicable"] != true {
		t.Fatal("amazon encryptionApplicable must be true")
	}
	enc, _ := fp["encrypted"].(string)
	if !strings.HasPrefix(enc, "ECdITeCs:") {
		t.Fatalf("amazon envelope must start with ECdITeCs:, got %.12s", enc)
	}
	// webpackHash present in identity view.
	if wh, _ := idBlock(body)["webpackHash"].(string); wh == "" {
		t.Fatal("amazon identity must include webpackHash")
	}
	// encrypt=false → no encrypted field.
	_, body2 := getFP("target=amazon&encrypt=false")
	if _, ok := fpBlock(body2)["encrypted"]; ok {
		t.Fatal("amazon encrypt=false must omit encrypted")
	}
}

func TestIntegration_CountBoundaries(t *testing.T) {
	// count=1 → single result (has identity); count=5 → batch.
	_, single := getFP("count=1")
	if _, ok := single["identity"]; !ok {
		t.Fatal("count=1 must be a single result")
	}
	_, batch := getFP("count=5")
	if c, _ := batch["count"].(float64); int(c) != 5 {
		t.Fatalf("count=5 must yield batch of 5, got %v", batch["count"])
	}
	// count over cap clamps to 100.
	_, big := getFP("count=1000")
	if c, _ := big["count"].(float64); int(c) != 100 {
		t.Fatalf("count=1000 must clamp to 100, got %v", big["count"])
	}
	// count=0/invalid → default single.
	_, zero := getFP("count=0")
	if _, ok := zero["identity"]; !ok {
		t.Fatal("count=0 must fall back to single result")
	}
}

// Smoke — zero external dependencies (Requirement 1.2, 6.1).
func TestSmoke_ZeroDependencies(t *testing.T) {
	modBytes, err := os.ReadFile("../../go.mod")
	if err != nil {
		t.Fatalf("read go.mod: %v", err)
	}
	if strings.Contains(string(modBytes), "require") {
		t.Fatalf("go.mod must not contain a require directive (zero external deps):\n%s", modBytes)
	}
	if _, err := os.Stat("../../go.sum"); err == nil {
		t.Fatal("go.sum exists — external dependencies are not allowed")
	}
}

// Example: defaults — no target → generic (no encryption); no device/browser →
// desktop Chrome; webpackHash present for amazon and absent for generic.
func TestExample_Defaults(t *testing.T) {
	_, body := getFP("")
	if fpBlock(body)["encryptionApplicable"] != false {
		t.Fatal("default target must be generic (encryptionApplicable=false)")
	}
	id := idBlock(body)
	if id["deviceType"] != "desktop" || id["browserFamily"] != "chrome" {
		t.Fatalf("default identity must be desktop chrome, got device=%v browser=%v", id["deviceType"], id["browserFamily"])
	}
	plat, _ := id["platform"].(string)
	if plat != "Win32" && plat != "MacIntel" && plat != "Linux x86_64" {
		t.Fatalf("default desktop platform unexpected: %q", plat)
	}
	if _, ok := id["webpackHash"]; ok {
		t.Fatal("generic identity must not include webpackHash")
	}
	_, abody := getFP("target=amazon")
	if wh, _ := idBlock(abody)["webpackHash"].(string); wh == "" {
		t.Fatal("amazon identity must include webpackHash")
	}
}
