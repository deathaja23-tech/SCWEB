package main

// swaggerHTML renders Swagger UI (assets from the public CDN) against /openapi.json.
const swaggerHTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Fingerprint Generator — API Docs</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css">
  <style>body{margin:0}</style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.onload = () => {
      window.ui = SwaggerUIBundle({
        url: "openapi.json",
        dom_id: "#swagger-ui",
        deepLinking: true,
        presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
      });
    };
  </script>
</body>
</html>`

// openapiJSON is the hand-written OpenAPI 3 spec (zero Go deps by design — no codegen).
// Keep in sync with handleFingerprint's params + output shape.
const openapiJSON = `{
  "openapi": "3.0.3",
  "info": {
    "title": "Fingerprint Generator",
    "version": "1.0.0",
    "description": "Generates realistic browser fingerprints (GPU, WebGL, canvas, screen, fonts, math, audio, timing) across desktop/mobile and Chrome/Firefox/Safari, then shapes them into a per-antibot **target** payload + envelope. A generic identity core feeds pluggable targets.\n\n**Default target is 'generic'** — a flat, self-describing identity payload with no encryption. Verified named targets: amazon, datadome, human, microsoft, x, xiaomi. Held/scaffold targets (akamai, cloudflare, kasada) are intentionally NOT registered and return 400 (their reverse-engineered constants are rotating/unavailable). Use GET /targets for the live list.\n\n**Auth:** through the public domain every path except /health, /docs, /openapi.json, /targets requires a Bearer token (enforced at the Caddy layer). On localhost no auth."
  },
  "servers": [
    { "url": "https://fp.example.com", "description": "Public (Bearer token)" },
    { "url": "http://127.0.0.1:8800", "description": "Local (no auth)" }
  ],
  "tags": [
    { "name": "fingerprint", "description": "Generate fingerprints" },
    { "name": "monitoring", "description": "Liveness and cache stats" }
  ],
  "components": {
    "securitySchemes": {
      "bearerAuth": { "type": "http", "scheme": "bearer" }
    },
    "schemas": {
      "Identity": {
        "type": "object",
        "description": "Target-agnostic browser identity. Field set is stable; consumers read by name.",
        "properties": {
          "chromeVersion": { "type": "string", "example": "131.0.0.0" },
          "userAgent": { "type": "string" },
          "secUA": { "type": "string", "description": "Chromium-only; omitted for Firefox/Safari" },
          "secChUaPlatform": { "type": "string", "example": "Windows", "description": "Chromium-only; omitted for Firefox/Safari" },
          "secChUaMobile": { "type": "string", "example": "?0", "description": "Chromium-only; ?1 for mobile Chrome" },
          "deviceType": { "type": "string", "enum": ["desktop", "mobile"] },
          "browserFamily": { "type": "string", "enum": ["chrome", "firefox", "safari"] },
          "mobilePlatform": { "type": "string", "enum": ["android", "ios"], "description": "Present for mobile identities" },
          "gpuVendor": { "type": "string" },
          "gpuModel": { "type": "string" },
          "webglExtensions": { "type": "array", "items": { "type": "string" } },
          "canvasHash": { "type": "integer", "format": "int32" },
          "histogram": { "type": "array", "items": { "type": "integer" }, "minItems": 256, "maxItems": 256 },
          "mathTan": { "type": "string" },
          "mathSin": { "type": "string" },
          "mathCos": { "type": "string" },
          "audioFingerprint": { "type": "string" },
          "plugins": { "type": "array", "items": { "type": "object", "additionalProperties": { "type": "string" } } },
          "screen": {
            "type": "object",
            "properties": {
              "width": { "type": "integer" }, "height": { "type": "integer" },
              "availWidth": { "type": "integer" }, "availHeight": { "type": "integer" },
              "colorDepth": { "type": "integer" }, "devicePixelRatio": { "type": "integer" }
            }
          },
          "deviceMemory": { "type": "integer" },
          "hardwareConcurrency": { "type": "integer" },
          "platform": { "type": "string", "example": "Win32" },
          "timeZone": { "type": "integer", "example": -5 },
          "languages": { "type": "array", "items": { "type": "string" } },
          "locale": { "type": "string", "example": "en-US" },
          "fonts": { "type": "array", "items": { "type": "string" } },
          "webpackHash": { "type": "string", "description": "Amazon target extra (present when target=amazon)" },
          "arkosePublicKey": { "type": "string", "description": "Arkose target extra (present when target=microsoft)" }
        }
      },
      "Fingerprint": {
        "type": "object",
        "properties": {
          "raw": { "type": "object", "description": "Target payload. generic: flat identity object. amazon: metrics/lsUbid/… (order-sensitive)." },
          "encrypted": { "type": "string", "description": "Present only when the target defines an envelope and encrypt!=false. amazon: ECdITeCs:<base64>; x/xpff: hex(iv||ct||tag); xiaomi: s=…&d=…&a=register; microsoft/x arkose: base64({ct,iv,s})." },
          "encryptionApplicable": { "type": "boolean", "description": "false for generic (no envelope); true for enveloped targets." }
        }
      },
      "FingerprintResult": {
        "type": "object",
        "properties": {
          "identity": { "$ref": "#/components/schemas/Identity" },
          "fingerprint": { "$ref": "#/components/schemas/Fingerprint" }
        }
      },
      "FingerprintBatch": {
        "type": "object",
        "properties": {
          "count": { "type": "integer" },
          "fingerprints": { "type": "array", "items": { "$ref": "#/components/schemas/FingerprintResult" } }
        }
      },
      "Error": { "type": "object", "properties": { "error": { "type": "string" } } }
    }
  },
  "paths": {
    "/health": {
      "get": {
        "tags": ["monitoring"],
        "summary": "Liveness (public, no auth)",
        "security": [],
        "responses": { "200": { "description": "OK", "content": { "application/json": { "schema": { "type": "object", "properties": { "status": { "type": "string", "example": "ok" } } } } } } }
      }
    },
    "/fingerprint": {
      "get": {
        "tags": ["fingerprint"],
        "summary": "Generate fingerprint(s)",
        "description": "Returns a single FingerprintResult when count=1, otherwise a FingerprintBatch. The payload schema + encryption envelope are chosen by target.",
        "security": [{ "bearerAuth": [] }],
        "parameters": [
          { "name": "count", "in": "query", "schema": { "type": "integer", "default": 1, "minimum": 1, "maximum": 100 }, "description": "Number of fingerprints (max 100)" },
          { "name": "proxy", "in": "query", "schema": { "type": "string" }, "description": "Proxy URL to bind identity to (same host reuses the identity for 6h; supports proxy-provider __cr.<cc> region hint)" },
          { "name": "chrome", "in": "query", "schema": { "type": "integer" }, "description": "Pin Chrome major version (e.g. 131)" },
          { "name": "target", "in": "query", "schema": { "type": "string", "enum": ["generic", "amazon", "datadome", "human", "microsoft", "x", "xiaomi"], "default": "generic" }, "description": "Antibot target / payload schema (see GET /targets). Unknown target → 400." },
          { "name": "variant", "in": "query", "schema": { "type": "string" }, "description": "Target variant when the target exposes more than one (x: xpff|txid|arkose). Invalid/unsupported → 400." },
          { "name": "device", "in": "query", "schema": { "type": "string", "enum": ["desktop", "mobile"] }, "description": "Device type (case-insensitive). Invalid → 400." },
          { "name": "browser", "in": "query", "schema": { "type": "string", "enum": ["chrome", "firefox", "safari"] }, "description": "Browser family (case-insensitive). Invalid → 400." },
          { "name": "country", "in": "query", "schema": { "type": "string", "example": "jp" }, "description": "ISO 3166-1 alpha-2 region hint (case-insensitive). Unknown/empty → weighted-random region." },
          { "name": "encrypt", "in": "query", "schema": { "type": "string", "enum": ["true", "false"], "default": "true" }, "description": "Set false to omit fingerprint.encrypted (no effect for generic)" },
          { "name": "pretty", "in": "query", "schema": { "type": "string", "enum": ["true", "false"], "default": "false" }, "description": "Pretty-print the JSON response" },
          { "name": "guest_id", "in": "query", "schema": { "type": "string" }, "description": "Session input — required for target=x variant=xpff" },
          { "name": "sitekey", "in": "query", "schema": { "type": "string" }, "description": "Session input — required for target=x variant=arkose" },
          { "name": "method", "in": "query", "schema": { "type": "string" }, "description": "Session input — required for target=x variant=txid" },
          { "name": "path", "in": "query", "schema": { "type": "string" }, "description": "Session input — required for target=x variant=txid" },
          { "name": "verification", "in": "query", "schema": { "type": "string" }, "description": "Session input (base64 key bytes) — required for target=x variant=txid" },
          { "name": "animation_key", "in": "query", "schema": { "type": "string" }, "description": "Session input — required for target=x variant=txid (cannot be synthesized)" },
          { "name": "url", "in": "query", "schema": { "type": "string" }, "description": "Session input — optional page URL (e.g. xiaomi)" }
        ],
        "responses": {
          "200": {
            "description": "Fingerprint(s)",
            "content": { "application/json": { "schema": { "oneOf": [ { "$ref": "#/components/schemas/FingerprintResult" }, { "$ref": "#/components/schemas/FingerprintBatch" } ] } } }
          },
          "400": { "description": "Unknown target, unsupported variant/device/browser, or missing required session input", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } },
          "500": { "description": "Build/encrypt error", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } }
        }
      }
    },
    "/targets": {
      "get": {
        "tags": ["monitoring"],
        "summary": "List registered (verified) targets (public, no auth)",
        "description": "Returns the target names currently registered — only verified targets that can emit a correct payload/envelope. Held/scaffold targets are excluded.",
        "security": [],
        "responses": { "200": { "description": "Target list", "content": { "application/json": { "schema": { "type": "object", "properties": { "targets": { "type": "array", "items": { "type": "string" } }, "count": { "type": "integer" } } } } } } }
      }
    },
    "/stats": {
      "get": {
        "tags": ["monitoring"],
        "summary": "Cache statistics",
        "security": [{ "bearerAuth": [] }],
        "responses": { "200": { "description": "Stats", "content": { "application/json": { "schema": { "type": "object" } } } } }
      }
    }
  }
}`
