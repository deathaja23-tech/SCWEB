// Package identity generates target-agnostic browser fingerprint identities
// (Chrome version, GPU, WebGL, canvas, screen, fonts, audio, math, hardware,
// region). Antibot-specific payload shaping lives in internal/antibot/*.
package identity

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math/rand"
	"sort"
	"strings"
)

// Chrome version support ────────────────────

type chromeVersion struct {
	Version string
	SecUA   string
}

// genChromeVersion generates a random Chrome version with matching Sec-CH-UA.
func genChromeVersion() chromeVersion {
	versions := []string{
		"120", "121", "122", "123", "124", "125", "126", "127", "128", "129",
		"130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
		"140", "141", "142", "143", "144", "145", "146", "147", "148", "149",
		"150", "151",
	}
	v := versions[rand.Intn(len(versions))]

	greaseBrands := []string{"Not_A Brand", "Not(A:Brand", "Not-A.Brand", "Not)A;Brand", "Not/A)Brand", "Not A;Brand", "Not?A_Brand"}
	greaseBrand := greaseBrands[rand.Intn(len(greaseBrands))]
	greaseVer := fmt.Sprintf("%d", 8+rand.Intn(92)) // 8~99

	secUA := fmt.Sprintf(`"%s";v="%s", "Chromium";v="%s", "Google Chrome";v="%s"`, greaseBrand, greaseVer, v, v)
	return chromeVersion{
		Version: v + ".0.0.0",
		SecUA:   secUA,
	}
}

// genChromeVersionWithPin generates a Chrome version pinned to a specific major version.
func genChromeVersionWithPin(major int) chromeVersion {
	v := fmt.Sprintf("%d", major)

	greaseBrands := []string{"Not_A Brand", "Not(A:Brand", "Not-A.Brand", "Not)A;Brand", "Not/A)Brand", "Not A;Brand", "Not?A_Brand"}
	greaseBrand := greaseBrands[rand.Intn(len(greaseBrands))]
	greaseVer := fmt.Sprintf("%d", 8+rand.Intn(92))

	secUA := fmt.Sprintf(`"%s";v="%s", "Chromium";v="%s", "Google Chrome";v="%s"`, greaseBrand, greaseVer, v, v)
	return chromeVersion{
		Version: v + ".0.0.0",
		SecUA:   secUA,
	}
}

// WebGL extensions ────────────────────

var webglExtCore = []string{
	"ANGLE_instanced_arrays", "EXT_blend_minmax", "EXT_color_buffer_half_float",
	"EXT_float_blend", "EXT_frag_depth", "EXT_shader_texture_lod",
	"EXT_texture_filter_anisotropic", "EXT_sRGB", "KHR_parallel_shader_compile",
	"OES_element_index_uint", "OES_fbo_render_mipmap", "OES_standard_derivatives",
	"OES_texture_float", "OES_texture_float_linear", "OES_texture_half_float",
	"OES_texture_half_float_linear", "OES_vertex_array_object",
	"WEBGL_color_buffer_float", "WEBGL_compressed_texture_s3tc",
	"WEBGL_compressed_texture_s3tc_srgb", "WEBGL_debug_renderer_info",
	"WEBGL_debug_shaders", "WEBGL_depth_texture", "WEBGL_draw_buffers",
	"WEBGL_lose_context", "WEBGL_multi_draw",
}

var webglExtOptional = []string{
	"EXT_disjoint_timer_query", "EXT_texture_compression_bptc",
	"EXT_texture_compression_rgtc", "WEBGL_compressed_texture_astc",
	"WEBGL_compressed_texture_etc", "OES_draw_buffers_indexed",
	"EXT_color_buffer_float",
}

// Plugins (Chrome built-in) ────────────────────

var pluginsPool = []map[string]string{
	{"name": "PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
	{"name": "Chrome PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
	{"name": "Chromium PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
	{"name": "Microsoft Edge PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
	{"name": "WebKit built-in PDF", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
}

// Platform constants ────────────────────

const (
	platWindows = "Win32"
	platMacOS   = "MacIntel"
	platLinux   = "Linux x86_64"
	platAndroid = "Linux armv8l" // navigator.platform for Android Chrome
	platIOS     = "iPhone"       // navigator.platform for iOS Safari
)

// Device type / browser family / mobile platform constants ────────────────────

const (
	deviceDesktop = "desktop"
	deviceMobile  = "mobile"

	browserChrome  = "chrome"
	browserFirefox = "firefox"
	browserSafari  = "safari"

	mobileAndroid = "android"
	mobileIOS     = "ios"
)

// Hardware tier constants ────────────────────

const (
	tierLow  = 0
	tierMid  = 1
	tierHigh = 2
)

// Font pools per platform ────────────────────

var fontsWindows = []string{
	"Arial", "Arial Black", "Bahnschrift", "Calibri", "Cambria", "Cambria Math",
	"Candara", "Comic Sans MS", "Consolas", "Constantia", "Corbel", "Courier New",
	"Ebrima", "Franklin Gothic Medium", "Gabriola", "Gadugi", "Georgia", "Impact",
	"Ink Free", "Javanese Text", "Leelawadee UI", "Lucida Console", "Lucida Sans Unicode",
	"Malgun Gothic", "Marlett", "Microsoft Himalaya", "Microsoft JhengHei",
	"Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Sans Serif",
	"Microsoft Tai Le", "Microsoft YaHei", "MingLiU-ExtB", "Mongolian Baiti",
	"MS Gothic", "MV Boli", "Myanmar Text", "Nirmala UI", "Palatino Linotype",
	"Segoe MDL2 Assets", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Emoji",
	"Segoe UI Historic", "Segoe UI Symbol", "SimSun", "Sitka", "Sylfaen", "Symbol",
	"Tahoma", "Times New Roman", "Trebuchet MS", "Verdana", "Webdings", "Wingdings",
	"Yu Gothic",
}

var fontsMacOS = []string{
	"American Typewriter", "Andale Mono", "Arial", "Arial Black", "Arial Narrow",
	"Arial Rounded MT Bold", "Arial Unicode MS", "Avenir", "Avenir Next",
	"Avenir Next Condensed", "Baskerville", "Big Caslon", "Bodoni 72", "Bradley Hand",
	"Brush Script MT", "Chalkboard", "Chalkboard SE", "Chalkduster", "Charter",
	"Cochin", "Comic Sans MS", "Copperplate", "Courier", "Courier New", "Didot",
	"DIN Alternate", "DIN Condensed", "Futura", "Geneva", "Georgia", "Gill Sans",
	"Helvetica", "Helvetica Neue", "Herculanum", "Hoefler Text", "Impact",
	"Lucida Grande", "Luminari", "Marker Felt", "Menlo", "Monaco", "Noteworthy",
	"Optima", "Palatino", "Papyrus", "Phosphate", "Rockwell", "Savoye LET",
	"SignPainter", "Skia", "Snell Roundhand", "Tahoma", "Times", "Times New Roman",
	"Trattatello", "Trebuchet MS", "Verdana", "Zapfino",
}

var fontsLinux = []string{
	"Bitstream Charter", "Cantarell", "Century Schoolbook L", "Courier 10 Pitch",
	"DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Dingbats", "FreeMono",
	"FreeSans", "FreeSerif", "Liberation Mono", "Liberation Sans", "Liberation Serif",
	"Nimbus Mono L", "Nimbus Roman No9 L", "Nimbus Sans L", "Noto Color Emoji",
	"Noto Mono", "Noto Sans", "Noto Sans Mono", "Noto Serif", "Standard Symbols L",
	"Ubuntu", "Ubuntu Condensed", "Ubuntu Mono", "URW Bookman L", "URW Chancery L",
	"URW Gothic L", "URW Palladio L",
}

// Data structures ────────────────────

// ScreenInfo holds screen dimensions.
type ScreenInfo struct {
	Width, Height, AvailWidth, AvailHeight, ColorDepth int
	DevicePixelRatio                                   int
}

// BrowserIdentity holds a full browser fingerprint identity.
type BrowserIdentity struct {
	ChromeVer           string
	UA                  string
	SecUA               string
	SecCHUAPlatform     string
	GPUVendor           string
	GPUModel            string
	WebGLExts           []string
	CanvasHash          int32
	HistogramBase       [256]int
	MathTan             string
	MathSin             string
	MathCos             string
	AudioFingerprint    string
	Plugins             []map[string]string
	Screen              ScreenInfo
	DeviceMemory        int
	HardwareConcurrency int
	Platform            string
	TimeZone            int
	Languages           []string
	Locale              string
	Fonts               []string

	// Device / browser coverage (Requirement 7). For a desktop-Chrome identity
	// these default to DeviceType="desktop", BrowserFamily="chrome",
	// MobilePlatform="", SecCHUAMobile="?0". Non-Chrome identities leave the
	// Chromium-only client-hint fields (SecUA, SecCHUAPlatform, SecCHUAMobile)
	// empty so they are omitted from payloads.
	DeviceType     string // "desktop" | "mobile"
	BrowserFamily  string // "chrome" | "firefox" | "safari"
	MobilePlatform string // "android" | "ios" | "" (desktop)
	SecCHUAMobile  string // "?1" | "?0" | "" (non-Chrome)
}

// Platform selection ────────────────────

// genPlatform picks a platform weighted by market share:
// Windows ~70%, macOS ~20%, Linux ~10%.
func genPlatform() string {
	r := rand.Intn(100)
	switch {
	case r < 70:
		return platWindows
	case r < 90:
		return platMacOS
	default:
		return platLinux
	}
}

// secCHUAPlatform maps the navigator.platform value to the Sec-CH-UA-Platform header.
func secCHUAPlatform(platform string) string {
	switch platform {
	case platMacOS:
		return "macOS"
	case platLinux:
		return "Linux"
	default:
		return "Windows"
	}
}

// buildUserAgent produces a platform-consistent Chrome User-Agent string.
func buildUserAgent(platform, chromeVer string) string {
	switch platform {
	case platMacOS:
		return fmt.Sprintf("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Safari/537.36", chromeVer)
	case platLinux:
		return fmt.Sprintf("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Safari/537.36", chromeVer)
	default:
		return fmt.Sprintf("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Safari/537.36", chromeVer)
	}
}

// GPU generation ────────────────────
// Returns a WebGL vendor/model pair correlated to platform and hardware tier.
// Windows: ANGLE (..., ... Direct3D11 vs_5_0 ps_5_0, D3D11)
// macOS  : ANGLE (Apple, ANGLE Metal Renderer: Apple M{N}, ...) or Intel OpenGL
// Linux  : ANGLE (..., ..., OpenGL 4.6) or Mesa strings

// gpuChip describes a GPU chip and the correlated hardware tier.
type gpuChip struct {
	chipVendor string // e.g. "Intel", "NVIDIA", "AMD", "Apple"
	prefix     string // e.g. "Intel(R) "
	model      string // e.g. "UHD Graphics 630" or "GeForce RTX 4090"
}

// Windows/Linux discrete/integrated GPU chips per tier.
var gpuTiersWinLinux = [3][]gpuChip{
	// Low-end: integrated graphics
	{
		{"Intel", "Intel(R) ", "UHD Graphics 630"},
		{"Intel", "Intel(R) ", "UHD Graphics 730"},
		{"Intel", "Intel(R) ", "HD Graphics 620"},
		{"Intel", "Intel(R) ", "HD Graphics 630"},
		{"Intel", "Intel(R) ", "HD Graphics 520"},
		{"Intel", "Intel(R) ", "UHD Graphics"},
		{"Intel", "Intel(R) ", "Iris(R) Xe Graphics"},
		{"Intel", "Intel(R) ", "Iris(R) Plus Graphics"},
		{"AMD", "AMD ", "Radeon(TM) Graphics"},
		{"AMD", "AMD ", "Radeon Vega 8 Graphics"},
		{"AMD", "AMD ", "Radeon RX Vega 11 Graphics"},
	},
	// Mid-range
	{
		{"NVIDIA", "NVIDIA ", "GeForce GTX 1650"},
		{"NVIDIA", "NVIDIA ", "GeForce GTX 1660 Super"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 2060"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 3050 Laptop GPU"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 3060"},
		{"NVIDIA", "NVIDIA ", "GeForce GTX 1060 6GB"},
		{"NVIDIA", "NVIDIA ", "GeForce GTX 1070"},
		{"AMD", "AMD ", "Radeon RX 5600 XT"},
		{"AMD", "AMD ", "Radeon RX 6600 XT"},
		{"AMD", "AMD ", "Radeon RX 5700 XT"},
		{"AMD", "AMD ", "Radeon RX 580"},
	},
	// High-end
	{
		{"NVIDIA", "NVIDIA ", "GeForce RTX 3070"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 3080"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 4070"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 4080"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 4090"},
		{"NVIDIA", "NVIDIA ", "GeForce RTX 3060 Ti"},
		{"AMD", "AMD ", "Radeon RX 6800 XT"},
		{"AMD", "AMD ", "Radeon RX 7800 XT"},
		{"AMD", "AMD ", "Radeon RX 7900 XTX"},
		{"AMD", "AMD ", "Radeon RX 6700 XT"},
	},
}

// Apple Silicon chips per tier (macOS).
var appleSiliconTiers = [3][]string{
	{"Apple M1"},                     // low
	{"Apple M2", "Apple M1 Pro"},     // mid
	{"Apple M3 Pro", "Apple M3 Max", "Apple M4 Pro", "Apple M4 Max", "Apple M2 Max"}, // high
}

// genGPU produces a WebGL vendor/model string matching the platform and tier.
func genGPU(platform string, tier int) (vendor, model string) {
	switch platform {
	case platMacOS:
		// ~70% Apple Silicon, ~30% Intel Mac
		if rand.Intn(10) < 7 {
			chips := appleSiliconTiers[tier]
			chip := chips[rand.Intn(len(chips))]
			vendor = "Google Inc. (Apple)"
			model = fmt.Sprintf("ANGLE (Apple, ANGLE Metal Renderer: %s, Unspecified Version)", chip)
			return
		}
		// Intel Mac (integrated) — always effectively low/mid tier
		intelModels := []string{
			"Intel(R) Iris(TM) Plus Graphics OpenGL Engine",
			"Intel(R) UHD Graphics 630",
			"Intel(R) Iris(TM) Graphics 6100",
			"Intel(R) HD Graphics 630",
		}
		m := intelModels[rand.Intn(len(intelModels))]
		vendor = "Google Inc. (Intel Inc.)"
		model = fmt.Sprintf("ANGLE (Intel Inc., %s, OpenGL 4.1)", m)
		return

	case platLinux:
		// ~50% Mesa-style, ~50% ANGLE OpenGL
		if rand.Intn(2) == 0 {
			mesaModels := []string{
				"Mesa Intel(R) UHD Graphics (TGL GT1)",
				"Mesa Intel(R) UHD Graphics 630 (CFL GT2)",
				"Mesa Intel(R) Iris(R) Xe Graphics (TGL GT2)",
				"AMD Radeon Graphics (radeonsi, renoir, LLVM 15.0.7, DRM 3.49, 6.2.0-generic)",
				"AMD Radeon RX 6600 (radeonsi, navi23, LLVM 15.0.7, DRM 3.49, 6.2.0-generic)",
				"NVIDIA GeForce RTX 3060/PCIe/SSE2",
				"llvmpipe (LLVM 15.0.7, 256 bits)",
			}
			m := mesaModels[rand.Intn(len(mesaModels))]
			vendor = "Mesa"
			model = m
			return
		}
		chip := gpuTiersWinLinux[tier][rand.Intn(len(gpuTiersWinLinux[tier]))]
		vendor = fmt.Sprintf("Google Inc. (%s)", chip.chipVendor)
		model = fmt.Sprintf("ANGLE (%s, %s%s, OpenGL 4.6)", chip.chipVendor, chip.prefix, chip.model)
		return

	default: // Windows
		chip := gpuTiersWinLinux[tier][rand.Intn(len(gpuTiersWinLinux[tier]))]
		vendor = fmt.Sprintf("Google Inc. (%s)", chip.chipVendor)
		model = fmt.Sprintf("ANGLE (%s, %s%s Direct3D11 vs_5_0 ps_5_0, D3D11)", chip.chipVendor, chip.prefix, chip.model)
		return
	}
}

// Hardware correlation ────────────────────

// hardwareSpec bundles correlated RAM (GB) and CPU core count.
type hardwareSpec struct {
	deviceMemory        int
	hardwareConcurrency int
}

// genHardwareTier picks a tier weighted low ~30% / mid ~45% / high ~25%.
func genHardwareTier() int {
	r := rand.Intn(100)
	switch {
	case r < 30:
		return tierLow
	case r < 75:
		return tierMid
	default:
		return tierHigh
	}
}

// genHardwareSpec returns coherent RAM + core count for the tier and platform.
func genHardwareSpec(platform string, tier int, gpuModel string) hardwareSpec {
	// Apple Silicon Macs have fixed unified-memory options and specific core counts.
	if platform == platMacOS && strings.Contains(gpuModel, "Apple M") {
		var memOptions, coreOptions []int
		switch tier {
		case tierLow: // M1
			memOptions = []int{8, 16}
			coreOptions = []int{8}
		case tierMid: // M2 / M1 Pro
			memOptions = []int{8, 16, 24}
			coreOptions = []int{8, 10}
		default: // M3/M4 Pro/Max
			memOptions = []int{16, 24, 32, 64, 96, 128}
			coreOptions = []int{10, 12, 14, 16}
		}
		return hardwareSpec{
			deviceMemory:        memOptions[rand.Intn(len(memOptions))],
			hardwareConcurrency: coreOptions[rand.Intn(len(coreOptions))],
		}
	}

	// Intel Mac / Windows / Linux tiers.
	var memOptions, coreOptions []int
	switch tier {
	case tierLow:
		memOptions = []int{4, 8}
		coreOptions = []int{4, 6, 8}
	case tierMid:
		memOptions = []int{8, 16}
		coreOptions = []int{8, 10, 12}
	default:
		memOptions = []int{16, 32, 64}
		coreOptions = []int{12, 16, 20, 24, 32}
	}
	return hardwareSpec{
		deviceMemory:        memOptions[rand.Intn(len(memOptions))],
		hardwareConcurrency: coreOptions[rand.Intn(len(coreOptions))],
	}
}

// Region / timezone / language ────────────────────
// The Region_Profile_Table and its resolution logic live in regions.go
// (data-driven: adding a region = adding a table row, no logic change).

// Font list per platform ────────────────────

// genFonts returns a shuffled realistic subset of platform fonts
// (most-but-not-all present, mimicking a real font-enumeration probe).
func genFonts(platform string) []string {
	var pool []string
	switch platform {
	case platMacOS:
		pool = fontsMacOS
	case platLinux:
		pool = fontsLinux
	default:
		pool = fontsWindows
	}

	work := make([]string, len(pool))
	copy(work, pool)
	rand.Shuffle(len(work), func(i, j int) { work[i], work[j] = work[j], work[i] })

	// Keep ~80-95% of the fonts (a few common fonts may be absent on any install).
	keep := len(work) * (80 + rand.Intn(16)) / 100
	if keep < 1 {
		keep = 1
	}
	selected := work[:keep]

	out := make([]string, len(selected))
	copy(out, selected)
	sort.Strings(out)
	return out
}

// Screen resolution generation ────────────────────
// AvailHeight = Height - taskbar(32~48), AvailWidth = Width, ColorDepth = 24

func genScreen(platform string) ScreenInfo {
	type resolution struct {
		w, h int
	}

	// macOS commonly uses Retina panels with DPR 2.
	if platform == platMacOS {
		macRes := []resolution{
			{2560, 1600}, {2880, 1800}, {3024, 1964}, {3456, 2234},
			{1440, 900}, {1680, 1050}, {1512, 982},
		}
		res := macRes[rand.Intn(len(macRes))]
		// Retina panels report DPR 2; older/scaled panels may report 1.
		dpr := 2
		if res.w <= 1680 && rand.Intn(3) == 0 {
			dpr = 1
		}
		menuBar := 24 + rand.Intn(9) // menu bar + dock reserve
		return ScreenInfo{
			Width:            res.w,
			Height:           res.h,
			AvailWidth:       res.w,
			AvailHeight:      res.h - menuBar,
			ColorDepth:       30, // macOS Retina commonly reports 30-bit
			DevicePixelRatio: dpr,
		}
	}

	r16x9 := []resolution{
		{1366, 768}, {1536, 864}, {1600, 900},
		{1920, 1080}, {2560, 1440}, {3840, 2160},
	}
	r16x10 := []resolution{
		{1440, 900}, {1680, 1050}, {1920, 1200}, {2560, 1600},
	}
	r21x9 := []resolution{
		{2560, 1080}, {3440, 1440},
	}
	rOther := []resolution{
		{1280, 720}, {1360, 768}, {2880, 1800},
	}

	// Weighted by market share: 16:9 most common
	pools := [][]resolution{r16x9, r16x9, r16x9, r16x10, r21x9, rOther}
	pool := pools[rand.Intn(len(pools))]
	res := pool[rand.Intn(len(pool))]

	taskbar := 32 + rand.Intn(17) // 32-48
	taskbar = (taskbar / 8) * 8
	if taskbar < 32 {
		taskbar = 32
	}

	colorDepths := []int{24, 24, 24, 24, 30} // 24 common, 30 is HDR

	return ScreenInfo{
		Width:            res.w,
		Height:           res.h,
		AvailWidth:       res.w,
		AvailHeight:      res.h - taskbar,
		ColorDepth:       colorDepths[rand.Intn(len(colorDepths))],
		DevicePixelRatio: 1,
	}
}

// Math precision generation ────────────────────
// Math.tan/sin/cos(-1e300) varies only in last 1-2 digits across hardware.
// tan base: "-1.4214488238747245"  tail 3~7
// sin base: "0.8178819121159085"   tail 3~7
// cos has two families:
//   Family A: "-0.5753861119575491"   tail 89~93
//   Family B: "-0.5765775004286854"   tail 53~55

func genMath() (tan, sin, cos string) {
	tanEnd := 3 + rand.Intn(100)
	sinEnd := 3 + rand.Intn(100)
	tan = fmt.Sprintf("-1.42144882387472%03d", tanEnd)
	sin = fmt.Sprintf("0.81788191211590%03d", sinEnd)

	// cos has two families, Family A more common (~70%)
	if rand.Intn(10) < 7 {
		cosEnd := 89 + rand.Intn(15)
		cos = fmt.Sprintf("-0.5753861119575%03d", cosEnd)
	} else {
		cosEnd := 53 + rand.Intn(10)
		cos = fmt.Sprintf("-0.5765775004286%03d", cosEnd)
	}
	return
}

// Audio fingerprint generation ────────────────────
// FingerprintJS sums an OfflineAudioContext oscillator+compressor render into a
// float ~124.04347527516074. The exact value clusters by platform/GPU DSP path;
// only the tail digits vary across hardware, mirroring the Math precision trick.

func genAudio(platform string, tier int) string {
	// Base clusters observed in the wild differ slightly by OS audio backend.
	var base string
	switch platform {
	case platMacOS:
		// macOS CoreAudio path
		base = "124.0434485875848"
	case platLinux:
		// Linux (PulseAudio/ALSA) path
		base = "124.08072766105033"
	default:
		// Windows most common cluster
		base = "124.04347527516074"
	}
	// Vary the trailing few digits deterministically-random per identity, biased
	// slightly by hardware tier so higher tiers cluster distinctly.
	tail := (tier * 7) + rand.Intn(90)
	// Replace the last 2 digits of the base with the varied tail.
	trimmed := base[:len(base)-2]
	return fmt.Sprintf("%s%02d", trimmed, tail%100)
}

// Canvas histogram simulation ────────────────────
// Simulates a 150x60 canvas with 36000 RGBA samples:
// 1. Transparent background -> bins[0] very large
// 2. Drawn area alpha=255 -> bins[255] very large
// 3. #f60 rectangle -> bins[102] spike (~500-700)
// 4. multiply/difference blend + circle -> ~153 spike (~400-700)
// 5. Text antialiasing + gradient + curves -> middle bins 4-120

func generateCanvasData() (int32, [256]int) {
	var bins [256]int
	const totalSamples = 36000 // 150x60x4(RGBA)

	// Main peaks: transparent background + alpha channel
	bins[0] = 5000 + rand.Intn(10001)   // 5000~15000
	bins[255] = 6000 + rand.Intn(10001) // 6000~16000

	// Secondary spikes from specific color values
	// #f60 rectangle G channel = 102
	spike1Pos := 100 + rand.Intn(6) // 100~105
	bins[spike1Pos] = 500 + rand.Intn(200)

	// multiply blend value ~153
	spike2Pos := 150 + rand.Intn(8) // 150~157
	bins[spike2Pos] = 400 + rand.Intn(300)

	// Calculate assigned samples
	assigned := bins[0] + bins[255] + bins[spike1Pos] + bins[spike2Pos]
	remaining := totalSamples - assigned

	// Feature color regions (mid-range values from drawing operations)
	featureBins := []struct {
		lo, hi   int
		avgCount int
	}{
		{1, 30, 30},    // dark region (antialiasing)
		{31, 70, 20},   // mid-dark (curves/gradient)
		{71, 99, 25},   // middle (blend colors)
		{106, 149, 15}, // mid-high (text/gradient transitions)
		{158, 200, 18}, // highlight (circle shading)
		{201, 254, 25}, // bright (near white)
	}

	for _, fb := range featureBins {
		for i := fb.lo; i <= fb.hi; i++ {
			if remaining <= 0 {
				break
			}
			center := (fb.lo + fb.hi) / 2
			dist := abs(i - center)
			maxDist := (fb.hi - fb.lo) / 2
			if maxDist == 0 {
				maxDist = 1
			}
			scale := float64(maxDist-dist) / float64(maxDist)
			if scale < 0.2 {
				scale = 0.2
			}
			base := int(float64(fb.avgCount) * scale)
			v := max(2, base+rand.Intn(max(1, base/2+1))-base/4)
			if v > remaining {
				v = remaining
			}
			bins[i] = v
			remaining -= v
		}
	}

	// Fill remaining bins with small noise
	for i := 1; i < 255; i++ {
		if bins[i] == 0 && remaining > 0 {
			v := 2 + rand.Intn(8)
			if v > remaining {
				v = remaining
			}
			bins[i] = v
			remaining -= v
		}
	}

	// Overflow/underflow absorbed into bins[0]
	if remaining > 0 {
		bins[0] += remaining
	} else if remaining < 0 {
		bins[0] += remaining
		if bins[0] < 10000 {
			bins[0] = 10000
		}
	}

	// Hash: SHA256(LE bytes of bins) -> first 4 bytes -> int32
	raw := make([]byte, 256*4)
	for i, v := range bins {
		binary.LittleEndian.PutUint32(raw[i*4:], uint32(v))
	}
	digest := sha256.Sum256(raw)
	hash := int32(binary.LittleEndian.Uint32(digest[:4]))
	return hash, bins
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}

// Core: random identity generation ────────────────────

// GenOptions controls identity generation across device types and browser
// families. Zero value => desktop Chrome, weighted-random region.
type GenOptions struct {
	ChromeMajor int    // pin Chrome major version (0 => random)
	Country     string // ISO country hint ("" => weighted-random region)
	Device      string // "desktop" | "mobile" | "" (=> desktop)
	Browser     string // "chrome" | "firefox" | "safari" | "" (=> chrome)
}

// RandomIdentity creates a random desktop-Chrome browser identity.
func RandomIdentity() *BrowserIdentity {
	return RandomIdentityWithOptions(GenOptions{})
}

// RandomIdentityWithPin creates a desktop-Chrome identity pinned to a Chrome
// major version.
func RandomIdentityWithPin(chromeMajor int) *BrowserIdentity {
	return RandomIdentityWithOptions(GenOptions{ChromeMajor: chromeMajor})
}

// RandomIdentityForRegion creates a desktop-Chrome identity with geo coherent to
// an ISO country hint (empty => weighted-random region).
func RandomIdentityForRegion(chromeMajor int, countryHint string) *BrowserIdentity {
	return RandomIdentityWithOptions(GenOptions{ChromeMajor: chromeMajor, Country: countryHint})
}

// RandomIdentityWithOptions is the primary generation entry point. It dispatches
// to the desktop-Chrome, mobile, or non-Chrome builder based on the options,
// applying Hardware_Tier and platform coherence in every path (Requirement 5, 7).
func RandomIdentityWithOptions(o GenOptions) *BrowserIdentity {
	device := strings.ToLower(strings.TrimSpace(o.Device))
	browser := strings.ToLower(strings.TrimSpace(o.Browser))

	switch {
	case browser == browserFirefox || browser == browserSafari:
		return buildNonChromeIdentity(o, browser, device)
	case device == deviceMobile:
		return buildMobileIdentity(o) // Chrome mobile (non-Chrome handled above)
	default:
		return buildDesktopChrome(o)
	}
}

// genWebGLExts returns the core WebGL extension set plus a random subset of the
// optional extensions, sorted. Shared across device/browser builders.
func genWebGLExts() []string {
	exts := make([]string, len(webglExtCore))
	copy(exts, webglExtCore)
	nOpt := rand.Intn(5)
	if nOpt > 0 && nOpt <= len(webglExtOptional) {
		perm := rand.Perm(len(webglExtOptional))
		for i := 0; i < nOpt; i++ {
			exts = append(exts, webglExtOptional[perm[i]])
		}
	}
	sort.Strings(exts)
	return exts
}

// genChromePlugins returns the shuffled Chrome built-in PDF plugin set.
func genChromePlugins() []map[string]string {
	plugins := make([]map[string]string, len(pluginsPool))
	copy(plugins, pluginsPool)
	rand.Shuffle(len(plugins), func(i, j int) { plugins[i], plugins[j] = plugins[j], plugins[i] })
	return plugins
}

// pickChromeVersion returns a Chrome version, pinned if chromeMajor > 0.
func pickChromeVersion(chromeMajor int) chromeVersion {
	if chromeMajor > 0 {
		return genChromeVersionWithPin(chromeMajor)
	}
	return genChromeVersion()
}

// buildDesktopChrome builds a desktop Chrome identity on Windows/macOS/Linux.
func buildDesktopChrome(o GenOptions) *BrowserIdentity {
	cv := pickChromeVersion(o.ChromeMajor)

	// Platform first — everything downstream keys off it.
	platform := genPlatform()

	// Hardware tier drives GPU + RAM + core correlation.
	tier := genHardwareTier()
	gpuVendor, gpuModel := genGPU(platform, tier)
	spec := genHardwareSpec(platform, tier, gpuModel)

	screen := genScreen(platform)

	// Region-coherent timezone + language + locale.
	region := resolveRegion(o.Country)

	mathTan, mathSin, mathCos := genMath()
	audio := genAudio(platform, tier)
	fonts := genFonts(platform)
	canvasHash, histogram := generateCanvasData()
	exts := genWebGLExts()
	plugins := genChromePlugins()
	ua := buildUserAgent(platform, cv.Version)

	return &BrowserIdentity{
		ChromeVer:           cv.Version,
		UA:                  ua,
		SecUA:               cv.SecUA,
		SecCHUAPlatform:     secCHUAPlatform(platform),
		GPUVendor:           gpuVendor,
		GPUModel:            gpuModel,
		WebGLExts:           exts,
		CanvasHash:          canvasHash,
		HistogramBase:       histogram,
		MathTan:             mathTan,
		MathSin:             mathSin,
		MathCos:             mathCos,
		AudioFingerprint:    audio,
		Plugins:             plugins,
		Screen:              screen,
		DeviceMemory:        spec.deviceMemory,
		HardwareConcurrency: spec.hardwareConcurrency,
		Platform:            platform,
		TimeZone:            region.timeZone,
		Languages:           region.languages,
		Locale:              region.locale,
		Fonts:               fonts,
		DeviceType:          deviceDesktop,
		BrowserFamily:       browserChrome,
		MobilePlatform:      "",
		SecCHUAMobile:       "?0",
	}
}
