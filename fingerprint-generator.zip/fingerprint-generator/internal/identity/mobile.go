package identity

import (
	"fmt"
	"math/rand"
	"sort"
)

// Mobile identity generation (Android / iOS) ────────────────────
// Covers Requirement 7.1 (mobile invariants), 7.2 (Chrome mobile client hints),
// and 7.7 (tier/platform coherence). Non-Chrome mobile (Firefox/Safari) is built
// in browser.go; this file builds Chrome mobile.

// Mobile font pools per platform.
var fontsAndroid = []string{
	"Roboto", "Roboto Condensed", "Roboto Mono", "Noto Sans", "Noto Serif",
	"Noto Color Emoji", "Noto Sans Mono", "Droid Sans", "Droid Sans Mono",
	"Droid Serif", "Google Sans", "Product Sans",
}

var fontsIOS = []string{
	".SF UI Text", ".SF UI Display", "SF Pro", "SF Pro Text", "SF Pro Display",
	"Helvetica", "Helvetica Neue", "Arial", "Arial Hebrew", "Courier",
	"Courier New", "Georgia", "Palatino", "Times New Roman", "Verdana",
	"Apple Color Emoji", "Menlo",
}

// mobileGPU describes an Android mobile GPU vendor/renderer.
type mobileGPU struct {
	vendor   string // WebGL vendor family (e.g. "Qualcomm", "ARM")
	renderer string // chip renderer (e.g. "Adreno (TM) 730")
}

// Android mobile GPUs per hardware tier.
var androidGPUTiers = [3][]mobileGPU{
	{ // low
		{"Qualcomm", "Adreno (TM) 610"},
		{"Qualcomm", "Adreno (TM) 619"},
		{"ARM", "Mali-G52 MC2"},
		{"ARM", "Mali-G57 MC2"},
	},
	{ // mid
		{"Qualcomm", "Adreno (TM) 642L"},
		{"Qualcomm", "Adreno (TM) 730"},
		{"ARM", "Mali-G76 MC4"},
		{"ARM", "Mali-G78 MP20"},
	},
	{ // high
		{"Qualcomm", "Adreno (TM) 740"},
		{"Qualcomm", "Adreno (TM) 750"},
		{"ARM", "Mali-G715 Immortalis MC11"},
		{"Samsung Electronics", "Xclipse 920"},
	},
}

// Android device models + OS versions for the User-Agent.
var androidDevices = []string{
	"Pixel 8", "Pixel 8 Pro", "Pixel 7", "Pixel 7a", "Pixel 6a",
	"SM-S918B", "SM-S911B", "SM-G991B", "SM-A536B", "SM-S908B",
	"M2101K6G", "2201123G", "23021RAAEG",
}

var androidVersions = []string{"12", "13", "14"}

// iOS versions for the User-Agent (underscore form).
var iosVersions = []string{"16_6", "17_1", "17_3", "17_4", "17_5", "18_0"}

// mobile screen resolutions (logical CSS px, portrait: height > width).
type mobileRes struct {
	w, h, dpr int
}

var androidScreens = []mobileRes{
	{360, 800, 3}, {384, 854, 3}, {393, 873, 3}, {412, 915, 3},
	{360, 780, 3}, {412, 892, 3}, {360, 640, 3}, {414, 896, 2},
}

var iosScreens = []mobileRes{
	{375, 812, 3}, {390, 844, 3}, {393, 852, 3}, {414, 896, 2},
	{428, 926, 3}, {430, 932, 3}, {375, 667, 2},
}

// genMobileHardware returns coherent mobile deviceMemory + core count for a tier.
// navigator.deviceMemory is capped at 8 by the spec; mobile cores rarely exceed 8.
func genMobileHardware(tier int) hardwareSpec {
	var mem, cores []int
	switch tier {
	case tierLow:
		mem = []int{2, 4}
		cores = []int{4, 6}
	case tierMid:
		mem = []int{4, 8}
		cores = []int{6, 8}
	default:
		mem = []int{8}
		cores = []int{8}
	}
	return hardwareSpec{
		deviceMemory:        mem[rand.Intn(len(mem))],
		hardwareConcurrency: cores[rand.Intn(len(cores))],
	}
}

// buildMobileIdentity builds a Chrome mobile identity (Android weighted, else iOS).
func buildMobileIdentity(o GenOptions) *BrowserIdentity {
	cv := pickChromeVersion(o.ChromeMajor)
	tier := genHardwareTier()
	region := resolveRegion(o.Country)

	// ~85% Android, ~15% iOS (Chrome on iOS is WebKit under the hood).
	mobilePlatform := mobileAndroid
	if rand.Intn(100) >= 85 {
		mobilePlatform = mobileIOS
	}

	var (
		platform, ua, gpuVendor, gpuModel, secCHUAPlat string
		fonts                                          []string
		res                                            mobileRes
	)

	if mobilePlatform == mobileIOS {
		platform = platIOS
		iosVer := iosVersions[rand.Intn(len(iosVersions))]
		ua = fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/%s Mobile/15E148 Safari/604.1", iosVer, cv.Version)
		gpuVendor = "Apple Inc."
		gpuModel = "Apple GPU"
		fonts = shuffledSubset(fontsIOS)
		secCHUAPlat = "iOS"
		res = iosScreens[rand.Intn(len(iosScreens))]
	} else {
		platform = platAndroid
		andVer := androidVersions[rand.Intn(len(androidVersions))]
		device := androidDevices[rand.Intn(len(androidDevices))]
		ua = fmt.Sprintf("Mozilla/5.0 (Linux; Android %s; %s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Mobile Safari/537.36", andVer, device, cv.Version)
		g := androidGPUTiers[tier][rand.Intn(len(androidGPUTiers[tier]))]
		gpuVendor = fmt.Sprintf("Google Inc. (%s)", g.vendor)
		gpuModel = fmt.Sprintf("ANGLE (%s, %s, OpenGL ES 3.2)", g.vendor, g.renderer)
		fonts = shuffledSubset(fontsAndroid)
		secCHUAPlat = "Android"
		res = androidScreens[rand.Intn(len(androidScreens))]
	}

	hw := genMobileHardware(tier)

	// Portrait screen with DPR in [2,4]; availHeight reserves a small chrome bar.
	screen := ScreenInfo{
		Width:            res.w,
		Height:           res.h,
		AvailWidth:       res.w,
		AvailHeight:      res.h - (56 + rand.Intn(24)),
		ColorDepth:       24,
		DevicePixelRatio: res.dpr,
	}

	mathTan, mathSin, mathCos := genMath()
	// Audio backend clusters: iOS ~ CoreAudio (macOS), Android ~ Linux-ish.
	audioPlat := platLinux
	if mobilePlatform == mobileIOS {
		audioPlat = platMacOS
	}
	audio := genAudio(audioPlat, tier)
	canvasHash, histogram := generateCanvasData()

	return &BrowserIdentity{
		ChromeVer:       cv.Version,
		UA:              ua,
		SecUA:           cv.SecUA, // Chrome family sends Sec-CH-UA
		SecCHUAPlatform: secCHUAPlat,
		SecCHUAMobile:   "?1", // Requirement 7.2
		GPUVendor:       gpuVendor,
		GPUModel:        gpuModel,
		WebGLExts:       genWebGLExts(),
		CanvasHash:      canvasHash,
		HistogramBase:   histogram,
		MathTan:         mathTan,
		MathSin:         mathSin,
		MathCos:         mathCos,
		AudioFingerprint:    audio,
		Plugins:             []map[string]string{}, // mobile Chrome exposes no plugins
		Screen:              screen,
		DeviceMemory:        hw.deviceMemory,
		HardwareConcurrency: hw.hardwareConcurrency,
		Platform:            platform,
		TimeZone:            region.timeZone,
		Languages:           region.languages,
		Locale:              region.locale,
		Fonts:               fonts,
		DeviceType:          deviceMobile,
		BrowserFamily:       browserChrome,
		MobilePlatform:      mobilePlatform,
	}
}

// shuffledSubset returns a sorted realistic most-but-not-all subset of a font pool.
func shuffledSubset(pool []string) []string {
	work := make([]string, len(pool))
	copy(work, pool)
	rand.Shuffle(len(work), func(i, j int) { work[i], work[j] = work[j], work[i] })
	keep := len(work) * (80 + rand.Intn(16)) / 100
	if keep < 1 {
		keep = 1
	}
	out := make([]string, keep)
	copy(out, work[:keep])
	sort.Strings(out)
	return out
}
