package identity

import "testing"

// Example: the Region_Profile_Table covers ≥24 distinct countries spanning all 7
// regions (Requirement 4.1).
func TestExample_RegionCoverage(t *testing.T) {
	present := map[string]bool{}
	for _, p := range regionProfiles {
		present[p.country] = true
	}
	if len(present) < 24 {
		t.Fatalf("only %d distinct countries, want >= 24", len(present))
	}

	regions := map[string][]string{
		"North America": {"us", "ca", "mx"},
		"South America": {"br", "ar", "cl"},
		"Europe":        {"gb", "de", "fr", "nl", "es", "it", "se", "pl"},
		"Middle East":   {"ae", "sa", "tr", "il"},
		"Africa":        {"za", "ng", "eg", "ke"},
		"Asia":          {"in", "sg", "cn", "jp", "kr", "id", "th", "vn", "ph"},
		"Oceania":       {"au", "nz"},
	}
	for region, countries := range regions {
		found := false
		for _, c := range countries {
			if present[c] {
				found = true
				break
			}
		}
		if !found {
			t.Fatalf("region %q has no country in the table", region)
		}
	}
}
