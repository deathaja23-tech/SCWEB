package identity

import (
	"math/rand"
	"strings"
)

// Region_Profile_Table (data-driven) ────────────────────
//
// This is the single source of region data for the Identity_Core. Adding a new
// region requires ONLY adding a row here — the resolution logic below never
// changes (Requirement 4.6).
//
// Invariants for every row (Requirement 4.2):
//   - timeZone   : whole-hour UTC offset observed in the country (standard time).
//   - languages  : navigator.languages; languages[0] is an official/predominant
//                  language of the country.
//   - locale     : corresponds to languages[0] and the country (language-COUNTRY).
//
// Coverage (Requirement 4.1): ≥24 distinct countries spanning all 7 regions —
// North America, South America, Europe, Middle East, Africa, Asia, Oceania.

// regionProfile bundles a coherent geo triple.
type regionProfile struct {
	country   string   // ISO 3166-1 alpha-2 code (lowercase)
	timeZone  int      // UTC offset in whole hours (standard time)
	languages []string // navigator.languages; [0] official/predominant
	locale    string   // primary locale (== languages[0])
	weight    int      // selection weight for weighted-random pick
}

var regionProfiles = []regionProfile{
	// ── North America ──
	{"us", -5, []string{"en-US", "en"}, "en-US", 25},              // US East
	{"us", -8, []string{"en-US", "en"}, "en-US", 15},              // US West
	{"ca", -5, []string{"en-CA", "en", "fr"}, "en-CA", 5},         // Canada (Toronto)
	{"mx", -6, []string{"es-MX", "es", "en"}, "es-MX", 3},         // Mexico

	// ── South America ──
	{"br", -3, []string{"pt-BR", "pt", "en"}, "pt-BR", 5},         // Brazil
	{"ar", -3, []string{"es-AR", "es", "en"}, "es-AR", 2},         // Argentina
	{"cl", -4, []string{"es-CL", "es", "en"}, "es-CL", 2},         // Chile

	// ── Europe ──
	{"gb", 0, []string{"en-GB", "en"}, "en-GB", 9},                // United Kingdom
	{"de", 1, []string{"de-DE", "de", "en"}, "de-DE", 8},          // Germany
	{"fr", 1, []string{"fr-FR", "fr", "en"}, "fr-FR", 6},          // France
	{"nl", 1, []string{"nl-NL", "nl", "en"}, "nl-NL", 4},          // Netherlands
	{"es", 1, []string{"es-ES", "es", "en"}, "es-ES", 4},          // Spain
	{"it", 1, []string{"it-IT", "it", "en"}, "it-IT", 4},          // Italy
	{"se", 1, []string{"sv-SE", "sv", "en"}, "sv-SE", 3},          // Sweden
	{"pl", 1, []string{"pl-PL", "pl", "en"}, "pl-PL", 3},          // Poland

	// ── Middle East ──
	{"ae", 4, []string{"ar-AE", "ar", "en"}, "ar-AE", 3},          // UAE
	{"sa", 3, []string{"ar-SA", "ar", "en"}, "ar-SA", 3},          // Saudi Arabia
	{"tr", 3, []string{"tr-TR", "tr", "en"}, "tr-TR", 3},          // Turkey
	{"il", 2, []string{"he-IL", "he", "en"}, "he-IL", 2},          // Israel

	// ── Africa ──
	{"za", 2, []string{"en-ZA", "en", "af"}, "en-ZA", 3},          // South Africa
	{"ng", 1, []string{"en-NG", "en"}, "en-NG", 2},                // Nigeria
	{"eg", 2, []string{"ar-EG", "ar", "en"}, "ar-EG", 2},          // Egypt
	{"ke", 3, []string{"en-KE", "en", "sw"}, "en-KE", 2},          // Kenya

	// ── Asia ──
	{"in", 5, []string{"en-IN", "en", "hi"}, "en-IN", 7},          // India (+5:30 → 5)
	{"sg", 8, []string{"en-SG", "en", "zh-CN"}, "en-SG", 4},       // Singapore
	{"cn", 8, []string{"zh-CN", "zh", "en"}, "zh-CN", 5},          // China
	{"jp", 9, []string{"ja-JP", "ja", "en"}, "ja-JP", 5},          // Japan
	{"kr", 9, []string{"ko-KR", "ko", "en"}, "ko-KR", 4},          // South Korea
	{"id", 7, []string{"id-ID", "id", "en"}, "id-ID", 5},          // Indonesia (WIB)
	{"th", 7, []string{"th-TH", "th", "en"}, "th-TH", 3},          // Thailand
	{"vn", 7, []string{"vi-VN", "vi", "en"}, "vi-VN", 3},          // Vietnam
	{"ph", 8, []string{"en-PH", "en", "fil"}, "en-PH", 3},         // Philippines

	// ── Oceania ──
	{"au", 10, []string{"en-AU", "en"}, "en-AU", 4},               // Australia (AEST)
	{"nz", 12, []string{"en-NZ", "en"}, "en-NZ", 2},               // New Zealand (NZST)
}

// regionByCountry finds a profile matching an ISO country code (first match),
// case-insensitive after trimming surrounding whitespace.
func regionByCountry(cc string) (regionProfile, bool) {
	cc = strings.ToLower(strings.TrimSpace(cc))
	for _, p := range regionProfiles {
		if p.country == cc {
			return p, true
		}
	}
	return regionProfile{}, false
}

// pickRegionProfile chooses a weighted-random region profile.
func pickRegionProfile() regionProfile {
	total := 0
	for _, p := range regionProfiles {
		total += p.weight
	}
	r := rand.Intn(total)
	for _, p := range regionProfiles {
		if r < p.weight {
			return p
		}
		r -= p.weight
	}
	return regionProfiles[0]
}

// resolveRegion returns a coherent geo profile: honor an explicit ISO country
// code hint when present and known, else pick a weighted-random region
// (Requirement 4.3/4.4/4.5).
func resolveRegion(countryHint string) regionProfile {
	if countryHint != "" {
		if p, ok := regionByCountry(countryHint); ok {
			return p
		}
	}
	return pickRegionProfile()
}
