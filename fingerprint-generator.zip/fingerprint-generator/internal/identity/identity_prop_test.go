package identity

import (
	"strings"
	"testing"
	"testing/quick"
)

// Property-based tests for the Identity_Core.
// Feature: global-fingerprint-optimization.

var qcfg = &quick.Config{MaxCount: 200}

func optsFrom(dsel, bsel, csel uint8) GenOptions {
	devices := []string{"", "desktop", "mobile"}
	browsers := []string{"", "chrome", "firefox", "safari"}
	countries := []string{"", "us", "jp", "de", "in", "br", "za", "au", "nz", "zz", "  Jp ", "US"}
	return GenOptions{
		Device:  devices[int(dsel)%len(devices)],
		Browser: browsers[int(bsel)%len(browsers)],
		Country: countries[int(csel)%len(countries)],
	}
}

func subsetOf(items []string, pool []string) bool {
	set := make(map[string]bool, len(pool))
	for _, p := range pool {
		set[p] = true
	}
	for _, it := range items {
		if !set[it] {
			return false
		}
	}
	return true
}

// memCoresShareTier reports whether (mem, cores) are jointly consistent with a
// single Hardware_Tier for the identity's device/platform class (no cross-tier mix).
func memCoresShareTier(id *BrowserIdentity) bool {
	type set struct{ mem, cores []int }
	var families [][3]set // [tier]{...} per family; check any family where all 3 tiers checked

	desktopNonApple := [3]set{
		{[]int{4, 8}, []int{4, 6, 8}},
		{[]int{8, 16}, []int{8, 10, 12}},
		{[]int{16, 32, 64}, []int{12, 16, 20, 24, 32}},
	}
	appleMac := [3]set{
		{[]int{8, 16}, []int{8}},
		{[]int{8, 16, 24}, []int{8, 10}},
		{[]int{16, 24, 32, 64, 96, 128}, []int{10, 12, 14, 16}},
	}
	mobile := [3]set{
		{[]int{2, 4}, []int{4, 6}},
		{[]int{4, 8}, []int{6, 8}},
		{[]int{8}, []int{8}},
	}

	switch {
	case id.DeviceType == deviceMobile || id.Platform == platIOS:
		families = append(families, mobile)
	case id.Platform == platMacOS:
		families = append(families, appleMac, desktopNonApple) // Intel Mac uses non-apple sets
	default:
		families = append(families, desktopNonApple)
	}

	has := func(xs []int, v int) bool {
		for _, x := range xs {
			if x == v {
				return true
			}
		}
		return false
	}
	for _, fam := range families {
		for tier := 0; tier < 3; tier++ {
			if has(fam[tier].mem, id.DeviceMemory) && has(fam[tier].cores, id.HardwareConcurrency) {
				return true
			}
		}
	}
	return false
}

// Feature: global-fingerprint-optimization, Property 5: Hardware-tier coherence — GPU model, deviceMemory, and hardwareConcurrency all originate from one single Hardware_Tier (no cross-tier mixing); Apple Silicon uses Apple sets.
func TestProperty5_HardwareTierCoherence(t *testing.T) {
	f := func(d, b, c uint8) bool {
		id := RandomIdentityWithOptions(optsFrom(d, b, c))
		return memCoresShareTier(id)
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 6: Platform-consistency invariant — UA, client-hint platform (when present), GPU renderer, fonts, and screen DPR all correspond to the single selected Platform.
func TestProperty6_PlatformConsistency(t *testing.T) {
	f := func(d, b, c uint8) bool {
		id := RandomIdentityWithOptions(optsFrom(d, b, c))
		// UA marker matches platform.
		uaOK := true
		switch id.Platform {
		case platWindows:
			uaOK = strings.Contains(id.UA, "Windows NT")
		case platMacOS:
			uaOK = strings.Contains(id.UA, "Macintosh") || strings.Contains(id.UA, "Mac OS X")
		case platLinux:
			uaOK = strings.Contains(id.UA, "Linux") && !strings.Contains(id.UA, "Android")
		case platAndroid:
			uaOK = strings.Contains(id.UA, "Android")
		case platIOS:
			uaOK = strings.Contains(id.UA, "iPhone")
		}
		// Fonts subset of the platform pool.
		var pool []string
		switch id.Platform {
		case platWindows:
			pool = fontsWindows
		case platMacOS:
			pool = fontsMacOS
		case platLinux:
			pool = fontsLinux
		case platAndroid:
			pool = fontsAndroid
		case platIOS:
			pool = fontsIOS
		}
		fontsOK := subsetOf(id.Fonts, pool)
		// DPR: mobile/mac Retina >= 2; Windows/Linux desktop == 1.
		dprOK := true
		if id.Platform == platWindows || id.Platform == platLinux {
			dprOK = id.Screen.DevicePixelRatio == 1
		} else {
			dprOK = id.Screen.DevicePixelRatio >= 1
		}
		return uaOK && fontsOK && dprOK
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 7: Mobile identity invariant — single Mobile_Platform, UA identifies it, mobile GPU, mobile fonts, portrait screen, DPR in [2,4]; Chrome mobile sets SecCHUAMobile=?1 and SecCHUAPlatform.
func TestProperty7_MobileInvariant(t *testing.T) {
	f := func(b, c uint8) bool {
		browsers := []string{"", "chrome"} // firefox/safari mobile covered by Property 8
		o := GenOptions{Device: "mobile", Browser: browsers[int(b)%len(browsers)], Country: []string{"", "us", "jp"}[int(c)%3]}
		id := RandomIdentityWithOptions(o)
		if id.MobilePlatform != mobileAndroid && id.MobilePlatform != mobileIOS {
			return false
		}
		if id.Screen.Height <= id.Screen.Width {
			return false // portrait
		}
		if id.Screen.DevicePixelRatio < 2 || id.Screen.DevicePixelRatio > 4 {
			return false
		}
		// Chrome mobile client hints.
		if id.SecCHUAMobile != "?1" {
			return false
		}
		if id.MobilePlatform == mobileAndroid && id.SecCHUAPlatform != "Android" {
			return false
		}
		if id.MobilePlatform == mobileIOS && id.SecCHUAPlatform != "iOS" {
			return false
		}
		var pool []string
		if id.MobilePlatform == mobileAndroid {
			pool = fontsAndroid
		} else {
			pool = fontsIOS
		}
		return subsetOf(id.Fonts, pool)
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 8: Non-Chrome identity invariant — UA identifies engine (Gecko/WebKit), client hints empty, GPU/plugins consistent, platform matrix (Safari→macOS/iOS, Firefox→Win/mac/Linux/Android), never Safari on Win/Linux/Android.
func TestProperty8_NonChromeInvariant(t *testing.T) {
	f := func(d, c uint8) bool {
		for _, browser := range []string{"firefox", "safari"} {
			o := GenOptions{Device: []string{"", "desktop", "mobile"}[int(d)%3], Browser: browser, Country: []string{"", "de", "jp"}[int(c)%3]}
			id := RandomIdentityWithOptions(o)
			// Chromium-only client hints must be empty.
			if id.SecUA != "" || id.SecCHUAPlatform != "" || id.SecCHUAMobile != "" {
				return false
			}
			if browser == "safari" {
				if !strings.Contains(id.UA, "Version/") || !strings.Contains(id.UA, "Safari") {
					return false
				}
				// Safari only on macOS (desktop) or iOS (mobile).
				if id.Platform != platMacOS && id.Platform != platIOS {
					return false
				}
			} else { // firefox
				if !strings.Contains(id.UA, "Firefox/") || !strings.Contains(id.UA, "Gecko") {
					return false
				}
				// Firefox never on iOS.
				if id.Platform == platIOS {
					return false
				}
			}
		}
		return true
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 9: Region-table data invariant — every row has a whole-hour tz in plausible range, non-empty languages, and locale corresponding to languages[0] and country.
func TestProperty9_RegionTableInvariant(t *testing.T) {
	for _, p := range regionProfiles {
		if p.timeZone < -12 || p.timeZone > 14 {
			t.Fatalf("region %s tz out of range: %d", p.country, p.timeZone)
		}
		if len(p.languages) == 0 {
			t.Fatalf("region %s has empty languages", p.country)
		}
		if p.locale != p.languages[0] {
			t.Fatalf("region %s locale %q != languages[0] %q", p.country, p.locale, p.languages[0])
		}
		// locale = lang-COUNTRY; country component must equal the row's country.
		parts := strings.SplitN(p.locale, "-", 2)
		if len(parts) != 2 || !strings.EqualFold(parts[1], p.country) {
			t.Fatalf("region %s locale %q country component != %q", p.country, p.locale, p.country)
		}
	}
}

// Feature: global-fingerprint-optimization, Property 10: Country-parameter region coherence — a known ISO code (any casing/whitespace) yields tz/languages/locale of a profile whose country equals the code.
func TestProperty10_CountryParamCoherence(t *testing.T) {
	f := func(pick uint8, padL, padR bool, upper bool) bool {
		cc := regionProfiles[int(pick)%len(regionProfiles)].country
		arg := cc
		if upper {
			arg = strings.ToUpper(arg)
		}
		if padL {
			arg = "  " + arg
		}
		if padR {
			arg = arg + "\t"
		}
		id := RandomIdentityWithOptions(GenOptions{Country: arg})
		// Result must match some profile row with this country.
		for _, p := range regionProfiles {
			if p.country == cc && id.TimeZone == p.timeZone && id.Locale == p.locale && sameStrs(id.Languages, p.languages) {
				return true
			}
		}
		return false
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 11: Unknown or empty country falls back to a valid random region without error.
func TestProperty11_UnknownCountryFallback(t *testing.T) {
	locales := map[string]bool{}
	for _, p := range regionProfiles {
		locales[p.locale] = true
	}
	f := func(junk string) bool {
		id := RandomIdentityWithOptions(GenOptions{Country: junk})
		return locales[id.Locale] // resolved to a table profile
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

func sameStrs(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}
