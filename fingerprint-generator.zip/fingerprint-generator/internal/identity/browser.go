package identity

import (
	"fmt"
	"math/rand"
)

// Non-Chrome identity generation (Firefox / Safari) ────────────────────
// Covers Requirement 7.3 (engine/GPU/plugins consistency, Chromium-only client
// hints omitted), 7.7 (tier/platform coherence), and 7.10 (platform matrix:
// Safari→macOS/iOS, Firefox→Win/mac/Linux/Android; never Safari on Win/Linux/Android).

var firefoxVersions = []string{
	"118.0", "119.0", "120.0", "121.0", "122.0", "123.0", "124.0", "125.0",
	"126.0", "127.0", "128.0", "129.0", "130.0", "131.0",
}

var safariVersions = []string{"16.6", "17.0", "17.1", "17.2", "17.3", "17.4", "17.5", "18.0"}

// buildNonChromeIdentity builds a Firefox or Safari identity following the
// platform matrix. browser ∈ {firefox, safari}; device ∈ {desktop, mobile, ""}.
func buildNonChromeIdentity(o GenOptions, browser, device string) *BrowserIdentity {
	tier := genHardwareTier()
	region := resolveRegion(o.Country)
	mobile := device == deviceMobile

	id := &BrowserIdentity{
		// Chromium-only client hints are omitted for non-Chrome (Requirement 7.3).
		SecUA:           "",
		SecCHUAPlatform: "",
		SecCHUAMobile:   "",
		WebGLExts:       genWebGLExts(),
		Plugins:         []map[string]string{}, // non-Chrome: no Chrome plugin set
		TimeZone:        region.timeZone,
		Languages:       region.languages,
		Locale:          region.locale,
		BrowserFamily:   browser,
	}
	mathTan, mathSin, mathCos := genMath()
	id.MathTan, id.MathSin, id.MathCos = mathTan, mathSin, mathCos
	id.CanvasHash, id.HistogramBase = generateCanvasData()

	if browser == browserSafari {
		id.GPUVendor = "Apple Inc."
		id.GPUModel = "Apple GPU"
		if mobile {
			// Safari mobile → iOS (Requirement 7.10).
			id.DeviceType = deviceMobile
			id.MobilePlatform = mobileIOS
			id.Platform = platIOS
			ver := safariVersions[rand.Intn(len(safariVersions))]
			iosVer := iosVersions[rand.Intn(len(iosVersions))]
			id.ChromeVer = ver
			id.UA = fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/%s Mobile/15E148 Safari/604.1", iosVer, ver)
			id.Fonts = shuffledSubset(fontsIOS)
			hw := genMobileHardware(tier)
			id.DeviceMemory, id.HardwareConcurrency = hw.deviceMemory, hw.hardwareConcurrency
			id.Screen = mobileScreen(iosScreens)
			id.AudioFingerprint = genAudio(platMacOS, tier)
		} else {
			// Safari desktop → macOS (Requirement 7.10), Apple Silicon.
			id.DeviceType = deviceDesktop
			id.MobilePlatform = ""
			id.Platform = platMacOS
			ver := safariVersions[rand.Intn(len(safariVersions))]
			id.ChromeVer = ver
			id.UA = fmt.Sprintf("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/%s Safari/605.1.15", ver)
			id.Fonts = genFonts(platMacOS)
			// Apple Silicon unified-memory / core sets (Requirement 5.3).
			hw := genHardwareSpec(platMacOS, tier, "Apple M")
			id.DeviceMemory, id.HardwareConcurrency = hw.deviceMemory, hw.hardwareConcurrency
			id.Screen = genScreen(platMacOS)
			id.AudioFingerprint = genAudio(platMacOS, tier)
		}
		return id
	}

	// Firefox (Gecko).
	ver := firefoxVersions[rand.Intn(len(firefoxVersions))]
	id.ChromeVer = ver
	if mobile {
		// Firefox mobile → Android (Requirement 7.10).
		id.DeviceType = deviceMobile
		id.MobilePlatform = mobileAndroid
		id.Platform = platAndroid
		andVer := androidVersions[rand.Intn(len(androidVersions))]
		id.UA = fmt.Sprintf("Mozilla/5.0 (Android %s; Mobile; rv:%s) Gecko/%s Firefox/%s", andVer, ver, ver, ver)
		g := androidGPUTiers[tier][rand.Intn(len(androidGPUTiers[tier]))]
		id.GPUVendor = g.vendor
		id.GPUModel = g.renderer
		id.Fonts = shuffledSubset(fontsAndroid)
		hw := genMobileHardware(tier)
		id.DeviceMemory, id.HardwareConcurrency = hw.deviceMemory, hw.hardwareConcurrency
		id.Screen = mobileScreen(androidScreens)
		id.AudioFingerprint = genAudio(platLinux, tier)
		return id
	}

	// Firefox desktop → Windows / macOS / Linux.
	id.DeviceType = deviceDesktop
	id.MobilePlatform = ""
	platform := genPlatform()
	id.Platform = platform
	switch platform {
	case platMacOS:
		id.UA = fmt.Sprintf("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:%s) Gecko/20100101 Firefox/%s", ver, ver)
	case platLinux:
		id.UA = fmt.Sprintf("Mozilla/5.0 (X11; Linux x86_64; rv:%s) Gecko/20100101 Firefox/%s", ver, ver)
	default:
		id.UA = fmt.Sprintf("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:%s) Gecko/20100101 Firefox/%s", ver, ver)
	}
	gpuVendor, gpuModel := genGPU(platform, tier)
	id.GPUVendor, id.GPUModel = gpuVendor, gpuModel
	id.Fonts = genFonts(platform)
	spec := genHardwareSpec(platform, tier, gpuModel)
	id.DeviceMemory, id.HardwareConcurrency = spec.deviceMemory, spec.hardwareConcurrency
	id.Screen = genScreen(platform)
	id.AudioFingerprint = genAudio(platform, tier)
	return id
}

// mobileScreen builds a portrait ScreenInfo from a mobile resolution set.
func mobileScreen(set []mobileRes) ScreenInfo {
	res := set[rand.Intn(len(set))]
	return ScreenInfo{
		Width:            res.w,
		Height:           res.h,
		AvailWidth:       res.w,
		AvailHeight:      res.h - (56 + rand.Intn(24)),
		ColorDepth:       24,
		DevicePixelRatio: res.dpr,
	}
}
