package identity

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	stdurl "net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const identityCacheTTL = 6 * time.Hour

type cachedIdentity struct {
	Identity  *BrowserIdentity `json:"identity"`
	CreatedAt int64            `json:"createdAt"`
}

var (
	idCacheMu   sync.Mutex
	idCache     map[string]cachedIdentity
	cacheDir    string
	cacheDirSet bool
)

// SetCacheDir sets the cache directory. Must be called before IdentityForProxy.
// Default: ~/.fingerprint-generator/
func SetCacheDir(dir string) {
	idCacheMu.Lock()
	defer idCacheMu.Unlock()
	cacheDir = dir
	cacheDirSet = true
}

func getCacheDir() string {
	if cacheDirSet {
		return cacheDir
	}
	home, err := os.UserHomeDir()
	if err != nil {
		home = "."
	}
	return filepath.Join(home, ".fingerprint-generator")
}

func identityCachePath() string {
	return filepath.Join(getCacheDir(), "identities.dat")
}

// proxyKey normalizes a proxy URL to a stable cache key: host:port only.
func proxyKey(proxyURL string) string {
	proxyURL = strings.TrimSpace(proxyURL)
	if proxyURL == "" {
		return "direct"
	}
	u, err := stdurl.Parse(proxyURL)
	if err != nil || u.Host == "" {
		sum := sha256.Sum256([]byte(proxyURL))
		return "raw:" + hex.EncodeToString(sum[:8])
	}
	key := strings.ToLower(u.Host)
	// Append region hint so different proxy-provider regions get separate identities.
	if region := extractRegionHint(proxyURL); region != "" {
		key += "#" + region
	}
	return key
}

func loadIdentityCacheLocked() {
	if idCache != nil {
		return
	}
	idCache = map[string]cachedIdentity{}
	b, err := os.ReadFile(identityCachePath())
	if err != nil {
		return
	}
	var m map[string]cachedIdentity
	if json.Unmarshal(b, &m) == nil && m != nil {
		idCache = m
	}
}

func saveIdentityCacheLocked() {
	if idCache == nil {
		return
	}
	b, err := json.Marshal(idCache)
	if err != nil {
		return
	}
	os.MkdirAll(filepath.Dir(identityCachePath()), 0o755)
	tmp := identityCachePath() + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, identityCachePath())
	}
}

// extractRegionHint pulls a proxy-provider-style `__cr.XX` ISO country code from a
// proxy URL, e.g. "user__cr.us:pass@host:port" => "us". Returns "" if absent.
func extractRegionHint(proxyURL string) string {
	const marker = "__cr."
	idx := strings.Index(proxyURL, marker)
	if idx < 0 {
		return ""
	}
	rest := proxyURL[idx+len(marker):]
	// Country code runs until a non-alpha delimiter (":", "@", "_", etc.).
	end := 0
	for end < len(rest) {
		c := rest[end]
		if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') {
			end++
			continue
		}
		break
	}
	return strings.ToLower(rest[:end])
}

// IdentityForProxy returns a stable identity bound to a proxy.
// Same proxy reuses the same hardware fingerprint for 6 hours.
func IdentityForProxy(proxyURL string) *BrowserIdentity {
	key := proxyKey(proxyURL)
	regionHint := extractRegionHint(proxyURL)

	idCacheMu.Lock()
	defer idCacheMu.Unlock()
	loadIdentityCacheLocked()

	now := time.Now().Unix()
	if entry, ok := idCache[key]; ok && entry.Identity != nil {
		if now-entry.CreatedAt < int64(identityCacheTTL.Seconds()) {
			return refreshVolatile(entry.Identity)
		}
	}

	// Region hint (if any) makes timezone/language coherent with the proxy geo.
	id := RandomIdentityForRegion(0, regionHint)
	idCache[key] = cachedIdentity{Identity: id, CreatedAt: now}
	saveIdentityCacheLocked()
	return refreshVolatile(id)
}

// refreshVolatile clones the cached identity. Per-target volatile seeds (e.g.
// Amazon's lsUbid prefix / webpackHash) are derived in the antibot adapter, not here.
func refreshVolatile(base *BrowserIdentity) *BrowserIdentity {
	clone := *base
	return &clone
}

// ResetIdentityCache clears the identity cache.
func ResetIdentityCache() {
	idCacheMu.Lock()
	defer idCacheMu.Unlock()
	idCache = map[string]cachedIdentity{}
	_ = os.Remove(identityCachePath())
}
