package behavioral

import (
	"reflect"
	"testing"

	"fingerprint-generator/internal/identity"
)

func TestDeterministicBySeed(t *testing.T) {
	a := New(42).MouseTrack(Point{0, 0}, Point{500, 300}, 40)
	b := New(42).MouseTrack(Point{0, 0}, Point{500, 300}, 40)
	if !reflect.DeepEqual(a, b) {
		t.Fatal("same seed must produce identical trajectory")
	}
}

func TestDiffersAcrossIdentities(t *testing.T) {
	id1 := identity.RandomIdentity()
	id2 := identity.RandomIdentity()
	t1 := NewFromIdentity(id1).MouseTrack(Point{0, 0}, Point{400, 400}, 30)
	t2 := NewFromIdentity(id2).MouseTrack(Point{0, 0}, Point{400, 400}, 30)
	if reflect.DeepEqual(t1, t2) {
		t.Fatal("distinct identities should yield distinct trajectories")
	}
}

func TestTrajectoryNotConstantSpeed(t *testing.T) {
	tr := New(7).MouseTrack(Point{0, 0}, Point{1000, 0}, 60)
	if len(tr) < 3 {
		t.Fatal("trajectory too short")
	}
	// Inter-sample time steps must not all be identical (constant speed = bot).
	d1 := tr[1].T - tr[0].T
	allSame := true
	for i := 2; i < len(tr); i++ {
		if tr[i].T-tr[i-1].T != d1 {
			allSame = false
			break
		}
	}
	if allSame {
		t.Fatal("timing steps are constant (non-human)")
	}
}

func TestSampleCap(t *testing.T) {
	tr := New(1).MouseTrack(Point{0, 0}, Point{10, 10}, 1_000_000)
	if len(tr) > maxSamples {
		t.Fatalf("sample count %d exceeds cap %d", len(tr), maxSamples)
	}
}

func TestClicksWithinBounds(t *testing.T) {
	b := Rect{X: 10, Y: 20, W: 100, H: 50}
	clicks := New(3).Clicks(25, b)
	var prev int64 = -1
	for _, c := range clicks {
		if c.X < b.X || c.X >= b.X+b.W || c.Y < b.Y || c.Y >= b.Y+b.H {
			t.Fatalf("click %v outside bounds %v", c, b)
		}
		if c.T <= prev {
			t.Fatalf("click timestamps must increase: %d <= %d", c.T, prev)
		}
		prev = c.T
	}
}
