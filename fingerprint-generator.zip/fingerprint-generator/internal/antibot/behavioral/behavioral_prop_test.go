package behavioral

import (
	"reflect"
	"testing"
	"testing/quick"

	"fingerprint-generator/internal/identity"
)

// Feature: global-fingerprint-optimization, Property 22: Behavioral data variability — for any two independently generated identities, the synthesized behavioral data (trajectories, clicks, timing) differ and are never a fixed constant vector.
func TestProperty22_BehavioralVariability(t *testing.T) {
	f := func(_ uint8) bool {
		id1 := identity.RandomIdentity()
		id2 := identity.RandomIdentity()
		m1 := NewFromIdentity(id1).MouseTrack(Point{0, 0}, Point{300, 300}, 20)
		m2 := NewFromIdentity(id2).MouseTrack(Point{0, 0}, Point{300, 300}, 20)
		if reflect.DeepEqual(m1, m2) {
			return false // must differ between identities
		}
		// Not a fixed constant vector: samples within a track vary.
		allSame := true
		for i := 1; i < len(m1); i++ {
			if m1[i] != m1[0] {
				allSame = false
				break
			}
		}
		return !allSame
	}
	if err := quick.Check(f, &quick.Config{MaxCount: 100}); err != nil {
		t.Fatal(err)
	}
}
