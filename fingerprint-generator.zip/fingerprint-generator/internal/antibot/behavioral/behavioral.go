// Package behavioral synthesizes human-like interaction signals (mouse/touch
// trajectories, click coordinates, timing) required by some antibot schemas
// (Requirement 9.7). Signals vary between identities (the seed is derived from
// identity signals) and are never emitted as fixed constants. Trajectories use
// Bézier curves with jitter and a non-constant (ease-in-out) speed profile — a
// constant speed is itself a bot signal. Deterministic when explicitly seeded so
// tests are reproducible. Pure Go stdlib.
package behavioral

import (
	"hash/fnv"
	"math"
	"math/rand"

	"fingerprint-generator/internal/identity"
)

// maxSamples caps synthesized sample counts to bound CPU/memory (DoS guard).
const maxSamples = 2048

// Point is an integer screen coordinate.
type Point struct{ X, Y int }

// Rect is an integer bounding box.
type Rect struct{ X, Y, W, H int }

// Sample is a coordinate with a relative timestamp in milliseconds.
type Sample struct {
	X int   `json:"x"`
	Y int   `json:"y"`
	T int64 `json:"t"`
}

// Synth wraps a seeded RNG so trajectories are reproducible per seed.
type Synth struct{ rng *rand.Rand }

// New creates a Synth from an explicit seed (deterministic).
func New(seed int64) *Synth { return &Synth{rng: rand.New(rand.NewSource(seed))} }

// NewFromIdentity seeds a Synth from identity signals (UA|canvas|audio) so two
// different identities almost certainly produce different signals.
func NewFromIdentity(id *identity.BrowserIdentity) *Synth {
	h := fnv.New64a()
	if id != nil {
		_, _ = h.Write([]byte(id.UA))
		_, _ = h.Write([]byte{byte(id.CanvasHash), byte(id.CanvasHash >> 8), byte(id.CanvasHash >> 16), byte(id.CanvasHash >> 24)})
		_, _ = h.Write([]byte(id.AudioFingerprint))
	}
	return New(int64(h.Sum64()))
}

func clampN(n int) int {
	if n < 0 {
		return 0
	}
	if n > maxSamples {
		return maxSamples
	}
	return n
}

// easeInOut maps t∈[0,1] to a non-linear progress (smoothstep) so velocity is
// non-constant along the trajectory.
func easeInOut(t float64) float64 { return t * t * (3 - 2*t) }

// bezierTrack builds an n-sample trajectory from → to along a quadratic Bézier
// with a randomized control point and per-sample jitter, using an ease-in-out
// time/space profile and non-constant inter-sample timing.
func (s *Synth) bezierTrack(from, to Point, n int) []Sample {
	n = clampN(n)
	if n <= 0 {
		return []Sample{}
	}
	// Control point: midpoint offset by a random perpendicular-ish amount.
	dx := float64(to.X - from.X)
	dy := float64(to.Y - from.Y)
	midX := float64(from.X) + dx*0.5
	midY := float64(from.Y) + dy*0.5
	offset := 20.0 + s.rng.Float64()*80.0
	cx := midX - dy*0.2 + (s.rng.Float64()-0.5)*offset
	cy := midY + dx*0.2 + (s.rng.Float64()-0.5)*offset

	out := make([]Sample, n)
	var t int64
	for i := 0; i < n; i++ {
		lin := float64(i) / float64(max(1, n-1))
		u := easeInOut(lin)
		omu := 1 - u
		// Quadratic Bézier B(u) = (1-u)^2 P0 + 2(1-u)u C + u^2 P1.
		x := omu*omu*float64(from.X) + 2*omu*u*cx + u*u*float64(to.X)
		y := omu*omu*float64(from.Y) + 2*omu*u*cy + u*u*float64(to.Y)
		// Sub-pixel jitter (shrinks near the endpoint).
		jitter := (1 - u) * 2.0
		x += (s.rng.Float64() - 0.5) * jitter
		y += (s.rng.Float64() - 0.5) * jitter
		// Non-constant timing: slower at the ends, faster in the middle.
		step := int64(6 + s.rng.Intn(10) + int(12*(1-math.Abs(0.5-lin)*2)))
		t += step
		out[i] = Sample{X: int(math.Round(x)), Y: int(math.Round(y)), T: t}
	}
	return out
}

// MouseTrack returns a human-like mouse trajectory from → to with n samples.
func (s *Synth) MouseTrack(from, to Point, n int) []Sample { return s.bezierTrack(from, to, n) }

// TouchTrack returns a human-like touch trajectory (same model, distinct call
// site for touch events).
func (s *Synth) TouchTrack(from, to Point, n int) []Sample { return s.bezierTrack(from, to, n) }

// Clicks returns n click samples within bounds with monotonically increasing,
// human-like timing.
func (s *Synth) Clicks(n int, bounds Rect) []Sample {
	n = clampN(n)
	out := make([]Sample, n)
	var t int64
	w := max(1, bounds.W)
	h := max(1, bounds.H)
	for i := 0; i < n; i++ {
		t += int64(120 + s.rng.Intn(900)) // inter-click gap
		out[i] = Sample{
			X: bounds.X + s.rng.Intn(w),
			Y: bounds.Y + s.rng.Intn(h),
			T: t,
		}
	}
	return out
}

// Timing returns n interval values (ms) in [minMs, maxMs] with variation.
func (s *Synth) Timing(n, minMs, maxMs int) []int {
	n = clampN(n)
	if maxMs < minMs {
		minMs, maxMs = maxMs, minMs
	}
	span := maxMs - minMs
	out := make([]int, n)
	for i := 0; i < n; i++ {
		if span <= 0 {
			out[i] = minMs
		} else {
			out[i] = minMs + s.rng.Intn(span+1)
		}
	}
	return out
}
