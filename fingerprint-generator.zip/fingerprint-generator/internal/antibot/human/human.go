// Package human implements the HUMAN (formerly PerimeterX) payload+envelope
// builder. It shares DataDome's encoding primitives and signal layout, with
// HUMAN's fixed interstitial HSV.
//
// REGISTERED. Reuses datadome.BuildSignals + the verified DataDomeEncode
// pipeline. Requires session inputs cid + hash + url.
package human

import (
	"encoding/json"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/antibot/cryptoutil"
	"fingerprint-generator/internal/antibot/datadome"
	"fingerprint-generator/internal/identity"
)

// HUMAN build constants. The interstitial HSV is fixed; the main/cid seed
// constants match DataDome's (shared bundle family).
const (
	mainBuildConst  = uint32(0x7d8479f9)
	cidBuildConst   = uint32(1809053797)
	hsvInterstitial = "9E9FC74889F6"
)

// compile-time interface check.
var _ antibot.Target = Target{}

func init() { antibot.Register(Target{}) }

// Target implements antibot.Target for HUMAN.
type Target struct{}

func (Target) Name() string { return "human" }

func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{
		EncryptionApplicable: true,
		RequiredInputs:       map[string][]string{"": {"cid", "hash"}},
	}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build reuses DataDome's signal layout with HUMAN's fixed HSV, then applies the
// shared envelope.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	entries := datadome.BuildSignals(ctx.Identity, ctx.SessionInputs, behavioral.NewFromIdentity(ctx.Identity))
	// HUMAN interstitial pins the hsv signal (if present) to a fixed value.
	for i := range entries {
		if entries[i][0] == "hsv" {
			entries[i][1] = "\"" + hsvInterstitial + "\""
		}
	}

	ddk := ctx.SessionInputs.Get("hash")
	cid := ctx.SessionInputs.Get("cid")
	mainSeed := mainBuildConst ^ cryptoutil.Djb2u(ddk)
	cidSeed := cidBuildConst ^ cryptoutil.Djb2u(cid)
	u := uint32(ctx.ClockNow().UnixMilli()>>3) & 0xFF

	raw, err := json.Marshal(entries)
	if err != nil {
		return nil, err
	}
	encoded := cryptoutil.DataDomeEncode(entries, mainSeed, cidSeed, u)
	return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
}
