// Package microsoft implements the antibot.Target for Microsoft/Outlook's Arkose
// FunCaptcha BDA payload (anti-bot-fingerprint-reference.md §3). It reuses the
// shared arkose BDA builder and carries Microsoft's static Arkose public key.
// Tier A: all constants stable (anti-bot-crypto-constants.md §3). Stateless.
package microsoft

import (
	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/arkose"
	"fingerprint-generator/internal/identity"
)

// publicKey is Microsoft/Outlook's static Arkose public key
// (anti-bot-crypto-constants.md §3).
const publicKey = "B7D8911C-5CC8-A9A3-35B0-554ACEE604DA"

// Target implements antibot.Target for Microsoft Arkose.
type Target struct{}

func init() { antibot.Register(Target{}) }

func (Target) Name() string { return "microsoft" }

// Capabilities: single-output, enveloped. The public key is static, so no
// required session inputs.
func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{EncryptionApplicable: true, RequiredInputs: map[string][]string{"": nil}}
}

// Build shapes the identity into the Arkose BDA payload + {ct,iv,s} envelope.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	raw, encoded, err := arkose.BuildBDA(ctx.Identity, ctx.ClockNow())
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
}

// IdentityExtras surfaces the Arkose public key so consumers can submit it
// alongside the BDA blob.
func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} {
	return map[string]interface{}{"arkosePublicKey": publicKey}
}
