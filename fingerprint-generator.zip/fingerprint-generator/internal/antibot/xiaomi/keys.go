package xiaomi

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
)

// RSA key material for Xiaomi MiMo (anti-bot-crypto-constants.md §1). All stable.
// EUI = RSA-1024 (account registration), Captcha = RSA-2048 (captcha data).

const euiPubPEM = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYEVrK/4Mahiv0pUJgTybx4J9P
5dUT/Y0PuwMbk+gMU+jrZnBiXGv6/hCH1avIhoBcE535F8nJQQN3UavZdFkYidso
XuEnat3+eVTp3FslyhRwIBDF09v4vDhRtxFOT+R7uH7h/mzmyA2/+lfIMWGIrffX
prYizbV76+YQKhoqFQIDAQAB
-----END PUBLIC KEY-----`

const captchaPubPEM = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArxfNLkuAQ/BYHzkzVwtu
g+0abmYRBVCEScSzGxJIOsfxVzcuqaKO87H2o2wBcacD3bRHhMjTkhSEqxPjQ/FE
XuJ1cdbmr3+b3EQR6wf/cYcMx2468/QyVoQ7BADLSPecQhtgGOllkC+cLYN6Md34
Uii6U+VJf0p0q/saxUTZvhR2ka9fqJ4+6C6cOghIecjMYQNHIaNW+eSKunfFsXVU
+QfMD0q2EM9wo20aLnos24yDzRjh9HJc6xfr37jRlv1/boG/EABMG9FnTm35xWrV
R0nw3cpYF7GZg13QicS/ZwEsSd4HyboAruMxJBPvK3Jdr4ZS23bpN0cavWOJsBqZ
VwIDAQAB
-----END PUBLIC KEY-----`

// Expected moduli (hex) from the constants doc — used by smoke tests to catch
// mis-copied key material.
const (
	EUIModulusHex     = "98115acaff831a862bf4a542604f26f1e09f4fe5d513fd8d0fbb031b93e80c53e8eb6670625c6bfafe1087d5abc886805c139df917c9c941037751abd974591889db285ee1276addfe7954e9dc5b25ca14702010c5d3dbf8bc3851b7114e4fe47bb87ee1fe6ce6c80dbffa57c8316188adf7d7a6b622cdb57bebe6102a1a2a15"
	CaptchaModulusHex = "af17cd2e4b8043f0581f3933570b6e83ed1a6e661105508449c4b31b12483ac7f157372ea9a28ef3b1f6a36c0171a703ddb44784c8d3921484ab13e343f1445ee27571d6e6af7f9bdc4411eb07ff71870cc76e3af3f43256843b0400cb48f79c421b6018e965902f9c2d837a31ddf85228ba53e5497f4a74abfb1ac544d9be147691af5fa89e3ee82e9c3a084879c8cc61034721a356f9e48aba77c5b17554f907cc0f4ab610cf70a36d1a2e7a2cdb8c83cd18e1f4725ceb17ebdfb8d196fd7f6e81bf10004c1bd1674e6df9c56ad54749f0ddca5817b199835dd089c4bf67012c49de07c9ba00aee3312413ef2b725daf8652db76e937471abd6389b01a9957"
)

// Xiaomi fixed constants (anti-bot-crypto-constants.md §1).
const (
	fixedIV        = "0102030405060708" // 16 ASCII bytes, used directly as the AES IV
	captchaCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()-=_+~`{}[]|:<>?/."
	captchaDataKey = "8027422fb0eb42fbac1b521ec4a7961f"
	sitekey        = "6LeBM0ocAAAAAEwYcFUjtxpVbs-0rnbSVXBBXmh4"
	defaultURL     = "https://global.account.xiaomi.com/fe/service/register?_locale=en_US&_uRegion=ID"
)

var (
	euiPubKey     = mustParseRSA(euiPubPEM)
	captchaPubKey = mustParseRSA(captchaPubPEM)
)

func mustParseRSA(pemStr string) *rsa.PublicKey {
	blk, _ := pem.Decode([]byte(pemStr))
	if blk == nil {
		panic("xiaomi: failed to decode RSA PEM")
	}
	k, err := x509.ParsePKIXPublicKey(blk.Bytes)
	if err != nil {
		panic(fmt.Sprintf("xiaomi: failed to parse RSA public key: %v", err))
	}
	return k.(*rsa.PublicKey)
}

// EUIPublicKey and CaptchaPublicKey expose the parsed keys for smoke tests.
func EUIPublicKey() *rsa.PublicKey     { return euiPubKey }
func CaptchaPublicKey() *rsa.PublicKey { return captchaPubKey }
