// Package xiaomi implements the antibot.Target for the Xiaomi MiMo / passport
// captcha data payload (anti-bot-fingerprint-reference.md §1). It shapes the
// generic identity into the env/action payload and wraps it in Xiaomi's
// envelope: s=RSA-2048(base64(aesKey)) & d=AES-128-CBC(json) & a=register.
// Tier A: all constants stable (anti-bot-crypto-constants.md §1). Stateless —
// the page URL is an optional Session_Input; no network access.
package xiaomi

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/url"
	"strings"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/identity"
)

// Target implements antibot.Target for Xiaomi.
type Target struct{}

func init() { antibot.Register(Target{}) }

func (Target) Name() string { return "xiaomi" }

// Capabilities: single-output, enveloped. `url` is optional (a default register
// URL is used when absent), so there are no strictly-required session inputs.
func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{EncryptionApplicable: true, RequiredInputs: map[string][]string{"": nil}}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

type xiaomiEnv struct {
	P1  string        `json:"p1"`
	P2  string        `json:"p2"`
	P3  string        `json:"p3"`
	P4  string        `json:"p4"`
	P5  string        `json:"p5"`
	P6  string        `json:"p6"`
	P7  string        `json:"p7"`
	P8  bool          `json:"p8"`
	P9  string        `json:"p9"`
	P10 int           `json:"p10"`
	P11 int64         `json:"p11"`
	P12 int           `json:"p12"`
	P13 int           `json:"p13"`
	P14 int           `json:"p14"`
	P15 int           `json:"p15"`
	P16 int           `json:"p16"`
	P17 int           `json:"p17"`
	P18 string        `json:"p18"`
	P19 int           `json:"p19"`
	P20 string        `json:"p20"`
	P21 string        `json:"p21"`
	P22 int           `json:"p22"`
	P23 string        `json:"p23"`
	P24 string        `json:"p24"`
	P25 string        `json:"p25"`
	P26 string        `json:"p26"`
	P28 string        `json:"p28"`
	P29 int           `json:"p29"`
	P30 int           `json:"p30"`
	P31 int           `json:"p31"`
	P32 string        `json:"p32"`
	P33 []interface{} `json:"p33"`
	P34 string        `json:"p34"`
}

type xiaomiAction struct {
	A1  []int         `json:"a1"`
	A2  []interface{} `json:"a2"`
	A3  [][]int       `json:"a3"`
	A4  []interface{} `json:"a4"`
	A5  [][]int       `json:"a5"`
	A6  []interface{} `json:"a6"`
	A7  []interface{} `json:"a7"`
	A8  []int         `json:"a8"`
	A9  []int         `json:"a9"`
	A10 []interface{} `json:"a10"`
	A11 []interface{} `json:"a11"`
	A12 []interface{} `json:"a12"`
	A13 []interface{} `json:"a13"`
	A14 []interface{} `json:"a14"`
}

type xiaomiNonce struct {
	T int64 `json:"t"`
	R int64 `json:"r"`
}

type xiaomiPayload struct {
	Type     int          `json:"type"`
	StartTs  int64        `json:"startTs"`
	EndTs    int64        `json:"endTs"`
	Env      xiaomiEnv    `json:"env"`
	Action   xiaomiAction `json:"action"`
	Force    bool         `json:"force"`
	TalkBack bool         `json:"talkBack"`
	Nonce    xiaomiNonce  `json:"nonce"`
	Version  string       `json:"version"`
	Scene    string       `json:"scene"`
}

func sha1hex(s string) string {
	h := sha1.Sum([]byte(s))
	return hex.EncodeToString(h[:])
}

// Build shapes the identity into the Xiaomi captcha payload + envelope.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	now := ctx.ClockNow()
	startMs := now.UnixMilli()
	syn := behavioral.NewFromIdentity(id)

	pageURL := ctx.SessionInputs.Get("url")
	if pageURL == "" {
		pageURL = defaultURL
	}

	// Device+browser identifier, e.g. "pc-Chrome131" / "mobile-Chrome131".
	form := "pc"
	if id.DeviceType == "mobile" {
		form = "mobile"
	}
	major := id.ChromeVer
	if i := strings.IndexByte(major, '.'); i > 0 {
		major = major[:i]
	}
	fam := "Chrome"
	switch id.BrowserFamily {
	case "firefox":
		fam = "Firefox"
	case "safari":
		fam = "Safari"
	}

	innerW := id.Screen.Width - 60
	innerH := id.Screen.Height - 120
	if innerW < 0 {
		innerW = id.Screen.Width
	}
	if innerH < 0 {
		innerH = id.Screen.Height
	}

	// Behavioral clicks → a3 (mousedown) / a5 (mouseup) as [x,y,t] triples.
	clicks := syn.Clicks(2, behavioral.Rect{X: 0, Y: 0, W: max1(innerW), H: max1(innerH)})
	a3 := make([][]int, 0, len(clicks))
	a5 := make([][]int, 0, len(clicks))
	for _, c := range clicks {
		a3 = append(a3, []int{c.X, c.Y, int(c.T % 1000)})
		a5 = append(a5, []int{c.X, c.Y, int((c.T + 5) % 1000)})
	}

	env := xiaomiEnv{
		P1: "0.1", P2: fmt.Sprintf("%s-%s%s", form, fam, major), P3: id.Platform,
		P4: "Gecko", P5: id.Locale, P6: "Netscape", P7: "Mozilla", P8: true, P9: id.UA,
		P10: 0, P11: startMs, P12: id.Screen.Width, P13: id.Screen.Height,
		P14: id.Screen.AvailWidth, P15: id.Screen.AvailHeight, P16: innerW, P17: innerH,
		P18: pageURL, P19: id.HardwareConcurrency,
		P20: sha1hex(fmt.Sprintf("canvas:%d", id.CanvasHash)),
		P21: strings.Join([]string{
			"P" + sha1hex("plat:"+id.Platform),
			"C" + sha1hex(fmt.Sprintf("canvas:%d", id.CanvasHash)),
			"M" + sha1hex("math:"+id.MathTan+id.MathSin+id.MathCos),
			"W" + sha1hex("webgl:"+id.GPUModel+strings.Join(id.WebGLExts, ",")),
		}, ","),
		P22: 0, P23: sha1hex(""), P24: "",
		P25: sha1hex("audio:" + id.AudioFingerprint),
		P26: sha1hex("fonts:" + strings.Join(id.Fonts, ",")),
		P28: "", P29: len(id.Plugins), P30: 10, P31: 10, P32: "0.73",
		P33: []interface{}{}, P34: pageURL,
	}

	action := xiaomiAction{
		A1: []int{innerW, innerH}, A2: []interface{}{}, A3: a3, A4: []interface{}{},
		A5: a5, A6: []interface{}{}, A7: []interface{}{},
		A8: []int{a3[0][2]}, A9: []int{a3[0][2], a5[len(a5)-1][2]},
		A10: []interface{}{}, A11: []interface{}{}, A12: []interface{}{},
		A13: []interface{}{}, A14: []interface{}{},
	}

	payload := xiaomiPayload{
		Type: 0, StartTs: startMs, EndTs: startMs + int64(600+syn.Timing(1, 0, 1200)[0]),
		Env: env, Action: action, Force: true, TalkBack: false,
		Nonce:   xiaomiNonce{T: now.Unix(), R: int64(syn.Timing(1, 1000000000, 2000000000)[0])*1000 + int64(syn.Timing(1, 0, 999)[0])},
		Version: "2.0", Scene: "register",
	}

	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}

	encoded, err := encryptEnvelope(raw)
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
}

func max1(v int) int {
	if v < 1 {
		return 1
	}
	return v
}

// encryptEnvelope builds `s=<RSA(base64(aesKey))>&d=<AES-CBC(json)>&a=register`.
// s and d are base64 then form-encoded for the register POST body.
func encryptEnvelope(payloadJSON []byte) (string, error) {
	aesKey, err := randomKey(captchaCharset, 16)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(aesKey) // AES-128 (16-byte key)
	if err != nil {
		return "", err
	}
	iv := []byte(fixedIV)
	if len(iv) != aes.BlockSize {
		return "", fmt.Errorf("xiaomi: fixed IV must be %d bytes, got %d", aes.BlockSize, len(iv))
	}
	ct := cbcEncrypt(block, iv, pkcs7Pad(payloadJSON, aes.BlockSize))
	d := base64.StdEncoding.EncodeToString(ct)

	// s = RSA-2048 PKCS#1 v1.5 encrypt of base64(aesKey).
	keyB64 := base64.StdEncoding.EncodeToString(aesKey)
	enc, err := rsa.EncryptPKCS1v15(rand.Reader, captchaPubKey, []byte(keyB64))
	if err != nil {
		return "", err
	}
	s := base64.StdEncoding.EncodeToString(enc)

	return "s=" + url.QueryEscape(s) + "&d=" + url.QueryEscape(d) + "&a=register", nil
}

// randomKey returns n bytes each a random char from charset (crypto/rand).
func randomKey(charset string, n int) ([]byte, error) {
	out := make([]byte, n)
	buf := make([]byte, n)
	if _, err := rand.Read(buf); err != nil {
		return nil, err
	}
	for i := 0; i < n; i++ {
		out[i] = charset[int(buf[i])%len(charset)]
	}
	return out, nil
}

func pkcs7Pad(data []byte, blockSize int) []byte {
	pad := blockSize - len(data)%blockSize
	out := make([]byte, len(data)+pad)
	copy(out, data)
	for i := len(data); i < len(out); i++ {
		out[i] = byte(pad)
	}
	return out
}

func cbcEncrypt(block cipher.Block, iv, data []byte) []byte {
	out := make([]byte, len(data))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(out, data)
	return out
}
