// Package cloudflare is a Tier C SCAFFOLD for Cloudflare's JSD challenge and
// Turnstile (anti-bot-fingerprint-reference.md §6/§7, anti-bot-crypto-constants.md §6/§7).
//
// NOT REGISTERED: for JSD the LZ alphabet and ~1610-entry template rotate
// per-script; for Turnstile the float XOR key, VM bytecode, and field
// serialization rotate per-request. No stable constants exist (constants doc
// marks all TIDAK STABIL). Per Requirement 8.4/8.6 this target is not registered
// (no init() Register, no blank import); requests return the standard 400. The
// scaffold conforms to antibot.Target (with both variants declared) so the seam
// is verified. No proof-of-work, no live fetch (stateless).
package cloudflare

import (
	"encoding/json"
	"fmt"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/cryptoutil"
	"fingerprint-generator/internal/identity"
)

// compile-time interface check (conforms without being registered).
var _ antibot.Target = Target{}

// Target implements antibot.Target for Cloudflare (scaffold, not registered).
type Target struct{}

func (Target) Name() string { return "cloudflare" }

func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{
		Variants:             []string{"jsd", "turnstile"},
		DefaultVariant:       "jsd",
		EncryptionApplicable: true,
		RequiredInputs: map[string][]string{
			"jsd":       {"sitekey", "path", "token"},
			"turnstile": {"sitekey", "ptoken"},
		},
	}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build dispatches by variant. Both paths are structural placeholders (rotating
// constants are unavailable).
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	variant := ctx.Variant
	if variant == "" {
		variant = "jsd"
	}
	switch variant {
	case "jsd":
		return buildJSD(ctx)
	case "turnstile":
		return buildTurnstile(ctx)
	default:
		return nil, fmt.Errorf("cloudflare: unknown variant %q", variant)
	}
}

func buildJSD(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	payload := map[string]interface{}{
		"t":   ctx.ClockNow().Unix(),
		"lhr": "about:blank",
		"api": false,
		"c":   false,
		"payload": map[string]interface{}{
			"__BASEURI__": ctx.SessionInputs.Get("path"),
			"userAgent":   id.UA,
			"platform":    id.Platform,
			"note":        "scaffold: template rotates per-script",
		},
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	// JSD envelope is LZ-string→base64 with a per-script custom alphabet (unknown);
	// use the standard alphabet as a structural placeholder.
	encoded := cryptoutil.CompressToBase64(string(raw), "")
	return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
}

func buildTurnstile(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	payload := map[string]interface{}{
		"sitekey":   ctx.SessionInputs.Get("sitekey"),
		"userAgent": id.UA,
		"platform":  id.Platform,
		"note":      "scaffold: VM bytecode + float key rotate per-request; no PoW",
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	// No stable envelope; return raw as the (unencrypted) placeholder body.
	return &antibot.BuildResult{Raw: raw, Encoded: string(raw)}, nil
}
