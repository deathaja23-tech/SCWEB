// Package arkose builds the Arkose Labs FunCaptcha BDA payload and its OpenSSL
// AES-256-CBC envelope (anti-bot-fingerprint-reference.md §3,
// anti-bot-crypto-constants.md §3). It is a shared BUILDER used by both the
// microsoft target (static public key) and the x target's `arkose` variant
// (per-session sitekey). It is not itself a registered antibot.Target.
//
// Envelope: base64(JSON{"ct":base64(ciphertext),"iv":hex(iv),"s":hex(salt)}),
// AES-256-CBC with key/iv from EVP_BytesToKey(userAgent+timeFrameKey, salt).
// timeFrameKey = floor(unixSec - unixSec%21600) (6-hour window). Stateless.
package arkose

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/antibot/cryptoutil"
	"fingerprint-generator/internal/identity"
)

const timeWindow = 21600 // 6 hours (seconds)

// jsbd mirrors the Arkose browser-metadata object.
type jsbd struct {
	HL   int    `json:"HL"`
	NCE  bool   `json:"NCE"`
	DT   string `json:"DT"`
	NWD  string `json:"NWD"`
	DMTO int    `json:"DMTO"`
	DOTO int    `json:"DOTO"`
}

// BuildBDA builds the BDA payload for id at time now and returns the raw payload
// JSON plus the encrypted, base64 wire blob.
func BuildBDA(id *identity.BrowserIdentity, now time.Time) (json.RawMessage, string, error) {
	unixSec := now.Unix()
	timeFrameKey := unixSec - (unixSec % timeWindow)
	syn := behavioral.NewFromIdentity(id)

	fe := buildFE(id)
	enhanced := buildEnhancedFP(id, syn)

	// f: MurmurHash3-128 hex of fe values joined with ";".
	f := cryptoutil.Murmur3x64_128Hex([]byte(strings.Join(fe, ";")), 0)
	// wh: 2x MurmurHash3-128 (seed 420) joined with "|".
	whInput := id.UA + "|" + id.Platform
	wh := cryptoutil.Murmur3x64_128Hex([]byte(whInput), 420) + "|" + cryptoutil.Murmur3x64_128Hex([]byte(whInput+"#"), 420)
	// ife_hash: MurmurHash3-128 of fe tokens joined with ", " (seed 38).
	ifeHash := cryptoutil.Murmur3x64_128Hex([]byte(strings.Join(fe, ", ")), 38)
	// n: base64 of the UNIX timestamp (seconds).
	n := base64.StdEncoding.EncodeToString([]byte(strconv.FormatInt(unixSec, 10)))

	bda := cryptoutil.NewOrderedMap()
	bda.Set("api_type", "js")
	bda.Set("f", f)
	bda.Set("n", n)
	bda.Set("wh", wh)
	bda.Set("enhanced_fp", enhanced)
	bda.Set("fe", fe)
	bda.Set("ife_hash", ifeHash)
	bda.Set("jsbd", jsbd{HL: 6, NCE: true, DT: "", NWD: "false", DMTO: 1, DOTO: 1})
	// c: copyright string (open item per design; documented-plausible value).
	bda.Set("c", "Copyright (c) FunCaptcha")

	raw, err := bda.MarshalJSON()
	if err != nil {
		return nil, "", err
	}

	encoded, err := encryptBDA(raw, id.UA, timeFrameKey)
	if err != nil {
		return nil, "", err
	}
	return raw, encoded, nil
}

// buildFE assembles the fe array of "PREFIX:value" strings (§3).
func buildFE(id *identity.BrowserIdentity) []string {
	larger, smaller := id.Screen.Width, id.Screen.Height
	if smaller > larger {
		larger, smaller = smaller, larger
	}
	touch := "0,false,false"
	if id.DeviceType == "mobile" {
		touch = "5,true,true"
	}
	plugins := make([]string, 0, len(id.Plugins))
	for _, p := range id.Plugins {
		plugins = append(plugins, p["name"])
	}
	sort.Strings(plugins)
	fonts := append([]string{}, id.Fonts...)
	sort.Strings(fonts)

	return []string{
		"DNT:unknown",
		"L:" + id.Locale,
		"D:" + strconv.Itoa(id.Screen.ColorDepth),
		"PR:" + strconv.Itoa(id.Screen.DevicePixelRatio),
		fmt.Sprintf("S:%d,%d", larger, smaller),
		fmt.Sprintf("AS:%d,%d", id.Screen.AvailWidth, id.Screen.AvailHeight),
		"TO:" + strconv.Itoa(-id.TimeZone*60),
		"SS:true", "LS:true", "IDB:true", "B:false", "ODB:false", "CPUC:unknown",
		"PK:" + id.Platform,
		"CFP:" + strconv.Itoa(int(id.CanvasHash)),
		"FR:false", "FOS:false", "FB:false",
		"JSF:" + strings.Join(fonts, ";"),
		"P:" + strings.Join(plugins, ";"),
		"T:" + touch,
		"H:" + strconv.Itoa(id.HardwareConcurrency),
		"SWF:false",
	}
}

// buildEnhancedFP assembles a representative enhanced_fp object from the identity.
func buildEnhancedFP(id *identity.BrowserIdentity, syn *behavioral.Synth) *cryptoutil.OrderedMap {
	m := cryptoutil.NewOrderedMap()
	exts := strings.Join(id.WebGLExts, ";")
	m.Set("webgl_extensions", exts)
	m.Set("webgl_extensions_hash", cryptoutil.Murmur3x64_128Hex([]byte(exts), 0))
	m.Set("webgl_renderer", id.GPUModel)
	m.Set("webgl_vendor", id.GPUVendor)
	m.Set("webgl_version", "WebGL 1.0 (OpenGL ES 2.0 Chromium)")
	m.Set("webgl_shading_language_version", "WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)")
	m.Set("webgl_aliased_line_width_range", "[1, 1]")
	m.Set("webgl_aliased_point_size_range", "[1, 1024]")
	m.Set("webgl_antialiasing", "yes")
	m.Set("webgl_bits", "8,8,24,8,8,0")
	m.Set("webgl_max_params", "16,192,16384,1024,16384,16,16384,30,16,16,4095")
	m.Set("webgl_max_viewport_dims", "[32767, 32767]")
	m.Set("webgl_unmasked_vendor", id.GPUVendor)
	m.Set("webgl_unmasked_renderer", id.GPUModel)
	m.Set("webgl_vsf_params", "23,127,127,23,127,127,23,127,127")
	m.Set("webgl_vsi_params", "0,31,30,0,31,30,0,31,30")
	m.Set("webgl_fsf_params", "23,127,127,23,127,127,23,127,127")
	m.Set("webgl_fsi_params", "0,31,30,0,31,30,0,31,30")
	blob := id.GPUVendor + "," + id.GPUModel + "," + exts
	m.Set("webgl_hash_webgl", cryptoutil.Murmur3x64_128Hex([]byte(blob), 0))

	mobile := id.DeviceType == "mobile"
	m.Set("user_agent_data_brands", brandsFromSecUA(id.SecUA))
	m.Set("user_agent_data_mobile", mobile)
	m.Set("navigator_connection_downlink", 10)
	m.Set("navigator_connection_downlink_max", nil)
	m.Set("network_info_rtt", 50+syn.Timing(1, 0, 100)[0])
	m.Set("network_info_save_data", false)
	m.Set("navigator_language", id.Locale)
	m.Set("navigator_languages", strings.Join(id.Languages, ","))
	m.Set("navigator_hardware_concurrency", id.HardwareConcurrency)
	m.Set("navigator_device_memory", id.DeviceMemory)
	m.Set("screen_color_depth", id.Screen.ColorDepth)
	m.Set("navigator_platform", id.Platform)
	m.Set("num_of_evaluations", strconv.Itoa(1+syn.Timing(1, 0, 5)[0]))
	m.Set("audio_fingerprint", id.AudioFingerprint)
	return m
}

func brandsFromSecUA(secUA string) string {
	if secUA == "" {
		return ""
	}
	return secUA
}

// encryptBDA encrypts the payload with AES-256-CBC using an OpenSSL-style
// salted EVP_BytesToKey derivation, returning base64(JSON{ct,iv,s}).
func encryptBDA(payload []byte, userAgent string, timeFrameKey int64) (string, error) {
	salt := make([]byte, 8)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}
	password := []byte(userAgent + strconv.FormatInt(timeFrameKey, 10))
	key, iv := cryptoutil.EVPBytesToKey(password, salt, 32, 16)

	block, err := aes.NewCipher(key) // AES-256
	if err != nil {
		return "", err
	}
	padded := pkcs7Pad(payload, aes.BlockSize)
	ct := make([]byte, len(padded))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(ct, padded)

	wire := struct {
		CT string `json:"ct"`
		IV string `json:"iv"`
		S  string `json:"s"`
	}{
		CT: base64.StdEncoding.EncodeToString(ct),
		IV: hex.EncodeToString(iv),
		S:  hex.EncodeToString(salt),
	}
	wireJSON, err := json.Marshal(wire)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(wireJSON), nil
}

func pkcs7Pad(data []byte, blockSize int) []byte {
	pad := blockSize - len(data)%blockSize
	out := make([]byte, len(data)+pad)
	copy(out, data)
	for i := len(data); i < len(out); i++ {
		out[i] = byte(pad)
	}
	return out
}
