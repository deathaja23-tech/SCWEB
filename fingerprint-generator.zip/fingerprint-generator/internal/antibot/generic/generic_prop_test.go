package generic

import (
	"encoding/json"
	"reflect"
	"sort"
	"testing"
	"testing/quick"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/identity"
)

var qcfg = &quick.Config{MaxCount: 200}

func genIdentity(d, b, c uint8) *identity.BrowserIdentity {
	devices := []string{"", "desktop", "mobile"}
	browsers := []string{"", "chrome", "firefox", "safari"}
	countries := []string{"", "us", "jp", "de", "in", "za"}
	return identity.RandomIdentityWithOptions(identity.GenOptions{
		Device:  devices[int(d)%len(devices)],
		Browser: browsers[int(b)%len(browsers)],
		Country: countries[int(c)%len(countries)],
	})
}

// Feature: global-fingerprint-optimization, Property 1: Generic payload completeness and purity — the marshaled payload contains exactly the identity-signal key set (the 3 Chromium-only client-hint keys present iff Chrome) and no target-specific keys.
func TestProperty1_GenericCompletenessPurity(t *testing.T) {
	base := []string{
		"chromeVersion", "userAgent", "platform", "gpuVendor", "gpuModel",
		"webglExtensions", "canvasHash", "histogram", "mathTan", "mathSin",
		"mathCos", "audioFingerprint", "plugins", "screen", "deviceMemory",
		"hardwareConcurrency", "timeZone", "languages", "locale", "fonts",
	}
	clientHints := []string{"secChUa", "secChUaPlatform", "secChUaMobile"}

	f := func(d, b, c uint8) bool {
		id := genIdentity(d, b, c)
		res, err := (Target{}).Build(&antibot.BuildContext{Identity: id})
		if err != nil {
			return false
		}
		var m map[string]json.RawMessage
		if err := json.Unmarshal(res.Raw, &m); err != nil {
			return false
		}
		want := append([]string{}, base...)
		if id.BrowserFamily == "chrome" {
			want = append(want, clientHints...)
		}
		// No target-specific keys.
		if _, ok := m["webpackHash"]; ok {
			return false
		}
		if _, ok := m["arkosePublicKey"]; ok {
			return false
		}
		got := make([]string, 0, len(m))
		for k := range m {
			got = append(got, k)
		}
		sort.Strings(got)
		sort.Strings(want)
		return reflect.DeepEqual(got, want)
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 2: Generic serialization round-trip fidelity — unmarshaling the payload yields a value deep-equal to toGenericPayload(identity), preserving int32 canvasHash, all 256 histogram bins, and all strings.
func TestProperty2_GenericRoundTrip(t *testing.T) {
	f := func(d, b, c uint8) bool {
		id := genIdentity(d, b, c)
		want := toGenericPayload(id)
		res, err := (Target{}).Build(&antibot.BuildContext{Identity: id})
		if err != nil {
			return false
		}
		var got GenericPayload
		if err := json.Unmarshal(res.Raw, &got); err != nil {
			return false
		}
		if len(got.Histogram) != 256 {
			return false
		}
		return reflect.DeepEqual(got, want)
	}
	if err := quick.Check(f, qcfg); err != nil {
		t.Fatal(err)
	}
}
