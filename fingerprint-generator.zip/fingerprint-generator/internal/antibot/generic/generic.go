// Package generic implements the universal antibot.Target ("generic"), the
// system default. It emits a single flat, self-describing JSON object mapping
// directly to the Identity signals, with NO encryption envelope and NO
// target-specific fields. Round-trip fidelity is preserved (int32 canvas hash,
// all 256 histogram bins, all strings).
package generic

import (
	"encoding/json"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/identity"
)

// Target implements antibot.Target for the generic universal payload.
type Target struct{}

func init() { antibot.Register(Target{}) }

func (Target) Name() string { return "generic" }

// Capabilities: single output, NO envelope, no required session inputs.
func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{EncryptionApplicable: false}
}

// Build marshals the identity to a flat GenericPayload. Encoded is always empty
// because the generic target defines no envelope (Requirement 1.4).
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	b, err := json.Marshal(toGenericPayload(ctx.Identity))
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{Raw: b}, nil
}

// IdentityExtras returns nil: generic contributes no extra identity fields
// (Requirement 3.5, 1.7).
func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// genScreen mirrors the nested screen object required by Requirement 1.1.
type genScreen struct {
	Width            int `json:"width"`
	Height           int `json:"height"`
	AvailWidth       int `json:"availWidth"`
	AvailHeight      int `json:"availHeight"`
	ColorDepth       int `json:"colorDepth"`
	DevicePixelRatio int `json:"devicePixelRatio"`
}

// GenericPayload is the flat, self-describing payload. The three Chromium-only
// client-hint fields are omitempty so they vanish for non-Chrome identities
// (Requirement 7.3). canvasHash is int32 for lossless round-trip (Requirement 1.3).
type GenericPayload struct {
	ChromeVersion       string              `json:"chromeVersion"`
	UserAgent           string              `json:"userAgent"`
	SecChUa             string              `json:"secChUa,omitempty"`
	SecChUaPlatform     string              `json:"secChUaPlatform,omitempty"`
	SecChUaMobile       string              `json:"secChUaMobile,omitempty"`
	Platform            string              `json:"platform"`
	GpuVendor           string              `json:"gpuVendor"`
	GpuModel            string              `json:"gpuModel"`
	WebglExtensions     []string            `json:"webglExtensions"`
	CanvasHash          int32               `json:"canvasHash"`
	Histogram           []int               `json:"histogram"`
	MathTan             string              `json:"mathTan"`
	MathSin             string              `json:"mathSin"`
	MathCos             string              `json:"mathCos"`
	AudioFingerprint    string              `json:"audioFingerprint"`
	Plugins             []map[string]string `json:"plugins"`
	Screen              genScreen           `json:"screen"`
	DeviceMemory        int                 `json:"deviceMemory"`
	HardwareConcurrency int                 `json:"hardwareConcurrency"`
	TimeZone            int                 `json:"timeZone"`
	Languages           []string            `json:"languages"`
	Locale              string              `json:"locale"`
	Fonts               []string            `json:"fonts"`
}

// toGenericPayload is a pure mapping from Identity to GenericPayload.
func toGenericPayload(id *identity.BrowserIdentity) GenericPayload {
	hist := make([]int, 256)
	copy(hist, id.HistogramBase[:])
	return GenericPayload{
		ChromeVersion:   id.ChromeVer,
		UserAgent:       id.UA,
		SecChUa:         id.SecUA,
		SecChUaPlatform: id.SecCHUAPlatform,
		SecChUaMobile:   id.SecCHUAMobile,
		Platform:        id.Platform,
		GpuVendor:       id.GPUVendor,
		GpuModel:        id.GPUModel,
		WebglExtensions: id.WebGLExts,
		CanvasHash:      id.CanvasHash,
		Histogram:       hist,
		MathTan:         id.MathTan,
		MathSin:         id.MathSin,
		MathCos:         id.MathCos,
		AudioFingerprint: id.AudioFingerprint,
		Plugins:          id.Plugins,
		Screen: genScreen{
			Width:            id.Screen.Width,
			Height:           id.Screen.Height,
			AvailWidth:       id.Screen.AvailWidth,
			AvailHeight:      id.Screen.AvailHeight,
			ColorDepth:       id.Screen.ColorDepth,
			DevicePixelRatio: id.Screen.DevicePixelRatio,
		},
		DeviceMemory:        id.DeviceMemory,
		HardwareConcurrency: id.HardwareConcurrency,
		TimeZone:            id.TimeZone,
		Languages:           id.Languages,
		Locale:              id.Locale,
		Fonts:               id.Fonts,
	}
}
