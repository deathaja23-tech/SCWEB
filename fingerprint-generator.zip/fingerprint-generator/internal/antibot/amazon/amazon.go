// Package amazon implements the antibot.Target for Amazon's "TES" fingerprint
// endpoint. It shapes a generic identity into Amazon's order-sensitive payload
// (metrics/lsUbid/dynamicUrls/…) and wraps it in the XXTEA `ECdITeCs:` envelope.
package amazon

import (
	"encoding/json"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/identity"
)

// Target implements antibot.Target for Amazon.
type Target struct{}

func init() { antibot.Register(Target{}) }

func (Target) Name() string { return "amazon" }

// Capabilities: Amazon is a single-output, enveloped target with no required
// session inputs (its session seeds are self-generated per call).
func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{EncryptionApplicable: true}
}

// Build shapes the identity into Amazon's raw payload JSON and its XXTEA
// `ECdITeCs:` envelope. Both are returned so the server honors encrypt=true|false
// without a second call. A fresh per-call FingerprintContext owns the Amazon
// session seeds (lsUbid, webpackHash). Page context is read from ctx.Page.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	fpCtx := NewFPContext(id)

	pageType := ctx.Page.PageType
	if pageType == "" {
		pageType = "default"
	}
	eventType := ctx.Page.EventType
	if eventType == "" {
		eventType = "PageLoad"
	}
	location := ctx.Page.LocationURL
	if location == "" {
		location = "https://example.com"
	}

	nowMs := ctx.ClockNow().UnixMilli()
	om := BuildFingerprintData(id, location, ctx.Page.Referrer, nowMs, fpCtx,
		pageType, eventType, ctx.Page.TimeOnPage, ctx.Page.EmailLen, ctx.Page.Email)
	raw, err := om.MarshalJSON()
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{
		Raw:     json.RawMessage(raw),
		Encoded: EncryptFingerprint(string(raw)),
	}, nil
}

// IdentityExtras surfaces Amazon's webpackHash into the emitted identity JSON
// (a consumer, kirox, reads `identity.webpackHash`). Derived from the UA so it is
// stable per identity.
func (Target) IdentityExtras(id *identity.BrowserIdentity) map[string]interface{} {
	return map[string]interface{}{"webpackHash": deriveWebpackHash(id.UA)}
}
