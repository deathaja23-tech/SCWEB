package amazon

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/big"
	mrand "math/rand"
	"time"
)

// JWEEncryptor handles JWE encryption.
type JWEEncryptor struct{}

func b64url(data []byte) string {
	return base64.RawURLEncoding.EncodeToString(data)
}

func jwkToPublicKey(jwk map[string]string) (*rsa.PublicKey, error) {
	nBytes, err := base64.RawURLEncoding.DecodeString(jwk["n"])
	if err != nil {
		return nil, fmt.Errorf("decode n: %w", err)
	}
	eBytes, err := base64.RawURLEncoding.DecodeString(jwk["e"])
	if err != nil {
		return nil, fmt.Errorf("decode e: %w", err)
	}
	n := new(big.Int).SetBytes(nBytes)
	e := new(big.Int).SetBytes(eBytes)
	return &rsa.PublicKey{N: n, E: int(e.Int64())}, nil
}

// Encrypt encrypts a password with RSA-OAEP-256 + AES-256-GCM.
func (j *JWEEncryptor) Encrypt(
	password string,
	publicKey map[string]string,
	issuer, audience, region string,
) (string, error) {
	header := map[string]string{
		"alg": "RSA-OAEP-256",
		"kid": publicKey["kid"],
		"enc": "A256GCM",
		"cty": "enc",
		"typ": "application/aws+signin+jwe",
	}
	headerJSON, _ := json.Marshal(header)
	headerB64 := b64url(headerJSON)

	cek := make([]byte, 32)
	if _, err := rand.Read(cek); err != nil {
		return "", err
	}

	pubKey, err := jwkToPublicKey(publicKey)
	if err != nil {
		return "", err
	}
	encryptedCEK, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, pubKey, cek, nil)
	if err != nil {
		return "", err
	}

	now := time.Now().Unix()
	claims := map[string]interface{}{
		"iss":      fmt.Sprintf("%s.%s", region, issuer),
		"iat":      now,
		"nbf":      now,
		"jti":      genUUID(),
		"exp":      now + 300,
		"aud":      fmt.Sprintf("%s.%s", region, audience),
		"password": password,
	}
	plaintext, _ := json.Marshal(claims)

	iv := make([]byte, 12)
	if _, err := rand.Read(iv); err != nil {
		return "", err
	}

	block, err := aes.NewCipher(cek)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nil, iv, plaintext, []byte(headerB64))

	ct := ciphertext[:len(ciphertext)-16]
	tag := ciphertext[len(ciphertext)-16:]

	return fmt.Sprintf("%s.%s.%s.%s.%s",
		headerB64,
		b64url(encryptedCEK),
		b64url(iv),
		b64url(ct),
		b64url(tag),
	), nil
}

func genUUID() string {
	b := make([]byte, 16)
	for i := range b {
		b[i] = byte(mrand.Intn(256))
	}
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}
