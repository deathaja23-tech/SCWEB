package amazon

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"math/rand"
	"time"

	"fingerprint-generator/internal/identity"
)

// lsUbid prefix pool — Amazon-specific lsUbid cookie seeds (moved out of the
// generic identity core).
var lsubidPrefixes = []string{"X10", "X19", "X42", "X55", "X73", "X81", "X96"}

func randLsubidPrefix() string {
	return lsubidPrefixes[rand.Intn(len(lsubidPrefixes))]
}

// deriveWebpackHash derives Amazon's /dist/main/app_<hash>.min.js seed from the UA.
func deriveWebpackHash(ua string) string {
	h := sha256.Sum256([]byte(ua))
	hexed := hex.EncodeToString(h[:])
	return hexed[rand.Intn(20):][:10]
}

// FingerprintContext maintains session-level Amazon fingerprint state.
type FingerprintContext struct {
	Identity      *identity.BrowserIdentity
	CanvasHash    int32
	HistogramBins [256]int
	LsUbidSignin  string
	LsUbidProfile string
	WebpackHash   string // Amazon seed; also surfaced in the identity JSON view
	prefixProfile string
	perfTiming    map[string]int64
	startTime     *int64
}

// NewFPContext creates an Amazon fingerprint context from a generic identity.
func NewFPContext(id *identity.BrowserIdentity) *FingerprintContext {
	ts := time.Now().Unix()
	return &FingerprintContext{
		Identity:      id,
		CanvasHash:    id.CanvasHash,
		HistogramBins: id.HistogramBase,
		WebpackHash:   deriveWebpackHash(id.UA),
		prefixProfile: randLsubidPrefix(),
		LsUbidSignin: fmt.Sprintf("%s-%07d-%07d:%d",
			randLsubidPrefix(), rand.Intn(10000000), rand.Intn(10000000), ts),
	}
}

// GetLsUbid returns the lsUbid for the given page type.
func (c *FingerprintContext) GetLsUbid(pageType string) string {
	if pageType == "profile" {
		if c.LsUbidProfile == "" {
			var ts int64
			if c.perfTiming != nil {
				ts = c.perfTiming["loadEventEnd"] / 1000
			} else {
				ts = time.Now().Unix()
			}
			c.LsUbidProfile = fmt.Sprintf("%s-%07d-%07d:%d",
				c.prefixProfile, rand.Intn(10000000), rand.Intn(10000000), ts)
		}
		return c.LsUbidProfile
	}
	return c.LsUbidSignin
}

// GetPerfTiming returns cached performance.timing, generating on first call.
func (c *FingerprintContext) GetPerfTiming(nowMs int64) map[string]int64 {
	if c.perfTiming == nil {
		c.perfTiming = GenPerfTiming(nowMs)
	}
	return c.perfTiming
}

// GetStartTime returns the page start timestamp, caching on first call.
func (c *FingerprintContext) GetStartTime(nowMs int64) int64 {
	if c.startTime == nil {
		t := nowMs
		c.startTime = &t
	}
	return *c.startTime
}

// ResetPerfTiming resets timing when navigating to a new page.
func (c *FingerprintContext) ResetPerfTiming() {
	c.perfTiming = nil
}

// GenerateFingerprintJSON generates a fingerprint JSON string (unencrypted).
func GenerateFingerprintJSON(
	id *identity.BrowserIdentity,
	locationURL, referrer string,
	ctx *FingerprintContext,
	pageType, eventType string,
	timeOnPage, emailLen int,
	email string,
) string {
	nowMs := time.Now().UnixMilli()
	fpData := BuildFingerprintData(id, locationURL, referrer, nowMs, ctx,
		pageType, eventType, timeOnPage, emailLen, email)
	return MarshalOrdered(fpData)
}
