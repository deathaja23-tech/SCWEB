package amazon

import (
	"encoding/base64"
	"fmt"
	"hash/crc32"
	"strings"
)

const (
	delta      uint32 = 0x9E3779B9
	fallbackVer       = "4.0.0"
	identifier        = "ECdITeCs"
)

var fallbackKey = [4]uint32{1888420705, 2576816180, 2347232058, 874813317}

// ActiveKey is the encryption key. Defaults to fallback; can be overridden.
var ActiveKey = fallbackKey

// Version is the TES version string. Defaults to fallback; can be overridden.
var Version = fallbackVer

// Identifier is the encrypted payload prefix.
var Identifier = identifier

// GetTESVersion returns the current TES version string.
func GetTESVersion() string {
	return Version
}

// GetIdentifier returns the current encrypted payload identifier prefix.
func GetIdentifier() string {
	return Identifier
}

// GetActiveKey returns the current XXTEA encryption key.
func GetActiveKey() [4]uint32 {
	return ActiveKey
}

// EncryptFingerprint encrypts a fingerprint JSON string with XXTEA.
func EncryptFingerprint(jsonStr string) string {
	crc := crc32.ChecksumIEEE([]byte(jsonStr))
	plaintext := fmt.Sprintf("%08X#%s", crc, jsonStr)
	encrypted := xxteaEncrypt(plaintext, GetActiveKey())
	encoded := base64.StdEncoding.EncodeToString(encrypted)
	return GetIdentifier() + ":" + encoded
}

func xxteaEncrypt(plaintext string, key [4]uint32) []byte {
	if len(plaintext) == 0 {
		return nil
	}
	n := (len(plaintext) + 3) / 4
	v := make([]uint32, n)
	for i := 0; i < n; i++ {
		var b0, b1, b2, b3 byte
		if 4*i < len(plaintext) {
			b0 = plaintext[4*i]
		}
		if 4*i+1 < len(plaintext) {
			b1 = plaintext[4*i+1]
		}
		if 4*i+2 < len(plaintext) {
			b2 = plaintext[4*i+2]
		}
		if 4*i+3 < len(plaintext) {
			b3 = plaintext[4*i+3]
		}
		v[i] = uint32(b0) | uint32(b1)<<8 | uint32(b2)<<16 | uint32(b3)<<24
	}
	rounds := 6 + 52/n
	z := v[n-1]
	var total uint32
	for r := 0; r < rounds; r++ {
		total += delta
		e := (total >> 2) & 3
		for p := 0; p < n; p++ {
			y := v[(p+1)%n]
			mx := ((z>>5 ^ y<<2) + (y>>3 ^ z<<4)) ^ ((total ^ y) + (key[(uint32(p)&3)^e] ^ z))
			v[p] += mx
			z = v[p]
		}
	}
	result := make([]byte, n*4)
	for i, val := range v {
		result[4*i] = byte(val)
		result[4*i+1] = byte(val >> 8)
		result[4*i+2] = byte(val >> 16)
		result[4*i+3] = byte(val >> 24)
	}
	return result
}

// DecryptFingerprint decrypts an XXTEA-encrypted fingerprint string.
func DecryptFingerprint(encrypted string) (string, error) {
	parts := strings.SplitN(encrypted, ":", 2)
	if len(parts) != 2 {
		return "", fmt.Errorf("invalid format")
	}
	data, err := base64.StdEncoding.DecodeString(parts[1])
	if err != nil {
		return "", err
	}
	raw := xxteaDecrypt(data, GetActiveKey())
	if idx := strings.Index(raw[:min(16, len(raw))], "#"); idx >= 0 {
		return raw[idx+1:], nil
	}
	return raw, nil
}

func xxteaDecrypt(data []byte, key [4]uint32) string {
	n := len(data) / 4
	if n < 2 {
		return ""
	}
	v := make([]uint32, n)
	for i := 0; i < n; i++ {
		v[i] = uint32(data[4*i]) | uint32(data[4*i+1])<<8 |
			uint32(data[4*i+2])<<16 | uint32(data[4*i+3])<<24
	}
	rounds := 6 + 52/n
	total := uint32(rounds) * delta
	y := v[0]
	for r := 0; r < rounds; r++ {
		e := (total >> 2) & 3
		for p := n - 1; p >= 0; p-- {
			z := v[(p-1+n)%n]
			mx := ((z>>5 ^ y<<2) + (y>>3 ^ z<<4)) ^ ((total ^ y) + (key[(uint32(p)&3)^e] ^ z))
			v[p] -= mx
			y = v[p]
		}
		total -= delta
	}
	var sb strings.Builder
	for _, val := range v {
		sb.WriteByte(byte(val))
		sb.WriteByte(byte(val >> 8))
		sb.WriteByte(byte(val >> 16))
		sb.WriteByte(byte(val >> 24))
	}
	return strings.TrimRight(sb.String(), "\x00")
}
