// Package x implements the antibot.Target for X/Twitter's three anti-bot systems
// (anti-bot-fingerprint-reference.md §2, anti-bot-crypto-constants.md §2):
//   - xpff   : X-Xp-Forwarded-For header — AES-256-GCM, key = SHA-256(base_key||guest_id)
//   - txid   : X-Client-Transaction-Id — byte assembly + random-salt XOR + base64
//   - arkose : Arkose FunCaptcha BDA (shared builder), per-session sitekey
//
// Tier A: all algorithm constants stable. Stateless — no ondemand.s fetch, no PoW.
package x

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/arkose"
	"fingerprint-generator/internal/identity"
)

// Stable constants (anti-bot-crypto-constants.md §2).
const (
	xpffBaseKeyHex = "0e6be1f1e21ffc33590b888fd4dc81b19713e570e805d4e5df80a493c9571a05"
	txidEpochMs    = int64(1682924400000)
	txidHashSalt   = "obfiowerehiring"
	txidTerminator = 0x03
)

// Target implements antibot.Target for X.
type Target struct{}

func init() { antibot.Register(Target{}) }

func (Target) Name() string { return "x" }

func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{
		Variants:             []string{"xpff", "txid", "arkose"},
		DefaultVariant:       "xpff",
		EncryptionApplicable: true,
		RequiredInputs: map[string][]string{
			"xpff":   {"guest_id"},
			"txid":   {"method", "path", "verification", "animation_key"},
			"arkose": {"sitekey"},
		},
	}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build dispatches on the selected variant.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	variant := ctx.Variant
	if variant == "" {
		variant = "xpff"
	}
	switch variant {
	case "xpff":
		return buildXPFF(ctx)
	case "txid":
		return buildTxID(ctx)
	case "arkose":
		raw, encoded, err := arkose.BuildBDA(ctx.Identity, ctx.ClockNow())
		if err != nil {
			return nil, err
		}
		return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
	default:
		return nil, fmt.Errorf("x: unknown variant %q", variant)
	}
}

// DeriveXPFFKey computes the AES-256 key = SHA-256(base_key_hex_string || guest_id).
// The base key is the 64-char hex string as embedded in the WASM binary.
func DeriveXPFFKey(guestID string) [32]byte {
	return sha256.Sum256([]byte(xpffBaseKeyHex + guestID))
}

func buildXPFF(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	guestID := ctx.SessionInputs.Get("guest_id")
	payload := struct {
		NavigatorProperties struct {
			HasBeenActive string `json:"hasBeenActive"`
			UserAgent     string `json:"userAgent"`
			Webdriver     string `json:"webdriver"`
		} `json:"navigator_properties"`
		CreatedAt int64 `json:"created_at"`
	}{}
	payload.NavigatorProperties.HasBeenActive = "true"
	payload.NavigatorProperties.UserAgent = ctx.Identity.UA
	payload.NavigatorProperties.Webdriver = "false"
	payload.CreatedAt = ctx.ClockNow().UnixMilli()

	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}

	key := DeriveXPFFKey(guestID)
	block, err := aes.NewCipher(key[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block) // 12-byte nonce, 16-byte tag
	if err != nil {
		return nil, err
	}
	iv := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(iv); err != nil {
		return nil, err
	}
	ctAndTag := gcm.Seal(nil, iv, raw, nil) // ciphertext || tag
	out := append(append([]byte{}, iv...), ctAndTag...)
	return &antibot.BuildResult{Raw: raw, Encoded: hex.EncodeToString(out)}, nil
}

func buildTxID(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	method := ctx.SessionInputs.Get("method")
	path := ctx.SessionInputs.Get("path")
	verification := ctx.SessionInputs.Get("verification")
	animationKey := ctx.SessionInputs.Get("animation_key")

	keyBytes, err := base64.StdEncoding.DecodeString(verification)
	if err != nil {
		return nil, fmt.Errorf("x/txid: verification is not valid base64: %w", err)
	}

	timeNow := (ctx.ClockNow().UnixMilli() - txidEpochMs) / 1000
	hashInput := fmt.Sprintf("%s!%s!%d%s%s", method, path, timeNow, txidHashSalt, animationKey)
	sum := sha256.Sum256([]byte(hashInput))

	timeBytes := []byte{
		byte(timeNow), byte(timeNow >> 8), byte(timeNow >> 16), byte(timeNow >> 24),
	}
	payload := make([]byte, 0, len(keyBytes)+4+16+1)
	payload = append(payload, keyBytes...)
	payload = append(payload, timeBytes...)
	payload = append(payload, sum[:16]...)
	payload = append(payload, txidTerminator)

	saltBuf := make([]byte, 1)
	if _, err := rand.Read(saltBuf); err != nil {
		return nil, err
	}
	salt := saltBuf[0]
	out := make([]byte, 0, len(payload)+1)
	out = append(out, salt)
	for _, b := range payload {
		out = append(out, b^salt)
	}
	txid := base64.StdEncoding.WithPadding(base64.NoPadding).EncodeToString(out)

	raw, err := json.Marshal(map[string]interface{}{
		"method": method, "path": path, "timeNow": timeNow, "hashInput": hashInput,
	})
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{Raw: raw, Encoded: txid}, nil
}
