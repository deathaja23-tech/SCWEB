package x

import (
	"encoding/hex"
	"testing"
)

// Smoke: the X XPFF AES base key is exactly 32 bytes (256-bit), per
// anti-bot-crypto-constants.md §2.
func TestSmoke_XPFFBaseKeyLength(t *testing.T) {
	b, err := hex.DecodeString(xpffBaseKeyHex)
	if err != nil {
		t.Fatalf("base key not valid hex: %v", err)
	}
	if len(b) != 32 {
		t.Fatalf("XPFF base key = %d bytes, want 32", len(b))
	}
}
