package antibot_test

import (
	"encoding/json"
	"testing"

	"fingerprint-generator/internal/antibot"
	_ "fingerprint-generator/internal/antibot/amazon" // register amazon
	"fingerprint-generator/internal/identity"
)

// stub is a trivial second target proving the seam works WITHOUT any real
// reverse-engineered schema — the whole point of the multi-target refactor.
type stub struct{}

func (stub) Name() string                       { return "stub" }
func (stub) Capabilities() antibot.Capabilities { return antibot.Capabilities{EncryptionApplicable: true} }
func (stub) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	raw, err := json.Marshal(map[string]string{"hello": "world", "ua": ctx.Identity.UA})
	if err != nil {
		return nil, err
	}
	return &antibot.BuildResult{Raw: raw, Encoded: "stub:" + string(raw)}, nil
}
func (stub) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

func TestRegistry(t *testing.T) {
	if _, ok := antibot.Get("amazon"); !ok {
		t.Fatal("amazon target not registered")
	}
	if _, ok := antibot.Get("nope"); ok {
		t.Fatal("unknown target should not resolve")
	}
	if _, err := antibot.MustGet("nope"); err == nil {
		t.Fatal("MustGet(nope) should error, not panic")
	}
}

func TestAddATarget(t *testing.T) {
	antibot.Register(stub{})
	tgt, err := antibot.MustGet("stub")
	if err != nil {
		t.Fatalf("stub not resolvable after Register: %v", err)
	}
	id := identity.RandomIdentity()
	res, err := tgt.Build(&antibot.BuildContext{Identity: id})
	if err != nil {
		t.Fatalf("stub Build: %v", err)
	}
	var m map[string]string
	if json.Unmarshal(res.Raw, &m) != nil || m["hello"] != "world" {
		t.Fatalf("stub payload wrong: %s", res.Raw)
	}
	if res.Encoded[:5] != "stub:" {
		t.Fatalf("stub Encoded envelope wrong: %s", res.Encoded)
	}
}

func TestAmazonProducesOrderedPayload(t *testing.T) {
	tgt, _ := antibot.MustGet("amazon")
	id := identity.RandomIdentityWithPin(131)
	res, err := tgt.Build(&antibot.BuildContext{
		Identity: id,
		Encrypt:  true,
		Page: antibot.PageContext{
			LocationURL: "https://example.com", PageType: "default", EventType: "PageLoad",
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	// first key must be "metrics" (order is load-bearing for Amazon's CRC)
	s := string(res.Raw)
	if len(s) < 10 || s[:10] != `{"metrics"` {
		t.Fatalf("amazon payload must start with metrics (ordered); got: %.40s", s)
	}
	if len(res.Encoded) < 9 || res.Encoded[:9] != "ECdITeCs:" {
		t.Fatalf("amazon envelope must be ECdITeCs:; got %.12s", res.Encoded)
	}
	// Capabilities: enveloped, single-output.
	if !tgt.Capabilities().EncryptionApplicable {
		t.Fatal("amazon Capabilities.EncryptionApplicable must be true")
	}
	// IdentityExtras must surface a non-empty webpackHash.
	if wh, _ := tgt.IdentityExtras(id)["webpackHash"].(string); wh == "" {
		t.Fatal("amazon IdentityExtras must include a non-empty webpackHash")
	}
}
