// Package kasada is a Tier C SCAFFOLD for Kasada (anti-bot-fingerprint-reference.md
// §8, anti-bot-crypto-constants.md §8).
//
// NOT REGISTERED: while the XTEA algorithm is stable (DELTA 0x9E3779B9, 32
// rounds), the 16-byte XTEA key, per-domain seed phrase, and 428-slot layout
// rotate per-deployment and are not available. Per Requirement 8.4/8.6 this
// target is not registered (no init() Register, no blank import); requests return
// the standard 400. No proof-of-work (Requirement 9.1). The scaffold conforms to
// antibot.Target so the seam is verified.
package kasada

import (
	"encoding/base64"
	"encoding/json"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/antibot/cryptoutil"
	"fingerprint-generator/internal/identity"
)

// compile-time interface check (conforms without being registered).
var _ antibot.Target = Target{}

// Target implements antibot.Target for Kasada (scaffold, not registered).
type Target struct{}

func (Target) Name() string { return "kasada" }

func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{
		EncryptionApplicable: true,
		RequiredInputs:       map[string][]string{"": {"difficulty", "prefix"}},
	}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build produces a PLACEHOLDER probe payload and XTEA-CBC encrypts it with a
// placeholder key (the real per-deployment key/seed/layout are unknown). No PoW.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	syn := behavioral.NewFromIdentity(id)
	probes := map[string]interface{}{
		"ua":         id.UA,
		"platform":   id.Platform,
		"hc":         id.HardwareConcurrency,
		"dm":         id.DeviceMemory,
		"canvas":     id.CanvasHash,
		"difficulty": ctx.SessionInputs.Get("difficulty"),
		"prefix":     ctx.SessionInputs.Get("prefix"),
		"timing":     syn.Timing(5, 1, 100),
		"note":       "scaffold: XTEA key + 428-slot layout rotate per-deployment; no PoW",
	}
	raw, err := json.Marshal(probes)
	if err != nil {
		return nil, err
	}

	// Placeholder XTEA-CBC (16-byte placeholder key + zero IV). Structural only.
	key := cryptoutil.KeyFromBytes([]byte("kasadaplaceholde"))
	var iv [8]byte
	ct := cryptoutil.XTEAEncryptCBC(raw, key, iv)
	return &antibot.BuildResult{Raw: raw, Encoded: base64.StdEncoding.EncodeToString(ct)}, nil
}
