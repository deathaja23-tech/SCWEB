package cryptoutil

import "crypto/md5"

// EVPBytesToKey implements OpenSSL's EVP_BytesToKey with MD5 and iteration
// count 1 — the derivation used by Arkose BDA (anti-bot-crypto-constants.md §3):
//
//	D_0 = ""; D_i = MD5(D_{i-1} || password || salt); key||iv = D_1 || D_2 || ...
//
// This is equivalent to the documented 4-round MD5 chain when the password is
// (user_agent + timeFrameKey) and salt is the fixed salt, producing a 32-byte
// key (+ optional 16-byte IV) for AES-256-CBC.
func EVPBytesToKey(password, salt []byte, keyLen, ivLen int) (key, iv []byte) {
	var d []byte
	var prev []byte
	for len(d) < keyLen+ivLen {
		h := md5.New()
		h.Write(prev)
		h.Write(password)
		h.Write(salt)
		prev = h.Sum(nil)
		d = append(d, prev...)
	}
	key = make([]byte, keyLen)
	copy(key, d[:keyLen])
	if ivLen > 0 {
		iv = make([]byte, ivLen)
		copy(iv, d[keyLen:keyLen+ivLen])
	}
	return key, iv
}
