package cryptoutil

import "encoding/binary"

// XTEA (standard) — 64-bit block, 32 rounds, DELTA 0x9E3779B9. Distinct from
// Amazon's XXTEA. Used by Kasada (anti-bot-crypto-constants.md §8). The XTEA key
// (16 bytes) and CBC seed are per-deployment/rotating, so they are supplied by
// the caller; here we implement only the stable algorithm.

// xteaDelta is a var (not const) so xteaDelta*xteaRounds computes with uint32
// wraparound at runtime rather than triggering a compile-time overflow check.
var xteaDelta uint32 = 0x9E3779B9

const xteaRounds = 32

// XTEAEncryptBlock encrypts one 64-bit block (v0,v1) with a 4-word key.
func XTEAEncryptBlock(v0, v1 uint32, key [4]uint32) (uint32, uint32) {
	var sum uint32
	for i := 0; i < xteaRounds; i++ {
		v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum&3])
		sum += xteaDelta
		v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11)&3])
	}
	return v0, v1
}

// XTEADecryptBlock reverses XTEAEncryptBlock.
func XTEADecryptBlock(v0, v1 uint32, key [4]uint32) (uint32, uint32) {
	sum := xteaDelta * xteaRounds
	for i := 0; i < xteaRounds; i++ {
		v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11)&3])
		sum -= xteaDelta
		v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum&3])
	}
	return v0, v1
}

// pkcs7Pad pads data to a multiple of blockSize (PKCS#7).
func pkcs7Pad(data []byte, blockSize int) []byte {
	pad := blockSize - len(data)%blockSize
	out := make([]byte, len(data)+pad)
	copy(out, data)
	for i := len(data); i < len(out); i++ {
		out[i] = byte(pad)
	}
	return out
}

// pkcs7Unpad removes PKCS#7 padding.
func pkcs7Unpad(data []byte) []byte {
	if len(data) == 0 {
		return data
	}
	pad := int(data[len(data)-1])
	if pad <= 0 || pad > len(data) {
		return data
	}
	return data[:len(data)-pad]
}

// XTEAEncryptCBC encrypts data with XTEA in CBC mode (big-endian words, PKCS#7),
// using an 8-byte IV. Blocks are chained by XOR with the previous ciphertext.
func XTEAEncryptCBC(data []byte, key [4]uint32, iv [8]byte) []byte {
	padded := pkcs7Pad(data, 8)
	out := make([]byte, len(padded))
	prev := iv
	for off := 0; off < len(padded); off += 8 {
		var blk [8]byte
		copy(blk[:], padded[off:off+8])
		for i := 0; i < 8; i++ {
			blk[i] ^= prev[i]
		}
		v0 := binary.BigEndian.Uint32(blk[0:4])
		v1 := binary.BigEndian.Uint32(blk[4:8])
		e0, e1 := XTEAEncryptBlock(v0, v1, key)
		binary.BigEndian.PutUint32(out[off:off+4], e0)
		binary.BigEndian.PutUint32(out[off+4:off+8], e1)
		copy(prev[:], out[off:off+8])
	}
	return out
}

// XTEADecryptCBC reverses XTEAEncryptCBC (returns unpadded plaintext).
func XTEADecryptCBC(data []byte, key [4]uint32, iv [8]byte) []byte {
	if len(data)%8 != 0 {
		return nil
	}
	out := make([]byte, len(data))
	prev := iv
	for off := 0; off < len(data); off += 8 {
		v0 := binary.BigEndian.Uint32(data[off : off+4])
		v1 := binary.BigEndian.Uint32(data[off+4 : off+8])
		d0, d1 := XTEADecryptBlock(v0, v1, key)
		var blk [8]byte
		binary.BigEndian.PutUint32(blk[0:4], d0)
		binary.BigEndian.PutUint32(blk[4:8], d1)
		for i := 0; i < 8; i++ {
			blk[i] ^= prev[i]
		}
		copy(out[off:off+8], blk[:])
		copy(prev[:], data[off:off+8])
	}
	return pkcs7Unpad(out)
}

// KeyFromBytes converts a 16-byte key into the 4-word XTEA key (big-endian).
func KeyFromBytes(b []byte) [4]uint32 {
	var k [4]uint32
	for i := 0; i < 4 && (i*4+4) <= len(b); i++ {
		k[i] = binary.BigEndian.Uint32(b[i*4 : i*4+4])
	}
	return k
}
