package cryptoutil

import (
	"bytes"
	"crypto/md5"
	"encoding/json"
	"testing"
)

func TestOrderedMapPreservesOrder(t *testing.T) {
	om := NewOrderedMap()
	om.Set("metrics", 1)
	om.Set("start", 2)
	om.Set("z", 3)
	b, err := om.MarshalJSON()
	if err != nil {
		t.Fatal(err)
	}
	if got := string(b); got != `{"metrics":1,"start":2,"z":3}` {
		t.Fatalf("order not preserved: %s", got)
	}
	// Overwriting an existing key must not change its position.
	om.Set("metrics", 9)
	b, _ = om.MarshalJSON()
	if got := string(b); got != `{"metrics":9,"start":2,"z":3}` {
		t.Fatalf("overwrite changed order: %s", got)
	}
}

func TestXTEABlockRoundTrip(t *testing.T) {
	key := [4]uint32{0x01234567, 0x89abcdef, 0xfedcba98, 0x76543210}
	v0, v1 := uint32(0xdeadbeef), uint32(0x0badf00d)
	e0, e1 := XTEAEncryptBlock(v0, v1, key)
	d0, d1 := XTEADecryptBlock(e0, e1, key)
	if d0 != v0 || d1 != v1 {
		t.Fatalf("XTEA block round-trip failed: got (%08x,%08x) want (%08x,%08x)", d0, d1, v0, v1)
	}
}

func TestXTEACBCRoundTrip(t *testing.T) {
	key := KeyFromBytes([]byte("0123456789abcdef"))
	iv := [8]byte{1, 2, 3, 4, 5, 6, 7, 8}
	plain := []byte("kasada probe payload of arbitrary length!!")
	ct := XTEAEncryptCBC(plain, key, iv)
	if len(ct)%8 != 0 {
		t.Fatalf("ciphertext not block-aligned: %d", len(ct))
	}
	got := XTEADecryptCBC(ct, key, iv)
	if !bytes.Equal(got, plain) {
		t.Fatalf("XTEA-CBC round-trip failed: got %q want %q", got, plain)
	}
}

func TestMurmur3Deterministic(t *testing.T) {
	a := Murmur3x64_128Hex([]byte("hello world"), 0)
	b := Murmur3x64_128Hex([]byte("hello world"), 0)
	if a != b {
		t.Fatalf("murmur3 not deterministic: %s vs %s", a, b)
	}
	if len(a) != 32 {
		t.Fatalf("murmur3 hex length = %d, want 32", len(a))
	}
	if Murmur3x64_128Hex([]byte("hello world"), 1) == a {
		t.Fatal("murmur3 seed had no effect")
	}
	if Murmur3x64_128Hex([]byte("hello worlx"), 0) == a {
		t.Fatal("murmur3 input change had no effect")
	}
}

func TestEVPBytesToKeyMatchesMD5Chain(t *testing.T) {
	password := []byte("Mozilla/5.0 ...1700000000")
	salt := []byte{0xde, 0xad, 0xbe, 0xef, 0x00, 0x11, 0x22, 0x33}
	key, iv := EVPBytesToKey(password, salt, 32, 16)
	if len(key) != 32 || len(iv) != 16 {
		t.Fatalf("key/iv lengths = %d/%d, want 32/16", len(key), len(iv))
	}
	// Reference 4-round MD5 chain: D_i = MD5(D_{i-1} || password || salt).
	var d []byte
	var prev []byte
	for i := 0; i < 4; i++ {
		h := md5.New()
		h.Write(prev)
		h.Write(password)
		h.Write(salt)
		prev = h.Sum(nil)
		d = append(d, prev...)
	}
	if !bytes.Equal(key, d[:32]) {
		t.Fatal("EVPBytesToKey key != documented MD5 chain")
	}
	if !bytes.Equal(iv, d[32:48]) {
		t.Fatal("EVPBytesToKey iv != documented MD5 chain")
	}
}

func TestDataDomeBase64RoundTrip(t *testing.T) {
	for _, s := range [][]byte{[]byte(""), []byte("a"), []byte("ab"), []byte("abc"), []byte("hello, DataDome"), {0, 1, 2, 253, 254, 255}} {
		enc := DataDomeBase64Encode(s)
		dec := DataDomeBase64Decode(enc)
		if !bytes.Equal(dec, s) {
			t.Fatalf("custom base64 round-trip failed for %v: enc=%q dec=%v", s, enc, dec)
		}
	}
	// Alphabet must not contain '=' padding.
	if bytes.ContainsRune([]byte(DataDomeBase64Encode([]byte("abc"))), '=') {
		t.Fatal("DataDome base64 must not use '=' padding")
	}
}

func TestDjb2AndXorshiftDeterministic(t *testing.T) {
	if Djb2("abc") != Djb2("abc") {
		t.Fatal("Djb2 not deterministic")
	}
	if Djb2("abc") == Djb2("abd") {
		t.Fatal("Djb2 collision on trivially different input")
	}
	if Xorshift32(12345) != Xorshift32(12345) {
		t.Fatal("Xorshift32 not deterministic")
	}
	if Xorshift32(12345) == 12345 {
		t.Fatal("Xorshift32 identity (no mixing)")
	}
}

func TestLZStringRoundTrip(t *testing.T) {
	cases := []string{
		"",
		"a",
		"hello hello hello world",
		`{"t":123,"lhr":"about:blank","api":false,"c":false,"payload":{"k":"v","n":42}}`,
		"日本語とEmoji😀テスト",
	}
	for _, s := range cases {
		enc := CompressToBase64(s, "")
		if len(enc)%4 != 0 {
			t.Fatalf("base64 not padded to 4 for %q: len=%d", s, len(enc))
		}
		got := DecompressFromBase64(enc, "")
		if got != s {
			t.Fatalf("LZString round-trip failed:\n  in : %q\n  out: %q", s, got)
		}
	}
}

func TestLZStringCustomAlphabetRoundTrip(t *testing.T) {
	// A rotated 65-char alphabet (last char is the padding char).
	alphabet := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_="
	s := `{"payload":{"a":1,"b":"cloudflare jsd oneshot"}}`
	enc := CompressToBase64(s, alphabet)
	got := DecompressFromBase64(enc, alphabet)
	if got != s {
		t.Fatalf("LZString custom-alphabet round-trip failed:\n  in : %q\n  out: %q", s, got)
	}
}

// sanity: OrderedMap value marshaling matches encoding/json for scalar values.
func TestOrderedMapValueEncoding(t *testing.T) {
	om := NewOrderedMap()
	om.Set("s", "x\"y")
	om.Set("arr", []int{1, 2, 3})
	b, _ := om.MarshalJSON()
	var round map[string]json.RawMessage
	if err := json.Unmarshal(b, &round); err != nil {
		t.Fatalf("OrderedMap output not valid JSON: %v (%s)", err, b)
	}
}
