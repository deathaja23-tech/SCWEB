package cryptoutil

import (
	"os"
	"path/filepath"
	"testing"
)

// Golden vector captured from a real tags.js v5.8.0 POST on leboncoin.fr and
// verified by known-plaintext attack. Re-encoding the decoded plaintext with
// the recovered session params must reproduce the original jspl ciphertext
// byte-for-byte. This is the honesty gate: if the crypto model drifts, this
// fails. Fixtures live in re-artifacts/datadome/.
//
//	ddk      = 05B30BD9055986BD2EE8F5A199D973
//	mainSeed = 0x7d8479f9 ^ djb2(ddk) = 0x6079e545
//	cidSeed  = 1809053797 ^ djb2(cid)
//	u        = 0
const goldenMainBuildConst = uint32(0x7d8479f9)
const goldenCIDBuildConst = uint32(1809053797)
const goldenU = uint32(0)

func fixture(t *testing.T, name string) string {
	t.Helper()
	// walk up to the repo root (where re-artifacts/ lives).
	dir, _ := os.Getwd()
	for i := 0; i < 6; i++ {
		p := filepath.Join(dir, "re-artifacts", "datadome", name)
		if b, err := os.ReadFile(p); err == nil {
			return string(b)
		}
		dir = filepath.Dir(dir)
	}
	t.Skipf("golden fixture %s not found (re-artifacts/datadome/) — skipping", name)
	return ""
}

func TestDataDomeGoldenRoundTrip(t *testing.T) {
	ddk := fixture(t, "golden_ddk.txt")
	cid := fixture(t, "golden_cid.txt")
	plain := fixture(t, "golden_plaintext.txt")
	wantB64 := fixture(t, "golden_jspl.txt")
	if ddk == "" || plain == "" || wantB64 == "" {
		return // skipped
	}
	mainSeed := goldenMainBuildConst ^ Djb2u(ddk)
	cidSeed := goldenCIDBuildConst ^ Djb2u(cid)

	got := DataDomeEncodeRaw([]byte(plain), mainSeed, cidSeed, goldenU)
	if got != wantB64 {
		// find first divergent char to aid debugging
		n := len(got)
		if len(wantB64) < n {
			n = len(wantB64)
		}
		div := -1
		for i := 0; i < n; i++ {
			if got[i] != wantB64[i] {
				div = i
				break
			}
		}
		t.Fatalf("re-encode != captured jspl (len got=%d want=%d, first diff @ %d)",
			len(got), len(wantB64), div)
	}
}

func TestDataDomeXorshiftSigned(t *testing.T) {
	// The signed-int32 arithmetic shift (>> 17) is the crux of the fix; a
	// logical shift would produce a different value for high-bit-set inputs.
	var in uint32 = 0x80000000
	got := Xorshift32(in)
	n := int32(in)
	n = n ^ (n << 13)
	n = n ^ (n >> 17)
	n = n ^ (n << 5)
	if got != uint32(n) {
		t.Fatalf("Xorshift32(0x80000000) = 0x%08x, want 0x%08x", got, uint32(n))
	}
}

func TestDataDomePRNGExtractionOrder(t *testing.T) {
	// First three bytes (before any mix, salt off) = state>>16,>>8,>>0.
	p := NewDataDomePRNG(0x11223344, 0, false)
	for i, want := range []byte{0x22, 0x33, 0x44} {
		if b := p.Next(); b != want {
			t.Fatalf("byte%d = 0x%02x, want 0x%02x", i, b, want)
		}
	}
}
