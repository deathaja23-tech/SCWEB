package cryptoutil

import "unicode/utf16"

// LZ-string (pieroxy) compressToBase64 / decompressFromBase64, ported faithfully
// and operating on UTF-16 code units. The alphabet is configurable because
// Cloudflare JSD rotates its 64-char alphabet per-script
// (anti-bot-crypto-constants.md §6); the default is the standard LZ-string
// base64 keyset. compress/decompress round-trip each other.

const lzStdBase64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="

// LZStringAlphabet returns a validated 65-char (64 + '=') alphabet, defaulting to
// the standard LZ-string base64 keyset when alphabet is empty.
func lzAlphabet(alphabet string) string {
	if alphabet == "" {
		return lzStdBase64
	}
	return alphabet
}

func lzReverse(alphabet string) map[byte]int {
	m := make(map[byte]int, len(alphabet))
	for i := 0; i < len(alphabet); i++ {
		m[alphabet[i]] = i
	}
	return m
}

func u16key(u []uint16) string {
	b := make([]byte, len(u)*2)
	for i, v := range u {
		b[i*2] = byte(v >> 8)
		b[i*2+1] = byte(v)
	}
	return string(b)
}

// CompressToBase64 compresses s (UTF-16) to base64 using the given alphabet.
func CompressToBase64(s, alphabet string) string {
	ab := lzAlphabet(alphabet)
	res := lzCompress(utf16.Encode([]rune(s)), 6, func(i int) byte { return ab[i] })
	// pad to a multiple of 4 with the alphabet's padding char ('=' by default).
	pad := ab[64%len(ab)]
	if len(ab) > 64 {
		pad = ab[64]
	}
	for len(res)%4 != 0 {
		res = append(res, pad)
	}
	return string(res)
}

// DecompressFromBase64 reverses CompressToBase64.
func DecompressFromBase64(s, alphabet string) string {
	ab := lzAlphabet(alphabet)
	rev := lzReverse(ab)
	units := lzDecompress(len(s), 32, func(index int) int {
		return rev[s[index]]
	})
	return string(utf16.Decode(units))
}

func lzCompress(uncompressed []uint16, bitsPerChar int, getChar func(int) byte) []byte {
	dictionary := map[string]int{}
	dictionaryToCreate := map[string]bool{}
	var w []uint16
	enlargeIn := 2
	dictSize := 3
	numBits := 2
	var data []byte
	dataVal := 0
	dataPos := 0

	push := func() {
		data = append(data, getChar(dataVal))
		dataVal = 0
	}
	writeBits := func(value, n int) {
		for i := 0; i < n; i++ {
			dataVal = (dataVal << 1) | (value & 1)
			if dataPos == bitsPerChar-1 {
				dataPos = 0
				push()
			} else {
				dataPos++
			}
			value >>= 1
		}
	}
	writeZeroBits := func(n int) {
		for i := 0; i < n; i++ {
			dataVal = dataVal << 1
			if dataPos == bitsPerChar-1 {
				dataPos = 0
				push()
			} else {
				dataPos++
			}
		}
	}

	emitW := func() {
		wk := u16key(w)
		if dictionaryToCreate[wk] {
			if w[0] < 256 {
				writeZeroBits(numBits)
				writeBits(int(w[0]), 8)
			} else {
				// value=1 across numBits, then 16-bit char
				value := 1
				for i := 0; i < numBits; i++ {
					dataVal = (dataVal << 1) | value
					if dataPos == bitsPerChar-1 {
						dataPos = 0
						push()
					} else {
						dataPos++
					}
					value = 0
				}
				writeBits(int(w[0]), 16)
			}
			enlargeIn--
			if enlargeIn == 0 {
				enlargeIn = 1 << numBits
				numBits++
			}
			delete(dictionaryToCreate, wk)
		} else {
			writeBits(dictionary[wk], numBits)
		}
		enlargeIn--
		if enlargeIn == 0 {
			enlargeIn = 1 << numBits
			numBits++
		}
	}

	for _, cUnit := range uncompressed {
		c := []uint16{cUnit}
		ck := u16key(c)
		if _, ok := dictionary[ck]; !ok {
			dictionary[ck] = dictSize
			dictSize++
			dictionaryToCreate[ck] = true
		}
		wc := append(append([]uint16{}, w...), cUnit)
		wck := u16key(wc)
		if _, ok := dictionary[wck]; ok {
			w = wc
		} else {
			emitW()
			dictionary[wck] = dictSize
			dictSize++
			w = c
		}
	}

	if len(w) != 0 {
		emitW()
	}

	// Mark end of stream (value 2).
	writeBits(2, numBits)

	// Flush.
	for {
		dataVal = dataVal << 1
		if dataPos == bitsPerChar-1 {
			data = append(data, getChar(dataVal))
			break
		}
		dataPos++
	}
	return data
}

func lzDecompress(length, resetValue int, getNextValue func(int) int) []uint16 {
	dictionary := map[int][]uint16{}
	enlargeIn := 4
	dictSize := 4
	numBits := 3
	var result []uint16

	dVal := getNextValue(0)
	dPos := resetValue
	dIndex := 1

	readBits := func(maxpower int) int {
		bits := 0
		power := 1
		for power != maxpower {
			resb := dVal & dPos
			dPos >>= 1
			if dPos == 0 {
				dPos = resetValue
				dVal = getNextValue(dIndex)
				dIndex++
			}
			if resb > 0 {
				bits |= power
			}
			power <<= 1
		}
		return bits
	}

	for i := 0; i < 3; i++ {
		dictionary[i] = []uint16{uint16(i)}
	}

	var c []uint16
	switch readBits(1 << 2) {
	case 0:
		c = []uint16{uint16(readBits(1 << 8))}
	case 1:
		c = []uint16{uint16(readBits(1 << 16))}
	case 2:
		return nil
	}
	dictionary[3] = c
	w := c
	result = append(result, c...)

	for {
		if dIndex > length {
			return nil
		}
		cw := readBits(1 << numBits)
		var entry []uint16
		switch cw {
		case 0:
			dictionary[dictSize] = []uint16{uint16(readBits(1 << 8))}
			cw = dictSize
			dictSize++
			enlargeIn--
		case 1:
			dictionary[dictSize] = []uint16{uint16(readBits(1 << 16))}
			cw = dictSize
			dictSize++
			enlargeIn--
		case 2:
			return result
		}

		if enlargeIn == 0 {
			enlargeIn = 1 << numBits
			numBits++
		}

		if v, ok := dictionary[cw]; ok {
			entry = v
		} else if cw == dictSize {
			entry = append(append([]uint16{}, w...), w[0])
		} else {
			return nil
		}
		result = append(result, entry...)

		dictionary[dictSize] = append(append([]uint16{}, w...), entry[0])
		dictSize++
		enlargeIn--

		w = entry
		if enlargeIn == 0 {
			enlargeIn = 1 << numBits
			numBits++
		}
	}
}
