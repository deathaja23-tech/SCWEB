// Package cryptoutil provides pure-Go-stdlib cryptographic and encoding
// building blocks shared by the antibot targets: an order-preserving JSON map,
// XTEA, MurmurHash3 x64 128, OpenSSL EVP_BytesToKey, LZ-string, and the DataDome
// custom base64 / PRNG primitives. All key material and parameters are sourced
// from anti-bot-crypto-constants.md by the calling target packages. Zero external
// dependencies (Requirement 6.1).
//
// Note: Amazon's XXTEA envelope stays in internal/antibot/amazon (unchanged for
// byte-identical backward compatibility). The XTEA here is the distinct standard
// cipher used by Kasada.
package cryptoutil

import (
	"encoding/json"
	"strings"
)

// OrderedMap preserves JSON key insertion order (order is load-bearing for some
// antibot payloads, e.g. Amazon's metrics-first CRC).
type OrderedMap struct {
	keys   []string
	values map[string]interface{}
}

// NewOrderedMap creates a new ordered map.
func NewOrderedMap() *OrderedMap {
	return &OrderedMap{values: make(map[string]interface{})}
}

// Set inserts or updates a key-value pair (first insertion fixes key order).
func (o *OrderedMap) Set(key string, value interface{}) {
	if _, exists := o.values[key]; !exists {
		o.keys = append(o.keys, key)
	}
	o.values[key] = value
}

// Get returns the value for key and whether it exists.
func (o *OrderedMap) Get(key string) (interface{}, bool) {
	v, ok := o.values[key]
	return v, ok
}

// Keys returns the keys in insertion order.
func (o *OrderedMap) Keys() []string { return o.keys }

// MarshalJSON serializes to ordered JSON.
func (o *OrderedMap) MarshalJSON() ([]byte, error) {
	var sb strings.Builder
	sb.WriteByte('{')
	for i, k := range o.keys {
		if i > 0 {
			sb.WriteByte(',')
		}
		kb, _ := json.Marshal(k)
		sb.Write(kb)
		sb.WriteByte(':')
		vb, err := json.Marshal(o.values[k])
		if err != nil {
			return nil, err
		}
		sb.Write(vb)
	}
	sb.WriteByte('}')
	return []byte(sb.String()), nil
}

// MarshalOrdered serializes an OrderedMap to a compact JSON string.
func MarshalOrdered(m *OrderedMap) string {
	b, _ := m.MarshalJSON()
	return string(b)
}
