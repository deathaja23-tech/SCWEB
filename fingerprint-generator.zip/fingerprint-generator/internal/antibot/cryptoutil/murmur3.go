package cryptoutil

import (
	"encoding/binary"
	"encoding/hex"
	"math/bits"
)

// MurmurHash3 x64 128-bit (canonical, from the reference C++ implementation).
// Used by Arkose BDA for the `f`, `wh`, `ife_hash`, and `webgl_hash_webgl`
// digests (anti-bot-crypto-constants.md §3).

const (
	murmurC1 uint64 = 0x87c37b91114253d5
	murmurC2 uint64 = 0x4cf5ad432745937f
)

func fmix64(k uint64) uint64 {
	k ^= k >> 33
	k *= 0xff51afd7ed558ccd
	k ^= k >> 33
	k *= 0xc4ceb9fe1a85ec53
	k ^= k >> 33
	return k
}

// Murmur3x64_128 returns the 128-bit MurmurHash3 (x64 variant) of data as a
// (h1, h2) pair.
func Murmur3x64_128(data []byte, seed uint32) (uint64, uint64) {
	h1 := uint64(seed)
	h2 := uint64(seed)
	nblocks := len(data) / 16

	for i := 0; i < nblocks; i++ {
		k1 := binary.LittleEndian.Uint64(data[i*16 : i*16+8])
		k2 := binary.LittleEndian.Uint64(data[i*16+8 : i*16+16])

		k1 *= murmurC1
		k1 = bits.RotateLeft64(k1, 31)
		k1 *= murmurC2
		h1 ^= k1
		h1 = bits.RotateLeft64(h1, 27)
		h1 += h2
		h1 = h1*5 + 0x52dce729

		k2 *= murmurC2
		k2 = bits.RotateLeft64(k2, 33)
		k2 *= murmurC1
		h2 ^= k2
		h2 = bits.RotateLeft64(h2, 31)
		h2 += h1
		h2 = h2*5 + 0x38495ab5
	}

	tail := data[nblocks*16:]
	var k1, k2 uint64
	switch len(tail) & 15 {
	case 15:
		k2 ^= uint64(tail[14]) << 48
		fallthrough
	case 14:
		k2 ^= uint64(tail[13]) << 40
		fallthrough
	case 13:
		k2 ^= uint64(tail[12]) << 32
		fallthrough
	case 12:
		k2 ^= uint64(tail[11]) << 24
		fallthrough
	case 11:
		k2 ^= uint64(tail[10]) << 16
		fallthrough
	case 10:
		k2 ^= uint64(tail[9]) << 8
		fallthrough
	case 9:
		k2 ^= uint64(tail[8])
		k2 *= murmurC2
		k2 = bits.RotateLeft64(k2, 33)
		k2 *= murmurC1
		h2 ^= k2
		fallthrough
	case 8:
		k1 ^= uint64(tail[7]) << 56
		fallthrough
	case 7:
		k1 ^= uint64(tail[6]) << 48
		fallthrough
	case 6:
		k1 ^= uint64(tail[5]) << 40
		fallthrough
	case 5:
		k1 ^= uint64(tail[4]) << 32
		fallthrough
	case 4:
		k1 ^= uint64(tail[3]) << 24
		fallthrough
	case 3:
		k1 ^= uint64(tail[2]) << 16
		fallthrough
	case 2:
		k1 ^= uint64(tail[1]) << 8
		fallthrough
	case 1:
		k1 ^= uint64(tail[0])
		k1 *= murmurC1
		k1 = bits.RotateLeft64(k1, 31)
		k1 *= murmurC2
		h1 ^= k1
	}

	h1 ^= uint64(len(data))
	h2 ^= uint64(len(data))
	h1 += h2
	h2 += h1
	h1 = fmix64(h1)
	h2 = fmix64(h2)
	h1 += h2
	h2 += h1
	return h1, h2
}

// Murmur3x64_128Hex returns the 128-bit hash as a 32-char big-endian hex string
// (h1 high, h2 low), matching the JS x64hash128 output format.
func Murmur3x64_128Hex(data []byte, seed uint32) string {
	h1, h2 := Murmur3x64_128(data, seed)
	var out [16]byte
	binary.BigEndian.PutUint64(out[0:8], h1)
	binary.BigEndian.PutUint64(out[8:16], h2)
	return hex.EncodeToString(out[:])
}
