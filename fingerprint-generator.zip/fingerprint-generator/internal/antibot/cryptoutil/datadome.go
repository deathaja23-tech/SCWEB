package cryptoutil

// DataDome / HUMAN primitives (anti-bot-crypto-constants.md §4). The encryption
// constants are stable; the buffer SIGNAL ORDERING is rotating, so the ordered
// key/value list is supplied by the caller (the datadome/human target packages,
// which are implemented but held from registration until the layout is pinned).

// ddBase64Alphabet is DataDome's custom index→char mapping:
// 0→'-', 1→'_', 2..11→'0'-'9', 12..37→'A'-'Z', 38..63→'a'-'z'.
var ddBase64Alphabet = buildDDAlphabet()

func buildDDAlphabet() []byte {
	out := make([]byte, 0, 64)
	out = append(out, '-', '_')
	for c := byte('0'); c <= '9'; c++ {
		out = append(out, c)
	}
	for c := byte('A'); c <= 'Z'; c++ {
		out = append(out, c)
	}
	for c := byte('a'); c <= 'z'; c++ {
		out = append(out, c)
	}
	return out
}

var ddBase64Reverse = buildDDReverse()

func buildDDReverse() [256]int {
	var r [256]int
	for i := range r {
		r[i] = -1
	}
	for i, c := range ddBase64Alphabet {
		r[c] = i
	}
	return r
}

// DataDomeBase64Encode encodes bytes using DataDome's custom alphabet with
// truncated padding (no '=' characters).
func DataDomeBase64Encode(data []byte) string {
	var out []byte
	n := len(data)
	for i := 0; i < n; i += 3 {
		b0 := data[i]
		var b1, b2 byte
		rem := n - i
		if rem > 1 {
			b1 = data[i+1]
		}
		if rem > 2 {
			b2 = data[i+2]
		}
		out = append(out, ddBase64Alphabet[b0>>2])
		out = append(out, ddBase64Alphabet[((b0&0x03)<<4)|(b1>>4)])
		if rem > 1 {
			out = append(out, ddBase64Alphabet[((b1&0x0f)<<2)|(b2>>6)])
		}
		if rem > 2 {
			out = append(out, ddBase64Alphabet[b2&0x3f])
		}
	}
	return string(out)
}

// DataDomeBase64Decode reverses DataDomeBase64Encode.
func DataDomeBase64Decode(s string) []byte {
	var out []byte
	var buf [4]int
	n := 0
	for i := 0; i < len(s); i++ {
		v := ddBase64Reverse[s[i]]
		if v < 0 {
			continue
		}
		buf[n] = v
		n++
		if n == 4 {
			out = append(out, byte(buf[0]<<2|buf[1]>>4), byte(buf[1]<<4|buf[2]>>2), byte(buf[2]<<6|buf[3]))
			n = 0
		}
	}
	switch n {
	case 2:
		out = append(out, byte(buf[0]<<2|buf[1]>>4))
	case 3:
		out = append(out, byte(buf[0]<<2|buf[1]>>4), byte(buf[1]<<4|buf[2]>>2))
	}
	return out
}

// Djb2 computes DataDome's string hash: hash = (hash<<5) - hash + charCode,
// truncated to int32 each step (the "|0" in the reference), starting at 0.
func Djb2(s string) int32 {
	var hash int32
	for _, c := range s {
		hash = (hash << 5) - hash + int32(c)
	}
	return hash
}

// Djb2u returns Djb2 reinterpreted as uint32 (the seed math is done in the
// unsigned 32-bit domain: seed = const ^ uint32(djb2(s))).
func Djb2u(s string) uint32 { return uint32(Djb2(s)) }

// Xorshift32 applies DataDome's state mixer c(n)=(n=(n^=n<<13)^n>>17)^n<<5.
// CRITICAL: JavaScript `>>` is a SIGNED (arithmetic) int32 shift, not logical.
// Reproducing it with an unsigned right shift desyncs the stream after the
// first mix (verified by known-plaintext round-trip against tags.js v5.8.0).
func Xorshift32(v uint32) uint32 {
	n := int32(v)
	n = n ^ (n << 13)
	n = n ^ (n >> 17) // arithmetic shift — matches JS `>>`
	n = n ^ (n << 5)
	return uint32(n)
}

// DataDomePRNG models DataDome's N(seed,salt) byte stream, faithful to tags.js
// v5.8.0 (verified by known-plaintext round-trip):
//
//	i := -1
//	next(): ++i; if i>2 { state = c(state); i = 0 }
//	        b := (state >> (16 - 8*i)) & 0xFF
//	        if useSalt { salt = (salt-1)&0xFF; b ^= salt }
//
// The byte extraction order is >>16, >>8, >>0 (i = 0,1,2). useSalt models the
// captured `o` flag: the FIRST N() created in a build captures h=true (salt
// applied) and then flips h to false, so the SECOND N() (the CID stream)
// captures o=false and does NOT apply the salt.
type DataDomePRNG struct {
	state   uint32
	salt    uint32
	i       int
	useSalt bool
}

// NewDataDomePRNG seeds the PRNG. salt is the low byte of u; useSalt selects
// whether the decrementing salt is XORed into each output byte (true for the
// main stream, false for the CID stream).
func NewDataDomePRNG(seed, salt uint32, useSalt bool) *DataDomePRNG {
	return &DataDomePRNG{state: seed, salt: salt & 0xFF, i: -1, useSalt: useSalt}
}

// Next returns the next PRNG byte.
func (p *DataDomePRNG) Next() byte {
	p.i++
	if p.i > 2 {
		p.state = Xorshift32(p.state)
		p.i = 0
	}
	b := byte(p.state >> uint(16-8*p.i))
	if p.useSalt {
		p.salt = (p.salt - 1) & 0xFF
		b ^= byte(p.salt)
	}
	return b
}

// DataDomeEncode builds a DataDome-style buffer from an ordered key/value list,
// XORing each byte against the PRNG stream and encoding with the custom base64.
// The marker bytes ('{', ',', ':', '}') follow the builder. Each entry is
// (key, jsonValue): the key is JSON-quoted here ("key"), the value must already
// be a valid JSON token supplied by the caller (e.g. `1`, `false`, `"str"`).
//
// Pipeline (verified byte-accurate against tags.js v5.8.0 by round-trip):
//  1. buffer: for each pair emit  marker^main, "key"^main, ':'^main, value^main
//     (marker '{' for the first entry, ',' for the rest); close '}'^main.
//  2. CID layer: XOR every byte with the CID PRNG stream (salt OFF).
//  3. base64: pack 3 bytes, XOR each with a decrementing salt h (h0 = u), then
//     map through the custom alphabet.
//
// mainSeed = 0x7d8479f9 ^ djb2(ddk)   (0x7d8479f9 is the cross-session-stable
// build constant `i^t`). cidSeed = 1809053797 ^ djb2(cid). u is the per-session
// salt (low byte of f(Date.now())). Marker '}' peeks the main stream once more
// via s(true) in the source; here it simply consumes the next main byte, which
// is equivalent because the close marker is the final byte.
func DataDomeEncode(entries [][2]string, mainSeed, cidSeed, u uint32) string {
	// layer-1 plaintext buffer: {"k":v,"k":v,...}
	var buf []byte
	buf = append(buf, '{')
	for i, kv := range entries {
		if i > 0 {
			buf = append(buf, ',')
		}
		buf = append(buf, '"')
		buf = append(buf, kv[0]...)
		buf = append(buf, '"', ':')
		buf = append(buf, kv[1]...)
	}
	buf = append(buf, '}')
	return DataDomeEncodeRaw(buf, mainSeed, cidSeed, u)
}

// DataDomeEncodeRaw applies the DataDome envelope (main XOR, CID XOR, salted
// custom base64) to an already-built plaintext buffer. Byte-accurate against
// tags.js v5.8.0 — used by the golden round-trip test.
func DataDomeEncodeRaw(plaintext []byte, mainSeed, cidSeed, u uint32) string {
	main := NewDataDomePRNG(mainSeed, u, true)
	cid := NewDataDomePRNG(cidSeed, u, false)
	raw := make([]byte, len(plaintext))
	for i, b := range plaintext {
		raw[i] = b ^ main.Next() ^ cid.Next()
	}
	// layer-3: custom base64 with a decrementing --h salt (h0 = u)
	h := byte(u & 0xFF)
	for i := range raw {
		h = (h - 1) & 0xFF
		raw[i] ^= h
	}
	return DataDomeBase64Encode(raw)
}
