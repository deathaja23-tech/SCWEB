package antibot_test

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"strings"
	"testing"
	"testing/quick"

	"fingerprint-generator/internal/antibot"
	_ "fingerprint-generator/internal/antibot/amazon"
	_ "fingerprint-generator/internal/antibot/generic"
	_ "fingerprint-generator/internal/antibot/microsoft"
	"fingerprint-generator/internal/antibot/x"
	_ "fingerprint-generator/internal/antibot/xiaomi"
	"fingerprint-generator/internal/identity"
)

var pcfg = &quick.Config{MaxCount: 150}

func randID(d, b, c uint8) *identity.BrowserIdentity {
	devices := []string{"", "desktop", "mobile"}
	browsers := []string{"", "chrome", "firefox", "safari"}
	countries := []string{"", "us", "jp", "de", "in"}
	return identity.RandomIdentityWithOptions(identity.GenOptions{
		Device:  devices[int(d)%len(devices)],
		Browser: browsers[int(b)%len(browsers)],
		Country: countries[int(c)%len(countries)],
	})
}

// Feature: global-fingerprint-optimization, Property 13: Registered-target resolution — resolving any registered name returns a Target whose Name() equals the requested name.
func TestProperty13_RegisteredResolution(t *testing.T) {
	for _, name := range antibot.Names() {
		tgt, err := antibot.MustGet(name)
		if err != nil {
			t.Fatalf("MustGet(%q): %v", name, err)
		}
		if tgt.Name() != name {
			t.Fatalf("resolved target Name()=%q != %q", tgt.Name(), name)
		}
	}
}

// Feature: global-fingerprint-optimization, Property 17: Amazon backward compatibility — raw payload begins with metrics and is fixed-order; encrypted envelope begins with ECdITeCs:; IdentityExtras always includes a non-empty webpackHash.
func TestProperty17_AmazonBackwardCompat(t *testing.T) {
	tgt, err := antibot.MustGet("amazon")
	if err != nil {
		t.Fatal(err)
	}
	f := func(d, b, c uint8) bool {
		id := randID(d, b, c)
		res, err := tgt.Build(&antibot.BuildContext{Identity: id, Encrypt: true,
			Page: antibot.PageContext{LocationURL: "https://example.com", PageType: "default", EventType: "PageLoad"}})
		if err != nil {
			return false
		}
		if !strings.HasPrefix(string(res.Raw), `{"metrics"`) {
			return false
		}
		if !strings.HasPrefix(res.Encoded, "ECdITeCs:") || len(res.Encoded) <= len("ECdITeCs:") {
			return false
		}
		wh, _ := tgt.IdentityExtras(id)["webpackHash"].(string)
		return wh != ""
	}
	if err := quick.Check(f, pcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 18: Named-target schema and envelope conformance — each registered named target produces a schema-conformant payload derived from the identity core, wrapped in its documented envelope.
func TestProperty18_NamedTargetSchemaEnvelope(t *testing.T) {
	// per-target: (variant, session inputs, validator).
	type tc struct {
		target   string
		variant  string
		sess     antibot.SessionInputs
		validate func(res *antibot.BuildResult) bool
	}
	hasKeys := func(raw json.RawMessage, keys ...string) bool {
		var m map[string]json.RawMessage
		if json.Unmarshal(raw, &m) != nil {
			return false
		}
		for _, k := range keys {
			if _, ok := m[k]; !ok {
				return false
			}
		}
		return true
	}
	bdaOK := func(res *antibot.BuildResult) bool {
		if !hasKeys(res.Raw, "api_type", "f", "n", "wh", "enhanced_fp", "fe", "ife_hash", "jsbd", "c") {
			return false
		}
		blob, err := base64.StdEncoding.DecodeString(res.Encoded)
		if err != nil {
			return false
		}
		return hasKeys(blob, "ct", "iv", "s")
	}
	cases := []tc{
		{"x", "xpff", antibot.SessionInputs{"guest_id": "v1%3A123"}, func(r *antibot.BuildResult) bool {
			if !hasKeys(r.Raw, "navigator_properties", "created_at") {
				return false
			}
			b, err := hex.DecodeString(r.Encoded)
			return err == nil && len(b) >= 12+16
		}},
		{"x", "txid", antibot.SessionInputs{"method": "POST", "path": "/i/api", "verification": base64.StdEncoding.EncodeToString([]byte("keybytes")), "animation_key": "abc"}, func(r *antibot.BuildResult) bool {
			return r.Encoded != "" && !strings.HasSuffix(r.Encoded, "=")
		}},
		{"x", "arkose", antibot.SessionInputs{"sitekey": "PK-1"}, bdaOK},
		{"microsoft", "", nil, bdaOK},
		{"xiaomi", "", nil, func(r *antibot.BuildResult) bool {
			if !hasKeys(r.Raw, "type", "startTs", "endTs", "env", "action", "force", "talkBack", "nonce", "version", "scene") {
				return false
			}
			return strings.HasPrefix(r.Encoded, "s=") && strings.Contains(r.Encoded, "&d=") && strings.HasSuffix(r.Encoded, "&a=register")
		}},
	}

	f := func(d, b, c uint8) bool {
		id := randID(d, b, c)
		for _, cse := range cases {
			tgt, err := antibot.MustGet(cse.target)
			if err != nil {
				return false
			}
			res, err := tgt.Build(&antibot.BuildContext{Identity: id, Variant: cse.variant, SessionInputs: cse.sess, Encrypt: true})
			if err != nil || !cse.validate(res) {
				return false
			}
		}
		return true
	}
	if err := quick.Check(f, pcfg); err != nil {
		t.Fatal(err)
	}
}

// Feature: global-fingerprint-optimization, Property 21: Envelope key derivation from identity/session inputs — decrypting x/xpff (IV||ct||tag) with SHA-256(base_key||guest_id) recovers the payload; the key is a deterministic function of exactly the declared inputs.
func TestProperty21_XPFFKeyDerivation(t *testing.T) {
	tgt, err := antibot.MustGet("x")
	if err != nil {
		t.Fatal(err)
	}
	f := func(d, b, c uint8, guest string) bool {
		if strings.TrimSpace(guest) == "" {
			guest = "v1%3A0000000000"
		}
		id := randID(d, b, c)
		res, err := tgt.Build(&antibot.BuildContext{Identity: id, Variant: "xpff", SessionInputs: antibot.SessionInputs{"guest_id": guest}})
		if err != nil {
			return false
		}
		raw, err := hex.DecodeString(res.Encoded)
		if err != nil || len(raw) < 12+16 {
			return false
		}
		key := x.DeriveXPFFKey(strings.TrimSpace(guest))
		block, err := aes.NewCipher(key[:])
		if err != nil {
			return false
		}
		gcm, err := cipher.NewGCM(block)
		if err != nil {
			return false
		}
		iv, ct := raw[:12], raw[12:]
		pt, err := gcm.Open(nil, iv, ct, nil)
		if err != nil {
			return false
		}
		// wrong key must fail (key depends on guest_id).
		wrong := x.DeriveXPFFKey(strings.TrimSpace(guest) + "x")
		wb, _ := aes.NewCipher(wrong[:])
		wg, _ := cipher.NewGCM(wb)
		if _, err := wg.Open(nil, iv, ct, nil); err == nil {
			return false
		}
		return string(pt) == string(res.Raw)
	}
	if err := quick.Check(f, pcfg); err != nil {
		t.Fatal(err)
	}
}
