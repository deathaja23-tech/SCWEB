package antibot_test

import (
	"math/big"
	"testing"

	"fingerprint-generator/internal/antibot"
	_ "fingerprint-generator/internal/antibot/amazon"
	_ "fingerprint-generator/internal/antibot/generic"
	_ "fingerprint-generator/internal/antibot/microsoft"
	_ "fingerprint-generator/internal/antibot/x"
	"fingerprint-generator/internal/antibot/xiaomi"
	_ "fingerprint-generator/internal/antibot/xiaomi"
)

// Smoke: every registered target has a unique, non-empty Name, and its
// Capabilities are internally consistent (DefaultVariant ∈ Variants; RequiredInputs
// keys reference declared variants or "").
func TestSmoke_RegisteredTargetsValid(t *testing.T) {
	names := antibot.Names()
	if len(names) == 0 {
		t.Fatal("no targets registered")
	}
	seen := map[string]bool{}
	for _, name := range names {
		if name == "" {
			t.Fatal("empty target name")
		}
		if seen[name] {
			t.Fatalf("duplicate target name %q", name)
		}
		seen[name] = true

		tgt, err := antibot.MustGet(name)
		if err != nil {
			t.Fatalf("MustGet(%q): %v", name, err)
		}
		if tgt.Name() != name {
			t.Fatalf("Name() %q != registry key %q", tgt.Name(), name)
		}
		caps := tgt.Capabilities()
		if len(caps.Variants) > 0 {
			found := false
			for _, v := range caps.Variants {
				if v == caps.DefaultVariant {
					found = true
				}
			}
			if !found {
				t.Fatalf("target %q DefaultVariant %q not in Variants %v", name, caps.DefaultVariant, caps.Variants)
			}
		}
		for vkey := range caps.RequiredInputs {
			if vkey == "" {
				continue
			}
			ok := false
			for _, v := range caps.Variants {
				if v == vkey {
					ok = true
				}
			}
			if !ok {
				t.Fatalf("target %q RequiredInputs key %q is not a declared variant", name, vkey)
			}
		}
	}
}

// Smoke: Xiaomi RSA key material matches the documented moduli and exponent
// (anti-bot-crypto-constants.md §1). Catches mis-copied constants early.
func TestSmoke_XiaomiRSAConstants(t *testing.T) {
	eui := xiaomi.EUIPublicKey()
	if eui.E != 65537 {
		t.Fatalf("EUI exponent = %d, want 65537", eui.E)
	}
	wantEUI, _ := new(big.Int).SetString(xiaomi.EUIModulusHex, 16)
	if eui.N.Cmp(wantEUI) != 0 {
		t.Fatal("EUI modulus mismatch")
	}
	if eui.N.BitLen() != 1024 {
		t.Fatalf("EUI key size = %d bits, want 1024", eui.N.BitLen())
	}

	cap := xiaomi.CaptchaPublicKey()
	if cap.E != 65537 {
		t.Fatalf("captcha exponent = %d, want 65537", cap.E)
	}
	wantCap, _ := new(big.Int).SetString(xiaomi.CaptchaModulusHex, 16)
	if cap.N.Cmp(wantCap) != 0 {
		t.Fatal("captcha modulus mismatch")
	}
	if cap.N.BitLen() != 2048 {
		t.Fatalf("captcha key size = %d bits, want 2048", cap.N.BitLen())
	}
}
