// Package akamai is a SCAFFOLD for Akamai Bot Manager sensor_data
// (anti-bot-fingerprint-reference.md §5). NOT REGISTERED and, per a full RE on
// 2026-07-14, NOT IMPLEMENTABLE as a stateless generator — see UNSTABLE_TARGETS.md
// §akamai for the evidence. Two architectural blockers proven empirically against
// a live BestBuy sensor_data v3 capture:
//
//  1. Server-issued nonce: the telemetry header carries e=<hash>~YAAQ... whose
//     YAAQ token is found inside the server-set bm_sz cookie. A valid payload
//     requires the server's challenge token first (challenge-response), so it
//     cannot be generated from nothing.
//  2. Internal accumulation state: with Date.now/performance.now/Math.random
//     frozen and no input, two consecutive bmak.get_telemetry() calls still
//     differ (6530B vs 2694B) — an internal counter/state changes per call.
//
// Contrast datadome/human (registered, byte-accurate): their encryption seed is
// a constant (0x7d8479f9, cross-session stable) and every input is deterministic
// from the identity + a client-chosen session key. Akamai's seed is a server
// nonce plus accumulating state, so an offline generator is impossible. The only
// viable approach is stateful extraction-replay (fetch bm_sz -> run get_telemetry
// in a live browser -> replay), which is a solver/client concern, not this
// stateless generator. The scaffold below conforms to antibot.Target only to keep
// the seam compiling; requests for "akamai" return the standard 400 unknown-target.
package akamai

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"strings"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/identity"
)

// compile-time interface check (conforms without being registered).
var _ antibot.Target = Target{}

// Target implements antibot.Target for Akamai (scaffold, not registered).
type Target struct{}

func (Target) Name() string { return "akamai" }

func (Target) Capabilities() antibot.Capabilities {
	// Cookies (_abck / bm_sz) are optional; no strictly-required session inputs.
	return antibot.Capabilities{EncryptionApplicable: true, RequiredInputs: map[string][]string{"": nil}}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build produces a PLACEHOLDER sensor array + SHA-256 hex (the real 58-element
// order/delimiter is unknown). Structural only.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	id := ctx.Identity
	syn := behavioral.NewFromIdentity(id)
	track := syn.MouseTrack(behavioral.Point{X: 0, Y: 0}, behavioral.Point{X: id.Screen.Width / 2, Y: id.Screen.Height / 2}, 24)

	fields := []string{
		"-1", id.UA, id.Platform,
		itoa(id.Screen.Width), itoa(id.Screen.Height),
		itoa(int(id.CanvasHash)), itoa(id.HardwareConcurrency),
	}
	for _, s := range track {
		fields = append(fields, itoa(s.X)+","+itoa(s.Y)+","+itoa(int(s.T)))
	}

	raw, err := json.Marshal(map[string]interface{}{"sensor_fields": fields, "note": "scaffold"})
	if err != nil {
		return nil, err
	}
	joined := strings.Join(fields, ",")
	sum := sha256.Sum256([]byte(joined))
	telemetry := base64.StdEncoding.EncodeToString([]byte(hex.EncodeToString(sum[:])))
	return &antibot.BuildResult{Raw: raw, Encoded: telemetry}, nil
}

func itoa(v int) string {
	neg := v < 0
	if neg {
		v = -v
	}
	if v == 0 {
		return "0"
	}
	var b [20]byte
	i := len(b)
	for v > 0 {
		i--
		b[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
