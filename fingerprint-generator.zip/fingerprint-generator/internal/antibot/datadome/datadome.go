// Package datadome implements the DataDome payload+envelope builder
// (anti-bot-fingerprint-reference.md §4, anti-bot-crypto-constants.md §4).
//
// The encryption pipeline (custom PRNG + CID PRNG + custom base64) is verified
// byte-accurate against tags.js v5.8.0 by known-plaintext round-trip. The
// signal ORDER and clean-browser defaults are captured in signal_template.go.
// Identity-coherent fields (screen/GPU/UA/tz/...) are overridden from the
// BrowserIdentity; a handful of session-specific fields (hashes, key/mouse
// stats) are randomized per build so payloads are not byte-identical.
//
// REGISTERED. Requires session inputs cid + ddk (hash) + url.
package datadome

import (
	"encoding/json"
	"strconv"

	"fingerprint-generator/internal/antibot"
	"fingerprint-generator/internal/antibot/behavioral"
	"fingerprint-generator/internal/antibot/cryptoutil"
	"fingerprint-generator/internal/identity"
)

// Build constants (anti-bot-crypto-constants.md §4 + RE of tags.js v5.8.0).
//   - mainBuildConst is the cross-session-stable `i^t` seed constant recovered
//     by known-plaintext attack (0x7d8479f9). mainSeed = mainBuildConst ^ djb2(ddk).
//   - cidBuildConst seeds the second XOR layer: cidSeed = cidBuildConst ^ djb2(cid).
const (
	mainBuildConst = uint32(0x7d8479f9)
	cidBuildConst  = uint32(1809053797)
)

// compile-time interface check.
var _ antibot.Target = Target{}

func init() { antibot.Register(Target{}) }

// Target implements antibot.Target for DataDome.
type Target struct{}

func (Target) Name() string { return "datadome" }

// Capabilities: single-output, enveloped, requires cid + hash (ddk) session inputs.
func (Target) Capabilities() antibot.Capabilities {
	return antibot.Capabilities{
		EncryptionApplicable: true,
		RequiredInputs:       map[string][]string{"": {"cid", "hash"}},
	}
}

func (Target) IdentityExtras(*identity.BrowserIdentity) map[string]interface{} { return nil }

// Build assembles the ordered signal buffer and applies the DataDome envelope.
func (Target) Build(ctx *antibot.BuildContext) (*antibot.BuildResult, error) {
	entries := BuildSignals(ctx.Identity, ctx.SessionInputs, behavioral.NewFromIdentity(ctx.Identity))

	// Envelope keying. ddk is the site hash carried in the "hash" session input.
	ddk := ctx.SessionInputs.Get("hash")
	cid := ctx.SessionInputs.Get("cid")
	mainSeed := mainBuildConst ^ cryptoutil.Djb2u(ddk)
	cidSeed := cidBuildConst ^ cryptoutil.Djb2u(cid)
	// Per-session salt u: low byte derived from the identity clock so payloads
	// vary between sessions but stay reproducible within one build.
	u := uint32(ctx.ClockNow().UnixMilli()>>3) & 0xFF

	raw, err := json.Marshal(entries)
	if err != nil {
		return nil, err
	}
	encoded := cryptoutil.DataDomeEncode(entries, mainSeed, cidSeed, u)
	return &antibot.BuildResult{Raw: raw, Encoded: encoded}, nil
}

// BuildSignals produces the ordered (key, jsonValue) signal list. It starts
// from the captured canonical template (signal_template.go) and overrides the
// identity-coherent + session-specific fields. Shared with the human target.
func BuildSignals(id *identity.BrowserIdentity, sess antibot.SessionInputs, syn *behavioral.Synth) [][2]string {
	over := identityOverrides(id, sess, syn)
	out := make([][2]string, 0, len(ddSignalTemplate))
	for _, s := range ddSignalTemplate {
		if v, ok := over[s.Key]; ok {
			out = append(out, [2]string{s.Key, v})
			continue
		}
		out = append(out, [2]string{s.Key, s.Val})
	}
	return out
}

// identityOverrides maps the identity-coherent and session-specific signals to
// values derived from the BrowserIdentity (so the payload does not contradict
// the fingerprint) and to per-build randomized values (so it is not static).
func identityOverrides(id *identity.BrowserIdentity, sess antibot.SessionInputs, syn *behavioral.Synth) map[string]string {
	q := func(s string) string { return strconv.Quote(s) }
	i := func(n int) string { return strconv.Itoa(n) }

	sw, sh := id.Screen.Width, id.Screen.Height
	// inner/available viewport: conventional clean-desktop deltas.
	availH := sh - 48
	innerW, innerH := sw*2/3, sh*2/3
	if innerW < 1024 {
		innerW = 1280
	}
	if innerH < 600 {
		innerH = 720
	}

	m := map[string]string{
		// screen / viewport (identity-coherent)
		"rs_w":  i(sw),
		"rs_h":  i(sh),
		"ars_w": i(sw),
		"ars_h": i(availH),
		"br_w":  i(innerW),
		"br_h":  i(innerH),
		"br_iw": i(innerW),
		"br_ih": i(innerH),
		"rs_cd": "24",
		"pr":    i(id.Screen.DevicePixelRatio),
		"so":    q("landscape-primary"),
		// hardware / platform
		"hc":  i(id.HardwareConcurrency),
		"dvm": i(id.DeviceMemory),
		"pf":  q(id.Platform),
		"ua":  q(id.UA),
		"mob": "false",
		// gpu
		"glvd": q(id.GPUVendor),
		"glrd": q(id.GPUModel),
		"iwgl": "true",
		// locale / timezone
		"tz":  i(id.TimeZone * -60), // JS getTimezoneOffset() sign convention
		"lg":  q(id.Locale),
		"lgs": langsJSON(id.Languages),
		// plugins
		"plg": i(len(id.Plugins)),
		// session-specific: randomized per build so payloads aren't byte-identical
		"trrd":    randFloat01(syn),
		"wdifpnh": q(i(randU32(syn))),
		"sgb":     i(randU32(syn)),
		"sgd":     i(randU32(syn)),
		"sgc":     i(randU32(syn)),
		"uish":    i(randU32(syn)),
	}
	return m
}

func langsJSON(langs []string) string {
	if len(langs) == 0 {
		return `["en-US"]`
	}
	b, _ := json.Marshal(langs)
	return string(b)
}

func randU32(syn *behavioral.Synth) int {
	return syn.Timing(1, 1, 0x7FFFFFFF)[0]
}

func randFloat01(syn *behavioral.Synth) string {
	n := syn.Timing(1, 1, 1_000_000_000)[0]
	f := float64(n) / 1_000_000_000.0
	return strconv.FormatFloat(f, 'g', 16, 64)
}
