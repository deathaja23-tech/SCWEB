# Fingerprint Generator

## Overview

Browser fingerprint generation HTTP API. Pure Go (zero external dependencies), generates realistic Chrome 120–151 fingerprints with GPU, screen, WebGL, canvas, math precision, audio, fonts, and performance timing. Multi-target architecture: a generic browser-identity core feeds pluggable per-antibot targets (currently Amazon TES only). Runs as systemd service `fingerprint-server.service` on `:8800`, exposed at `https://fp.example.com` via Cloudflare Tunnel + Caddy.

## Commands

```bash
# Build
cd ./ && go build -o ~/bin/fingerprint-server ./cmd/server/

# Run (systemd — primary)
sudo systemctl restart fingerprint-server.service
sudo systemctl status fingerprint-server.service
journalctl -u fingerprint-server.service -f

# Health check
curl https://fp.example.com/health

# Generate fingerprint (remote)
TOKEN=$(cut -d= -f2 .fp-token.env)
curl -H "Authorization: Bearer $TOKEN" "https://fp.example.com/fingerprint"
curl -H "Authorization: Bearer $TOKEN" "https://fp.example.com/fingerprint?count=5&chrome=131&encrypt=true"

# Generate fingerprint (local, no token)
curl "http://127.0.0.1:8800/fingerprint?count=1&pretty=true"
```

## Conventions

- Go stdlib only — no `go.sum`, no external modules
- HTTP server uses `net/http` mux, not a framework
- Identity core (`internal/identity/`) is target-agnostic; antibot-specific payload shaping lives in `internal/antibot/<target>/`
- Target adapters implement the `antibot.Target` interface: `Name()`, `BuildPayload()`, `Encrypt()`, `IdentityExtras()`
- Per-proxy identity cache (6h TTL) at `~/.fingerprint-generator/identities.dat`
- CORS enabled globally (`Access-Control-Allow-Origin: *`)
- Swagger UI at `/docs` + raw OpenAPI at `/openapi.json` (both public, hand-written in `docs.go`)

## Boundaries

- **NEVER** commit `.fp-token.env` — it's the Bearer token for remote API access
- **NEVER** add external Go dependencies — zero-dep is a core design constraint
- **NEVER** generate identities without hardware correlation (GPU ↔ RAM ↔ CPU tiers must be coherent — no RTX 4090 + 2GB RAM)
- **ALWAYS** normalize proxy URLs to `host:port` for cache key dedup
- **ALWAYS** ensure platform consistency: UA, Sec-CH-UA-Platform, GPU renderer, fonts, screen DPR must all match the selected platform (Win32/MacIntel/Linux)

## Dependencies

None. Pure Go stdlib + internal packages. No `go.sum` file exists.

## Config

| Env var / Flag | Default | Purpose |
|----------------|---------|---------|
| `--port` | `8800` | Listen port |
| `--host` | `0.0.0.0` | Listen host |
| `--cache-dir` | `~/.fingerprint-generator/` | Cache directory for proxy identity map |

Bearer token: `.//.fp-token.env`
Caddy enforces Bearer auth on all paths except `/health` and docs paths on the public domain. Localhost has no auth.

## Error Handling

- Unknown `target` query param → 400 with available target names
- Build/encrypt failure → 500 with error message
- Count capped at 100 (silent clamp)
- Cache miss → new random identity generated; cache hit → reused within 6h TTL

## Troubleshooting

1. **Platform mismatch detected by antibot**: Ensure the identity's platform, UA, GPU renderer, fonts, and screen DPR are all internally consistent. The generator handles this automatically for random identities, but pinned Chrome versions still respect platform weights.

2. **Proxy identity not caching**: Cache key is normalized to `host:port`. If the same proxy with different auth strings produces different identities, check that the URL normalization strips credentials properly.

3. **Adding a new antibot target**: Implement `antibot.Target` interface in `internal/antibot/<name>/`, register via `init()`, add blank import in `cmd/server/main.go`. Must supply the reverse-engineered payload schema from a real captured request.

4. **systemd restart**: `sudo systemctl restart fingerprint-server.service`. Binary at `~/bin/fingerprint-server`. Build with `go build -o ~/bin/fingerprint-server ./cmd/server/` from project root.
