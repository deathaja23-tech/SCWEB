# Anti-Bot Fingerprint Payload Reference

Comprehensive payload format and encryption details for major anti-bot systems.
All structures verified from deobfuscated source code and public reverse-engineering artifacts.

---

## Table of Contents

1. [Xiaomi MiMo Platform](#1-xiaomi-mimo-platform)
2. [X/Twitter TES (Twitter Evaluation System)](#2-xtwitter-tes-twitter-evaluation-system)
3. [Arkose Labs FunCaptcha (Microsoft/X)](#3-arkose-labs-funcaptcha-microsoftx)
4. [DataDome / HUMAN Security](#4-datadome--human-security)
5. [Akamai Bot Manager](#5-akamai-bot-manager)
6. [Cloudflare JSD Challenge](#6-cloudflare-jsd-challenge)
7. [Cloudflare Turnstile](#7-cloudflare-turnstile)
8. [Kasada](#8-kasada)
9. [GitHub (Lightweight)](#9-github-lightweight)
10. [Cross-Platform Comparison](#10-cross-platform-comparison)

---

## 1. Xiaomi MiMo Platform

### Encryption (TWO Distinct RSA+AES Layers)

**Layer 1 — Account Registration (EUI):**
- RSA-1024, PKCS#1 v1.5
- AES key: random 16 chars from charset `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*`
- AES-128-CBC, fixed IV `0102030405060708`, PKCS7 padding
- Output: `EUI = <RSA(base64(aesKey))>.<base64(field_names)>` + each field value encrypted separately

**Layer 2 — Captcha Data Payload:**
- RSA-**2048**, PKCS#1 v1.5 (DIFFERENT key from registration)
- AES key: random 16 chars from charset `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()-=_+~`{}[]|:<>?/.` (89 chars)
- AES-128-CBC, fixed IV `0102030405060708`, PKCS7 padding
- Output: `s = RSA(base64(aesKey))` + `d = AES-CBC(JSON(payload))`
- POST body: `s=<s>&d=<d>&a=register`

### Captcha Payload Structure (Real Chrome 148 Capture)

```json
{
  "type": 0,
  "startTs": 1752172800000,
  "endTs": 1752172800600,
  "env": {
    "p1": "0.1",
    "p2": "pc-Chrome148",
    "p3": "Linux x86_64",
    "p4": "Gecko",
    "p5": "en-US",
    "p6": "Netscape",
    "p7": "Mozilla",
    "p8": true,
    "p9": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ...",
    "p10": 0,
    "p11": 1752172800000,
    "p12": 1920,
    "p13": 1080,
    "p14": 1920,
    "p15": 1080,
    "p16": 1860,
    "p17": 960,
    "p18": "https://global.account.xiaomi.com/fe/service/register?_locale=en_US&_uRegion=ID",
    "p19": 5,
    "p20": "b61165d7c387d373f59d977af2b3c5a090f61907",
    "p21": "Pd369809e2cf9b3e61d61254f48e6a98e6abe02ed,Cf5de68f67482549f612c4c553c1a8d44de2fd042,M0c8ad6916ae9493e506332df0ddbf245659ad2de,W26c61e60e6329023c3daad583513d7c4e6331c3a",
    "p22": 0,
    "p23": "da39a3ee5e6b4b0d3255bfef95601890afd80709",
    "p24": "",
    "p25": "79c0c1eb2748f583a66ce654b4dc1685157963f8",
    "p26": "fbe83d766a4229e366d48d0096d8e26aaf852730",
    "p28": "",
    "p29": 107,
    "p30": 10,
    "p31": 10,
    "p32": "0.73",
    "p33": [],
    "p34": "https://global.account.xiaomi.com/fe/service/register?_locale=en_US&_uRegion=ID"
  },
  "action": {
    "a1": [1860, 960],
    "a2": [],
    "a3": [[657, 599, 99], [827, 702, 690]],
    "a4": [],
    "a5": [[657, 599, 83], [827, 702, 685]],
    "a6": [],
    "a7": [],
    "a8": [99],
    "a9": [98, 689],
    "a10": [],
    "a11": [],
    "a12": [],
    "a13": [],
    "a14": []
  },
  "force": true,
  "talkBack": false,
  "nonce": { "t": 1752172800, "r": 4829173645182 },
  "version": "2.0",
  "scene": "register"
}
```

### Field Reference

| Field | Description |
|-------|-------------|
| `p1` | Version string |
| `p2` | Device+browser identifier |
| `p3` | Platform (navigator.platform) |
| `p4` | Engine (navigator.product) |
| `p5` | Language (navigator.language) |
| `p6` | App name (navigator.appName) |
| `p7` | App code name (navigator.appCodeName) |
| `p8` | Cookie enabled (navigator.cookieEnabled) |
| `p9` | User agent string |
| `p10` | Unknown (always 0) |
| `p11` | Timestamp (same as startTs) |
| `p12` | screen.width |
| `p13` | screen.height |
| `p14` | screen.availWidth |
| `p15` | screen.availHeight |
| `p16` | innerWidth (viewport) |
| `p17` | innerHeight (viewport) |
| `p18` | Page URL |
| `p19` | hardwareConcurrency |
| `p20` | Canvas fingerprint hash (40 hex chars) |
| `p21` | WebGL fingerprints (P=platform, C=canvas, M=math, W=webgl — 4x 40 hex) |
| `p22` | Unknown (always 0) |
| `p23` | Empty canvas hash (SHA1 of empty) |
| `p24` | Unknown (empty string) |
| `p25` | Audio fingerprint hash (40 hex) |
| `p26` | Fonts fingerprint hash (40 hex) |
| `p28` | Unknown (empty string) |
| `p29` | Plugins count |
| `p30` | Unknown (always 10) |
| `p31` | Unknown (always 10) |
| `p32` | Unknown (always "0.73") |
| `p33` | Automation anomalies (EMPTY = real browser, non-empty = bot detected) |
| `p34` | Page URL (same as p18) |
| `a1` | Viewport dimensions [width, height] |
| `a3` | Click coordinates + timing [[x, y, t], ...] |
| `a5` | Mouseup coordinates + timing [[x, y, t], ...] |
| `a8` | Event timing array |
| `a9` | Event timing array |

### Per-Account Randomization

To avoid fingerprint clustering, each account gets unique:
- `p20` — canvas hash: random 40 hex chars
- `p21` — WebGL hashes: random 40 hex each
- `p25` — audio hash: random 40 hex chars
- `p26` — fonts hash: random 40 hex chars
- `p12-p17` — screen/viewport: randomized from 8 common resolutions
- `a3/a5` — click coordinates: jittered ±3px
- `startTs/endTs` — timing: 600-1800ms realistic collection duration

### Captcha Flow

```
Step 1: GET register page → initial cookies
Step 2: GET /pass2/config?key=register → passport config
Step 3: POST verify.sec.xiaomi.com/captcha/v2/data?k=<KEY>
         body: s=<RSA-key>&d=<AES-payload>&a=register → e_token
Step 4: Solve reCAPTCHA Enterprise v2
         (sitekey: 6LeBM0ocAAAAAEwYcFUjtxpVbs-0rnbSVXBBXmh4)
         bound to e_token via enterprisePayload.s
Step 5: POST verify.sec.xiaomi.com/captcha/v2/recaptcha/verify?k=<KEY>
         body: e=<e_token>&g=<recaptcha_token>&type=4 → captchaToken
Step 6: POST /passport/register (encrypted email/password via EUI)
Step 7: IMAP poll for 6-digit verification code from noreply@notice.xiaomi.com
Step 8: POST /passport/verify (encrypted verification code)
```

### Constants

| Constant | Value |
|----------|-------|
| Captcha Data Key | `8027422fb0eb42fbac1b521ec4a7961f` |
| reCAPTCHA Sitekey | `6LeBM0ocAAAAAEwYcFUjtxpVbs-0rnbSVXBBXmh4` |
| Captcha Data Endpoint | `https://verify.sec.xiaomi.com/captcha/v2/data` |
| Captcha Verify Endpoint | `https://verify.sec.xiaomi.com/captcha/v2/recaptcha/verify` |
| Email Sender | `noreply@notice.xiaomi.com` |

---

## 2. X/Twitter Anti-Bot Systems

X/Twitter uses THREE separate anti-bot/fingerprinting systems:
1. **XPFF (X-Xp-Forwarded-For)** — WASM-based browser fingerprint header
2. **Transaction ID (X-Client-Transaction-Id)** — CSS animation fingerprint + request signing
3. **Arkose FunCaptcha** — interactive challenge (covered in Section 3)

---

### 2A. XPFF (X-Xp-Forwarded-For) Header

#### Encryption: AES-256-GCM (Go WASM)

- **Algorithm:** AES-256-GCM
- **Key derivation:** `SHA-256(base_key + guest_id)` → 32-byte digest = AES key directly
- **Base key** (hardcoded in WASM data section):
  ```
  0e6be1f1e21ffc33590b888fd4dc81b19713e570e805d4e5df80a493c9571a05
  ```
- **guest_id:** extracted from Twitter cookies (URL-encoded, e.g. `v1%3A174849298500261196`)
- **IV:** 12 bytes, randomly generated (`wasi_snapshot_preview1.random_get`)
- **Auth tag:** 16 bytes (standard GCM)
- **Output:** hex-encoded `IV (12B) || ciphertext || tag (16B)`
- **Validity:** 300,000 ms (5 minutes)

#### WASM Call Flow

```
$func428 (main entry)
 ├─ pulls JS data via syscall/js.valueGet
 ├─ $func410 → builds JSON payload
 ├─ key derivation:
 │    ├─ hardcoded base_key + guest_id (from cookies)
 │    └─ $func20 (concat) → $func207 (SHA-256 update) → $func208 (finalize)
 ├─ $func250 → AES key expansion
 ├─ write 12-byte IV to memory
 ├─ $func266 → AES-GCM encrypt → ciphertext
 ├─ write IV + ciphertext + tag consecutively
 └─ convert buffer to hex string → return
```

#### Current Payload (ACTIVE)

```json
{
  "navigator_properties": {
    "hasBeenActive": "true",
    "userAgent": "Mozilla/5.0 ...",
    "webdriver": "false"
  },
  "created_at": 1750014202073
}
```

#### Old Payload (DEPRECATED — fields now empty/removed)

```json
{
  "webgl_fingerprint": "",
  "canvas_fingerprint": "",
  "navigator_properties": {
    "hasBeenActive": "false",
    "userAgent": "...",
    "webdriver": "false"
  },
  "codec_fingerprint": "",
  "audio_fingerprint": "",
  "audio_properties": null,
  "created_at": 1750014202073
}
```

#### Fingerprint Fields Status

| Field | Source | Status |
|-------|--------|--------|
| `navigator.userAgent` | JS `navigator.userAgent` | **ACTIVE** |
| `navigator.webdriver` | JS `navigator.webdriver` → `"false"` | **ACTIVE** |
| `navigator.userActivation.hasBeenActive` | JS API | **ACTIVE** |
| `created_at` | `Date.now()` (unix ms) | **ACTIVE** |
| `webgl_fingerprint` | WASM placeholder | **EMPTY/REMOVED** |
| `canvas_fingerprint` | WASM placeholder | **EMPTY/REMOVED** |
| `codec_fingerprint` | WASM placeholder | **EMPTY/REMOVED** |
| `audio_fingerprint` | WASM placeholder | **EMPTY/REMOVED** |
| `audio_properties` | WASM placeholder | **EMPTY/REMOVED** |

#### SDK Details

- **Namespace:** `window.XPForwardedForSDK`
- **Methods:** `init()`, `getForwardedForStr()`, `destroy()`, `pause()`, `resume()`
- **Host validation:** only `x.com`, `pro.x.com` (prod) and `localhost.x.com:3443` (dev)
- **WASM binary:** Go compiled (`GOOS=js GOARCH=wasm`), ~372KB, uses `crypto/aes` + `crypto/cipher` (GCM) + `crypto/sha256`
- **Return format:** `{ str: "<base64-token>", expiryTimeMillis: <timestamp> }`

#### Key Constants

| Constant | Value |
|----------|-------|
| AES base key | `0e6be1f1e21ffc33590b888fd4dc81b19713e570e805d4e5df80a493c9571a05` |
| GCM IV length | 12 bytes |
| GCM auth tag | 16 bytes |
| Token validity | 300,000 ms (5 minutes) |
| AES source | Go stdlib `crypto/internal/fips140/aes/aes_generic.go:148` |

---

### 2B. Transaction ID (X-Client-Transaction-Id)

#### Algorithm

1. Fetch `x.com` home page, extract `<meta name="twitter-site-verification" content="...">` value (base64-encoded key bytes)
2. Load `ondemand.s` JS file (URL from regex `"ondemand\.s"\s*:\s*"([\w]+)"`) — extract indices
3. Derive `animation_key` from CSS animation fingerprint
4. Compute SHA-256 hash of request-specific payload
5. Assemble byte array, XOR with random salt, base64 encode

#### Animation Key Derivation (CSS Animation Fingerprint)

1. `row_index = key_bytes[row_index_from_ondemand] % 16`
2. `frame_time = reduce(multiply, [key_bytes[i] % 16 for i in key_bytes_indices])`, rounded to nearest 10
3. Select DOM element `[id^='loading-x-anim']` at index `key_bytes[5] % 4`
4. Parse SVG path `d` attribute, split on `C` to get bezier control points
5. Use `row_index` to select a frame, compute `target_time = frame_time / 4096`
6. Interpolate color (from_color → to_color) and rotation via cubic bezier
7. Convert rotation to transformation matrix `[cos, -sin, sin, cos]`
8. Build hex string from color RGB + matrix values, strip `[.-]` chars → `animation_key`

#### Hash Construction

```
hash_input = "{METHOD}!{PATH}!{TIME_NOW}obfiowerehiring{animation_key}"

where:
  TIME_NOW = floor((timestamp_ms - 1682924400000) / 1000)  // offset from April 2023
  hash = SHA-256(hash_input)
```

#### Payload Byte Assembly

```python
time_now_bytes = [(time_now >> (i*8)) & 0xFF for i in range(4)]  # 4 bytes little-endian
random_num = randint(0, 255)
bytes_arr = [*key_bytes, *time_now_bytes, *hash_val[:16], 3]
# key_bytes + 4 time bytes + 16 hash bytes + terminator 0x03
out = bytearray([random_num, *[b ^ random_num for b in bytes_arr]])
# XOR all with random salt
```

**Encoding:** Base64, trailing `=` stripped.

#### Key Constants

| Constant | Value |
|----------|-------|
| Time epoch offset | `1682924400000` ms (April 2023) |
| Hash salt literal | `obfiowerehiring` |
| Transaction terminator byte | `0x03` |
| XOR random salt range | 0–255 |
| Verification meta tag | `<meta name="twitter-site-verification">` |
| Ondemand regex | `(\(\w{1}\[(\d{1,2})\],\s*16\))+` |

---

### 2C. Arkose FunCaptcha (X Integration)

X/Twitter uses Arkose FunCaptcha for interactive challenges. The full BDA payload structure, fe array keys, enhanced_fp fields, and encryption details are documented in **Section 3 (Arkose Labs FunCaptcha)**.

Key difference from Microsoft: X's Arkose public key is per-session (loaded from enforcement script), not a static key.

---

## 3. Arkose Labs FunCaptcha (Microsoft/X)

### BDA Payload Top-Level Fields

| Field | Type | Description |
|-------|------|-------------|
| `api_type` | string | Static `"js"` |
| `f` | string | MurmurHash3-128 hex digest of `fe` values joined with `;` |
| `n` | string | Base64-encoded UNIX timestamp (seconds) |
| `wh` | string | Window hash: 2x MurmurHash3-128 (seed 420) concatenated with `\|` |
| `enhanced_fp` | object | 60+ fingerprint signals (see below) |
| `fe` | array | Array of `"PREFIX:value"` strings (see below) |
| `ife_hash` | string | MurmurHash3-128 of fe tokens joined with `, ` (seed 38) |
| `jsbd` | object | Browser metadata: `{HL, NCE, DT, NWD, DMTO, DOTO}` |
| `c` | string | Copyright string (used as of 2025-02) |

### `fe` Array Keys (PREFIX:value format)

```
DNT:          - Do Not Track (navigator.doNotTrack)
L:            - Language (navigator.language)
D:            - Color Depth (screen.colorDepth)
PR:           - Device Pixel Ratio
S:            - Screen resolution (width,height — larger dim first)
AS:           - Available screen resolution
TO:           - Timezone offset (minutes from UTC)
SS:           - sessionStorage available (true/false)
LS:           - localStorage available (true/false)
IDB:          - IndexedDB available (true/false)
B:            - IE addBehavior (true/false)
ODB:          - openDatabase / Web SQL (true/false)
CPUC:         - cpuClass ("unknown" if absent)
PK:           - Platform (navigator.platform)
CFP:          - Canvas fingerprint (Java hashCode)
FR:           - Fake resolution detected (true/false)
FOS:          - Fake OS detected (true/false)
FB:           - Fake browser detected (true/false)
JSF:          - JavaScript fonts (65 fonts checked, semicolon-separated)
P:            - navigator.plugins names (sorted, semicolon-separated)
T:            - Touch support (maxTouch,touchEvent,ontouchstart)
H:            - hardwareConcurrency
SWF:          - swfobject (legacy, always false)
```

### `enhanced_fp` Object — Complete Key List

**WebGL signals:**
- `webgl_extensions` — semicolon-separated getSupportedExtensions()
- `webgl_extensions_hash` — MurmurHash3-128 of extensions string
- `webgl_renderer` — getParameter(RENDERER)
- `webgl_vendor` — getParameter(VENDOR)
- `webgl_version` — getParameter(VERSION)
- `webgl_shading_language_version`
- `webgl_aliased_line_width_range` — [min, max]
- `webgl_aliased_point_size_range` — [min, max]
- `webgl_antialiasing` — "yes"/"no"
- `webgl_bits` — "ALPHA,BLUE,DEPTH,GREEN,RED,STENCIL"
- `webgl_max_params` — 11 comma-separated GPU limits
- `webgl_max_viewport_dims` — [width, height]
- `webgl_unmasked_vendor` — UNMASKED_VENDOR_WEBGL
- `webgl_unmasked_renderer` — UNMASKED_RENDERER_WEBGL
- `webgl_vsf_params` — vertex shader float precisions
- `webgl_vsi_params` — vertex shader int precisions
- `webgl_fsf_params` — fragment shader float precisions
- `webgl_fsi_params` — fragment shader int precisions
- `webgl_hash_webgl` — MurmurHash3 x64 over Object.entries(webglBlob).join(",")

**Navigator/Network:**
- `user_agent_data_brands` — navigator.userAgentData.brands
- `user_agent_data_mobile` — navigator.userAgentData.mobile
- `navigator_connection_downlink` — connection.downlink (Mbps)
- `navigator_connection_downlink_max` — connection.downlinkMax
- `network_info_rtt` — connection.rtt (ms)
- `network_info_save_data` — connection.saveData
- `network_info_rtt_type` — REPURPOSED: first 3 chars of webgl_extensions_hash + first 3 chars of webgl_hash_webgl
- `screen_pixel_depth` — REPURPOSED: screen.pixelDepth × 3
- `navigator_device_memory` — navigator.deviceMemory
- `navigator_languages` — navigator.languages.join(",")

**Window/Screen:**
- `window_inner_width`, `window_inner_height`
- `window_outer_width`, `window_outer_height`

**Browser Detection:**
- `browser_detection_firefox` — UA contains "Firefox"
- `browser_detection_brave` — brave window object
- `9f41a2c` — Perplexity Comet Browser detection
- `5c273b3` — Genspark AI Browser (navigator.genspark)
- `ce4046e` — Sigma Browser (window.__SIGMA__)
- `f58835f` — Browser API checks hash (MD5 of supported APIs: PermissionStatus, EyeDropper, AudioData, WritableStreamDefaultController, CSSCounterStyleRule, NavigatorUAData, BarcodeDetector, Intl.DisplayNames, ContactsManager, SVGDiscardElement, navigator.usb, navigator.mediaDevices, HTMLVideoElement.getVideoPlaybackQuality)
- `browser_object_checks` — MD5 hash of sorted global browser objects

**Sandbox/Headless Detection:**
- `29s83ih9` — Sandbox checks (JSDom etc)
- `headless_browser_phantom` — callPhantom, _phantom, etc
- `headless_browser_selenium` — Selenium/WebDriver heuristics
- `headless_browser_nightmare_js` — window.__nightmare
- `862f2c1` — Generic automation framework detection (bitmask: Selenium/ChromeDriver, Watir, WatiN, Geb, Spynner, Awesomium, Blender, domAutomation, Sequentum, Electron)
- `1l2l5234ar2` — CDP/Puppeteer detection

**Media:**
- `audio_codecs` — canPlayType for ogg, mp3, wav, m4a, aac
- `audio_codecs_extended_hash` — MD5 of extended audio probe
- `video_codecs` — canPlayType for ogg, h264, webm, mpeg4v, mpeg4a, theora
- `video_codecs_extended_hash` — MD5 of extended video probe
- `audio_fingerprint` — Web Audio API oscillator+compressor fingerprint

**CSS/Media Queries:**
- `media_query_dark_mode` — prefers-color-scheme: dark
- `f9bf2db` — CSS media queries object (pc, ah, ap, p, h, u, ic, prm, prt, s, fc)
- `05d3d24` — Extended CSS media queries (23 queries, sorted, MD5 hashed)

**Other:**
- `document__referrer` — document.referrer (query stripped)
- `window__ancestor_origins` — location.ancestorOrigins
- `window__tree_index` — frame index path from top
- `window__tree_structure` — recursive child frames
- `window__location_href` — location.href (query+fragment stripped)
- `client_config__sitedata_location_href` — host location.href (query stripped)
- `client_config__language` — config.language
- `client_config__surl` — optional surl from config
- `c8480e29a` — MD5(surl) + invisible separator
- `client_config__triggered_inline` — !!config.inlineRunOnTrigger
- `mobile_sdk__is_sdk` — boolean isSDK
- `z87b89t5` — null on web, 100302 on mobile SDK
- `navigator_battery_charging` — (await navigator.getBattery()).charging
- `7541c2s` — Media devices check
- `1f220c9` — Navigator permissions hash (MD5)
- `math_fingerprint` — JS engine floating point fingerprint
- `supported_math_functions` — Math function availability
- `3f76dd27` — Screen orientation
- `5dd48ca0` — RTCPeerConnection existence (bitmask)
- `4b4b269e68` — Session UUID (crypto.randomUUID)
- `6a62b2a558` — Script version hash (from enforcement filename)
- `is_keyless` — true if no public key in api.js URL
- `wait_for_settings` — config.waitForSettings
- `c2d2015` — Sensor data (accelerometer, gyroscope etc), MD5 hashed
- `43f2d94` — Web3/MetaMask detection
- `20c15922` — Bluetooth availability
- `4f59ca8` — Apple Pay availability/version
- `3ea7194` — HDR format support (HDR10, HLG, DolbyVision)
- `83eb055` — Keyboard layout
- `speech_default_voice` / `speech_voices_hash` — TTS voices MD5
- `vsadsa` — Navigation entries
- `basfas` — Heap size limit
- `lfasdgs` — Build ID (from enforcement bootstrap)
- `4ca87df3d1` — Mouse/biometrics data (75 events: x, y, timestamp, target)
- `867e25e5d4` — Touch event data (similar format)
- `d4a306884c` — Keyboard event data

### `jsbd` Object

```json
{
  "HL": "<window.history.length>",
  "NCE": "<navigator.cookieEnabled>",
  "DT": "<document.title>",
  "NWD": "<JSON.stringify(navigator.webdriver)>",
  "DMTO": 1,
  "DOTO": 1
}
```

### Encryption (AES-CBC, OpenSSL-style)

```json
{
  "ct": "<base64 ciphertext>",
  "iv": "<hex initialization vector>",
  "s": "<hex salt>"
}
```

**Key derivation:**
- BDA encryption (pre-4.x.x): Key = `userAgent + timeFrameKey`
  - `timeFrameKey = Math.floor((timestamp/1000) - ((timestamp/1000) % 21600))`
  - TIME_CONSTANT_VALUE = 21600 (6 hours)
- Other encryption: Key = `sessionToken` or `"REQUESTED" + sessionToken + "ID"`

**Decryption:**
1. Parse `ct` from base64, `s` from hex (8-byte salt), `iv` from hex (16-byte IV)
2. Derive key via `EVP_BytesToKey(key, salt, 32, 16)` — OpenSSL-compatible MD5-based
3. AES-CBC 256-bit decrypt with crypto.subtle

### Endpoint Flow

```
/fc/gt2/public_key/  → Setup + encrypted BDA → risk decision
/fc/gfct/            → Fetch challenge data (session_token, challengeID, challengeURL, dapib_url)
/fc/ekey/            → Encryption key exchange
Answer submission    → Per-round answer → multi-round loop
dapib_url            → Per-session verifier JS (reads window.parent.ae, produces tguess)
Verify API (v4)      → Server-side token verification
```

### Answer Encryption (breaker.js)

Challenge answers are obfuscated through 4 transforms:
1. Reverse each string value twice (double-reverse = identity, but executes)
2. Shift digits +33 (charCode), letters → charCode string
3. Clean to valid JS identifiers, swap key↔value
4. Append optional random char (sandbox detection)

### Key Constants

| Site | Public Key |
|------|-----------|
| Microsoft/Outlook signup | `B7D8911C-5CC8-A9A3-35B0-554ACEE604DA` |
| X/Twitter | Per-session from enforcement script |

---

## 4. DataDome / HUMAN Security

### Encryption: Custom XOR + PRNG + Custom Base64 (NOT AES-CBC)

**Layer 1 — Main PRNG Seed Derivation:**
```
prngSeed = 9959949970 ^ customHash(hash) ^ hashXorConstant
customHash() = djb2 variant: hash = (hash << 5) - hash + charCode | 0
```
Fallback for empty string: `1789537805`

**Layer 2 — PRNG (createPrng):**
- State machine: extracts 1 byte per call from 32-bit state
- Round 0: `state >> 8 & 0xFF`, Round 1: `state >> 0 & 0xFF`, Round 2: `state >> 16 & 0xFF`
- Every 3rd call: state mixed via modified Xorshift: `value ^= value << 13; value ^= value >> 17; value ^= value << 5`
- Salt XOR: `result ^= --saltState` (decrementing salt counter masked to 255)

**Layer 3 — Buffer Construction:**
- Each key-value pair: `[startMarker XOR prng] + [key UTF-8 XOR prng] + [58 XOR prng (':')] + [value UTF-8 XOR prng]`
- Start markers: `123` (`{`) for first entry, `44` (`,`) for subsequent
- Closing marker: `125` (`}`) XOR main PRNG XOR cidPRNG

**Layer 4 — CID-PRNG XOR (second layer):**
```
cidPrngSeed = 1809053797 ^ customHash(cid)
```
Independent PRNG stream, XORs every byte of the buffer. Salt = same as main PRNG but `useAlt = false`.

**Layer 5 — Custom Base64 Encoding:**
- Groups of 3 bytes → XOR with decrementing salt → split into 4 × 6-bit values
- Character mapping:
  - `0` → `-` (45), `1` → `_` (95)
  - `2-11` → `0-9` (48-57)
  - `12-37` → `A-Z` (65-90)
  - `38-63` → `a-z` (97-122)
- Padding: truncated (no `=` chars), length % 4 indicates padding

### HSV (Hidden State Value)

- **CAPTCHA:** Dynamic — `randHex[0..randIndex] + hash[-4:] + randHex[randIndex..]` (randIndex random 0-8, randHex random 8-char hex)
- **Interstitial:** Fixed `"9E9FC74889F6"`
- HSV injected as first signal's value in buffer

### Challenge Type Constants

| Constant | CAPTCHA | Interstitial |
|----------|---------|--------------|
| Main PRNG seed | `9959949970` | `9959949970` |
| Hash XOR | `-1748112727` | `-883841716` |
| CID PRNG constant | `1809053797` | `1809053797` |
| HSV | Dynamic (random) | Fixed `"9E9FC74889F6"` |
| Base64 padding | Handled | Skipped |

### WASM Challenge

Both captcha and interstitial embed a compiled WASM module:
- Base64 string starting with `"AGFzbQ"` (WebAssembly magic header `\0asm\x01\x00\x00\x00`)
- Executes via `new.WebAssembly.Instance()`
- Imports object produced by top-level "imports provider" function
- Fields hashed by `wasm_b()`: `hardwareConcurrency`, `br_oh`, `maxTouchPoints`, `maxTouchPoints` (varies per build)
- Dynamic challenge: per-session bit-twiddle expression over `(build-sig, br_ow, br_oh, hardwareConcurrency)`

### Bundle Shapes

| Script | Shape | Decoders |
|--------|-------|----------|
| Captcha | Browserify IIFE: `!function(e,B,s){ ... }({ 1:[fn,deps], ... })` | Module-local helpers `C`, `Q`, `Z`, `c`, `D`, `E` |
| Interstitial | Anonymous IIFE: `(function(){ var e={...modules...}; ... })()` | Same style as captcha |

### Fingerprinting Signals (after VM deobfuscation)

- Canvas: draws rect, reads back pixel values
- WebGL: full shader source in plain text after decode
- Timing: full navigation timeline
- Memory: current JS heap usage
- Screen: dimensions and pixel ratio
- DOM tricks: injects hidden elements to measure font rendering and layout
- Automation check: webdriver property

---

## 5. Akamai Bot Manager

### sensor_data Structure (v2.0)

The `sensor_data` parameter is a **58-element array** joined with a delimiter, then SHA-256 hashed:

```
Array → .join(delimiter) → SHA-256 hash → hex encoding → sensor_data string
```

Uses **negative number IDs as keys** (e.g., `"-100"`) alternating with collected values — flattened key-value pair format.

### Collected Data Points

| Category | Data Collected |
|----------|---------------|
| **Timing** | performance.now() / Date.now() — startTs, page load timing, interaction timing |
| **Browser** | User-Agent, plugins, MIME types, languages, platform |
| **Screen** | Screen dimensions, window dimensions, device pixel ratio, color depth |
| **Canvas** | 2D canvas fingerprint (text rendering), WebGL renderer/vendor |
| **Motion** | Mouse trajectories, click coordinates, scroll events, touch events |
| **Cookies** | `_abck` cookie parsing, `bm_sz` cookie parsing |
| **Device** | Device orientation, battery status, connection type |
| **Input** | Keyboard timing, form interaction patterns |

### Canvas Fingerprint

- Generated via offscreen canvas: draws text/shapes, calls `toDataURL()`
- Processed through charCodeAt sum function
- **Cannot be randomly forged** — must come from real browsers
- Located at array position ~22

### Motion Trajectory

- Collected via: mousemove, mousedown, mouseup, click, scroll, touchstart, touchmove, touchend
- Stored as concatenated coordinate+timestamp pairs
- Distance/velocity calculation: `sqrt((x0-x1)² + (x2-x3)² + (x4-x5)²)`
- **Must simulate realistic mouse movements** — constant velocity = bot detection

### Encryption: SHA-256

SHA-256 confirmed by classic round constants: `1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225`

Output converted to hex string.

### v3.0 Changes

- Uses `dK(N3, [key, value])` pairs instead of positional array
- Many more fields in final assembled payload
- Still uses same SHA-256 encryption approach
- `akamai-bm-telemetry` header derived from sensor_data (base64 encoded)

### Cookie Lifecycle

| Cookie | Purpose |
|--------|---------|
| `_abck` | Anti-bot cookie (encrypted, changes on each sensor POST) |
| `bm_sz` | Browser machine size/identity |
| `ak_bmsc` | Session token |

`_abck` values:
- `...~-1~-1~-1~-1` = failed
- `...~-1~0~-1~-1` = passed

---

## 6. Cloudflare JSD Challenge

### `__CF$cv$params` (extracted from page HTML)

| Field | Type | Description |
|-------|------|-------------|
| `r` | hex string | Oneshot path suffix |
| `t` | base64 string | Challenge token |

Regex: `__CF\$cv\$params\s*=\s*\{([^}]*(?:r\s*:\s*['"][^'"]*['"])[^}]*)\}`

### Oneshot POST Payload

POST to `/cdn-cgi/challenge-platform/h/{sitekey}/jsd/oneshot/{path}{r}`

| Field | Type | Value |
|-------|------|-------|
| `t` | int64 | `time.Now().Unix()` |
| `lhr` | string | `"about:blank"` |
| `api` | bool | `false` |
| `c` | bool | `false` |
| `payload` | object | Fingerprint (51 top-level keys, ~1610 entries) |

Entire JSON is **LZ-compressed to base64** using a custom 64-char alphabet extracted from the deobfuscated script.

### Fingerprint Template — 51 Top-Level Keys (~1610 entries)

**Template placeholders** (string-replaced at runtime):
- `__BASEURI__` → target URL
- `__ORIGIN__` → origin (scheme + host)
- `__HOST__` → hostname
- `__LASTMOD__` → current timestamp `01/02/2006 15:04:05`

**Major key categories:**

| Key | Items | Description |
|-----|-------|-------------|
| `"0"` | 9 | Numeric-value props: length, innerWidth, innerHeight, scrollX, pageXOffset, scrollY, pageYOffset, TEMPORARY, maxTouchPoints |
| `"1"`–`"32"` | varies | DOM node type constants and document position constants |
| `"880"` | 1 | outerHeight |
| `"1079"` | 1 | outerWidth |
| `"o"` | 117 | Object existence checks: window, self, document, navigator.*, d.* |
| `"F"` | 11 | Boolean properties: closed, crossOriginIsolated, credentialless, d.hidden, d.fullscreen, etc. |
| `"x"` | 264 | Undefined/existence props: event handlers, DOM nodes |
| `"__ORIGIN__"` | 1 | origin |
| `"1.25"` | 1 | devicePixelRatio |
| `"u"` | 2 | event, undefined |
| `"T"` | 11 | Boolean props: isSecureContext, originAgentCluster, offscreenBuffering, etc. |
| `"N"` | 1135 | Function existence/type checks: alert, fetch, d.createElement, d.addEventListener, etc. |
| `"q0"` | 1 | Array |
| `"Infinity"` | 1 | Infinity |
| `"NaN"` | 1 | NaN |
| `"Google Inc."` | 1 | navigator.vendor |
| `"Mozilla"` | 1 | navigator.appCodeName |
| `"Netscape"` | 1 | navigator.appName |
| UA string | 1 | navigator.appVersion |
| `"Win32"` | 1 | navigator.platform |
| `"Gecko"` | 1 | navigator.product |
| Full UA | 1 | navigator.userAgent |
| `"en-US"` | 2 | navigator.language, navigator.languages |
| `"about:blank"` | 3 | d.URL, d.documentURI, d.referrer |
| `"BackCompat"` | 1 | d.compatMode |
| `"UTF-8"` | 3 | d.characterSet, d.charset, d.inputEncoding |
| `"text/html"` | 1 | d.contentType |
| `"__HOST__"` | 1 | d.domain |
| `"s"` | 1 | d.cookie |
| `"__LASTMOD__"` | 1 | d.lastModified |
| `"complete"` | 1 | d.readyState |
| `"off"` | 1 | d.designMode |
| `"visible"` | 2 | d.visibilityState, d.webkitVisibilityState |
| `"#document"` | 1 | d.nodeName |
| `"__BASEURI__"` | 1 | d.baseURI |

### Deobfuscation Pipeline

1. `inlineConstantObjects` — inline numeric object literals
2. `extractOffset` — find decoder offset (pattern: `x = x - N`)
3. `extractTarget` — find rotation target (default: `159113`)
4. `extractRotationExpr` — find expression containing `parseInt`
5. `collectAliases` — find decoder function self-reassignment pattern
6. `buildstringsDynamic` — build string table using offset + target + rotation
7. `extractLZAlphabet` — find 64-char unique charset in `charAt` call

### Protocol

- Script: `{origin}/cdn-cgi/challenge-platform/scripts/jsd/main.js`
- Endpoint: `{origin}/cdn-cgi/challenge-platform/h/{sitekey}/jsd/oneshot/{path}{r}`
- Response: `cf_clearance` cookie
- `cf_clearance` tied to: IP + User-Agent + TLS fingerprint

---

## 7. Cloudflare Turnstile

### 28-Opcode Custom VM

Opcodes: `ADD`, `XOR`, `CALL`, `BTOA`, `RESOLVE`, `BIND_METHOD`, `JSON_STRINGIFY`, etc.

- Double-XOR encryption: outer with `p` token, inner with float key embedded in bytecode
- Register addresses assigned from random floating-point values per request
- Programs: 417–580 instructions after decryption

### 55-Field Fingerprint (3 Layers)

**Layer 1 — Browser Fingerprinting (38 fields):**

| Category | Count | Fields |
|----------|-------|--------|
| WebGL | 8 | UNMASKED_VENDOR_WEBGL, UNMASKED_RENDERER_WEBGL, WEBGL_debug_renderer_info, getExtension, getParameter, getContext, canvas, webgl |
| Screen | 8 | colorDepth, pixelDepth, width, height, availWidth, availHeight, availLeft, availTop |
| Hardware | 5 | hardwareConcurrency, deviceMemory, maxTouchPoints, platform, vendor |
| Font measurement | 4 | create hidden div → apply fonts → getBoundingClientRect → remove element |
| DOM probing | 8 | createElement, appendChild, removeChild, div, style, position, visibility, ariaHidden |
| Storage | 5 | Write to localStorage key `6f376b6560133c2c`, inspect quota.estimate, usage |

**Layer 2 — Cloudflare Edge Headers (5 fields):**
- `cfIpCity`
- `cfIpLatitude`
- `cfIpLongitude`
- `cfConnectingIp`
- `userRegion`

**Layer 3 — React Application State (3 fields):**
- `__reactRouterContext`
- `loaderData`
- `clientBootstrap`

### Signal Orchestrator

- 271-instruction module
- 6 event listeners: `keydown`, `pointermove`, `click`, `scroll`, `paste`, `wheel`
- 36 `window.__oai_so_*` properties: typing cadence, mouse speed, scroll pattern, idle time, paste behavior

### Proof of Work

- SHA-256 cache over 25 fingerprint fields
- 400k–500k uniform random iterations
- 7 binary flags: `ai`, `createPRNG`, `cache`, `solana`, `dump`, `InstallTrigger`, `data`

### Final Token

- `JSON.stringify` → XOR encrypt → `RESOLVE` return to parent frame
- Attached as `OpenAI-Sentinel-Turnstile-Token` header

### Server-Side API (Workers/WAF)

| Field | Type | Description |
|-------|------|-------------|
| `score` | 1-99 | Bot score (0 = not computed) |
| `verifiedBot` | boolean | Is verified bot |
| `staticResource` | boolean | Serves static resource |
| `ja3Hash` | string | JA3 fingerprint (Enterprise, HTTPS only) |
| `ja4` | string | JA4 fingerprint (Enterprise, HTTPS only) |
| `jsDetection.passed` | boolean | Passed JS detection |
| `detectionIds` | number[] | Heuristic detection IDs |
| `corporateProxy` | boolean | From corporate proxy (Enterprise) |

**BotScoreSrc values:** Heuristics, Machine Learning, Anomaly Detection, JS Detection, Cloudflare Service, Not Computed

**JA4 Signals (Enterprise):** `heuristic_ratio_1h`, `browser_ratio_1h`, `cache_ratio_1h`, `h2h3_ratio_1h`, `uas_rank_1h`, `paths_rank_1h`, `reqs_rank_1h`, `ips_rank_1h`, `reqs_quantile_1h`, `ips_quantile_1h`

---

## 8. Kasada

### Request Flow

| Component | Role |
|-----------|------|
| `p.js` | Initializer — SHA256 PoW chaining, seed phrases, difficulty params |
| `/mfc` | Endpoint — fetches challenge parameters (difficulty, sub-challenge counts, prefix) |
| `ips.js` (~477KB) | Payload generator — full VM, fingerprinting, encryption |
| `/tl` | Endpoint — POST encrypted fingerprint payload, receives tokens |

### Output Headers

| Header | Description |
|--------|-------------|
| `x-kpsdk-ct` | Client Token — expensive, fingerprint-tied, ~30min TTL, reusable across requests |
| `x-kpsdk-cd` | Client Data — cheap, per-request, single-use (<5s freshness) |
| `x-kpsdk-h` | HMAC signature binding CT to CD |
| `x-kpsdk-v` | Version identifier |
| `x-kpsdk-r` | Request ID |

### VM Architecture (ips.js)

| Property | Value |
|----------|-------|
| Handlers | 172 opcode handlers (proxy-dispatched) |
| Bytecode encoding | Custom character-mapped scheme, variable-length, dynamic alphabet |
| Time-lock | Seed derived from current time → ~5-hour decode window |
| Permutation table | Fisher-Yates shuffle with embedded seed → maps raw opcodes to handler indices |
| State object | Registers, scope chains, exception handlers |
| Components | Bytecode decoder + massive encoded string + VM executor |

Core dispatcher: reads next opcode, maps through permutation table (`>> 5` shift), dispatches through handler array. Each handler operates on state object with virtual registers.

### 428-Slot Template Array & Probe System

- **428 slots**, populated by **427 probes** in **20 batches** executing in parallel
- Template **shuffled between batches** — different seeds and algorithms per shuffle
- A **dynamic challenge probe** computes values from VM bytecodes + device-specific values (proves real VM execution)

| Category | Examples |
|----------|----------|
| Standard properties | User agent, screen dimensions, timezone, platform |
| Canvas/WebGL | Rendering hashes, GPU vendor/renderer strings, parameter values |
| Audio context | Capabilities, sample rates, channel configurations |
| Installed fonts | Enumeration and measurement |
| Timing measurements | Event latency, rAF cadence, input-to-action gaps |
| Navigator state | webdriver flag, window.chrome shape, plugin list |
| Anti-instrumentation | CDP detection, Playwright bindings, Selenium prefixes |
| Consistency checks | UA↔API surface agreement, platform↔font set, version↔codecs |
| Dynamic challenge | Bytecode-derived values proving real VM execution |

### XTEA Encryption

Standard XTEA block cipher:
- 64-bit blocks, 32 rounds, DELTA = `0x9E3779B9`
- 16-byte key (4 × 32-bit integers)
- Custom CBC-like chaining: each block's output feeds into next block's input
- Key NOT stored plainly — embedded as integer array, expanded through rotation/shift/arithmetic

```
// 32 rounds of XTEA:
sum = 0
for _ in range(32):
    v0 = (v0 + (((v1 << 4) ^ (v1 >> 5)) + v1 ^ (sum + key[sum & 3]))) | 0
    sum = (sum + 2654435769) | 0
    v1 = (v1 + (((v0 << 4) ^ (v0 >> 5)) + v0 ^ (sum + key[(sum >> 11) & 3]))) | 0
```

### Proof-of-Work

| Parameter | Source |
|-----------|--------|
| Seed phrase | Per-domain constant (embedded in p.js) |
| Difficulty | Retrieved from `/mfc` endpoint |
| Sub-challenge count | Retrieved from `/mfc` |
| Algorithm | SHA256 chaining — find nonces below difficulty threshold |
| Sub-challenges | Multiple, solved sequentially |
| Cost | ~100ms CPU time for real browser |

### Anti-Instrumentation

- **CDP Runtime.enable side channel:** console.log Error with custom stack getter → V8 serializes for debugger → getter fires → marks instrumented
- **Framework globals:** navigator.webdriver, `__playwright__binding__`, `__pwInitScripts`, `cdc_*` Selenium prefixes
- **Consistency checks:** UA claims Chrome 134 but BarcodeDetector missing → contradiction. Platform↔font↔codec↔WebGL agreement

### Payload POST Structure (→ /tl)

1. Fingerprint template (428-slot array, XTEA-CBC encrypted)
2. PoW solutions (nonces for each sub-challenge)
3. Dynamic challenge proof (bytecode-derived verification values)
4. Timestamp (freshness validation)

### Key Rotation

- Bytecode (ips.js) rotates every few weeks
- Time-lock: ~5-hour decode window per script version
- Each site has unique seed phrases
- Template shuffle seeds change per batch

---

## 9. GitHub (Lightweight)

GitHub uses a lightweight fingerprinting approach based on fingerprintjs, NOT a dedicated anti-bot vendor.

### BotD Detection Signals

| Detection | Signal | Frameworks |
|-----------|--------|------------|
| `hasWebdriver` | navigator.webdriver === true | Selenium, Puppeteer, Playwright |
| `hasWebdriverWritable` | webdriver property descriptor | Puppeteer, Playwright |
| `hasSeleniumProperty` | document.$cdc_, $wdc_ | Selenium WebDriver |
| `hasCDP` | CDP runtime markers | Chrome DevTools Protocol |
| `hasPlaywright` | __playwright, __pw_* | Playwright |
| `hasMissingChromeObject` | Missing window.chrome | Headless Chrome |
| `headlessChromeScreenResolution` | 800x600 default | Headless browsers |
| `hasHighCPUCount` | Unrealistic core count | VM/container environments |
| `hasImpossibleDeviceMemory` | Unrealistic memory values | Spoofed environments |

### Fingerprint Structure (fpscanner reference)

```json
{
  "fastBotDetection": true,
  "fastBotDetectionDetails": {
    "hasWebdriver": false,
    "hasWebdriverWritable": true,
    "hasSeleniumProperty": false,
    "hasCDP": false,
    "hasPlaywright": false,
    "hasWebdriverIframe": false,
    "hasWebdriverWorker": false
  },
  "fsid": "JA4-inspired fingerprint ID",
  "signals": { "raw signal data" },
  "time": 1752172800000,
  "nonce": "random value for replay detection"
}
```

### Anti-Replay

- Timestamp validation (fingerprint expires after N seconds)
- Nonce for replay detection
- Build-time key injection for payload encryption

---

## 10. Cross-Platform Comparison

| Feature | Xiaomi | X/Twitter XPFF | X/Twitter TxID | Arkose | DataDome | Akamai | CF JSD | CF Turnstile | Kasada | GitHub |
|---------|--------|---------------|----------------|--------|----------|--------|--------|-------------|--------|--------|
| **Encryption** | RSA+AES | AES-256-GCM | SHA-256+XOR | AES-256-CBC | XOR+PRNG | SHA-256 | LZ-comp | XOR+VM | XTEA-CBC | Base64 |
| **Key Size** | 1024/2048-bit RSA | 256-bit (SHA-256 derived) | N/A (hash) | 256-bit (MD5 chain) | Variable | 256-bit SHA | Custom alpha | Embedded float | 128-bit XTEA | N/A |
| **VM/Bytecode** | No | Go WASM | No | No | Custom VM+WASM | VM (v3) | No | 28-opcode VM | 172-handler VM | No |
| **Canvas FP** | ✅ (p20) | ❌ (empty) | ❌ | ✅ (CFP) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **WebGL FP** | ✅ (p21) | ❌ (empty) | ❌ | ✅ (enhanced_fp) | ✅ | ✅ | ✅ | ✅ (8 fields) | ✅ | ✅ |
| **Audio FP** | ✅ (p25) | ❌ (empty) | ❌ | ✅ (audio_fingerprint) | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ |
| **Mouse/Click** | ✅ (a3/a5) | ❌ | ❌ (CSS anim) | ✅ (4ca87df3d1) | ✅ | ✅ | ✅ | ✅ (36 props) | ✅ | ✅ |
| **Behavioral** | Basic | None | CSS animation | 75 events | Motion data | Trajectory | Object checks | 271-instr orchestrator | 20 batch probes | Basic |
| **PoW** | No | No | No | No | No | No | No | SHA-256 400-500k | SHA256 chaining | No |
| **WebDriver** | ✅ (p33) | ✅ (webdriver) | ❌ | ✅ (NWD) | ✅ | ✅ | ✅ (1135 fn) | ✅ | ✅ | ✅ |
| **Token TTL** | Session | 5 min | N/A (per-req) | Session | Session | ~30min (_abck) | Session (cf_clearance) | Session | ~30min (CT) | Session |


*Last updated: 2026-07-11*

